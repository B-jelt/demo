<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

if(isset($_POST['hidden'])AND($_POST['hidden'])=='h')
{

if(isset($_POST['name'])AND($_POST['name'])!=null)
{

  
	if(preg_match('/^[A-Z a-z]*$/',$_POST['name']))
  {

if(isset($_POST['age'])AND($_POST['age'])!=null)
{
if(isset($_POST['gender'])AND($_POST['gender'])!=null)
{
if(isset($_POST['phone'])AND($_POST['phone'])!=null)
{
	if(preg_match('/^[0-9]*$/',$_POST['contact']))
  {
  	$nm1=strlen($_POST['contact']);
  	if($nm1>=10 and $nm1<=12)
  	{
if(isset($_POST['email'])AND($_POST['email'])!=null)
{
if(isset($_POST['password'])AND($_POST['password'])!=null)
{
if(isset($_POST['confirm'])AND($_POST['confirm'])!=null)
{ 

	$a=trim($_POST['name']);
	$b=trim($_POST['age']);
	$c=trim($_POST['gender']);
	$d=trim($_POST['phone']);
    $e=trim($_POST['email']); 
    $f=trim($_POST['password']);
 
    $obj->dreg($a,$b,$c,$d,$e,$f,$_FILES['photo']);
  
    
}
else
echo "<script>alert('confirm password is empty')</script>";
}
else
echo "<script>alert('password is empty')</script>";
}
else
echo "<script>alert('email is empty')</script>";
}

else
echo "<script>alert('contact is invalid')</script>";
}
else
echo "<script>alert('contact is invalid')</script>";
}
else
echo "<script>alert('contact is invalid')</script>";
}
else
echo "<script>alert('gender is empty')</script>";
}
else
echo "<script>alert('age is empty')</script>";
}

else
echo "<script>alert('name is invalid')</script>";
}
else
echo "<script>alert('name is empty')</script>";
}	
$smartyObj->display("reg.tpl");
?>
