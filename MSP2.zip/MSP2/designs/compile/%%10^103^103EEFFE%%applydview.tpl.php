<?php /* Smarty version 2.6.26, created on 2021-02-15 11:09:18
         compiled from applydview.tpl */ ?>
<html>
<head><title> Casting</title></head>
<body><form action="" method="post">
<center><h3>Casting applications</h3></center>
<table class="table table-striped">

<tr>

	<th>Full Name</th>
	<th>Address</th>
	<th>Pincode</th>
	<th>District</th>
	<th>City</th>
	<th>Gender</th>
	<th>Age</th>
	<th>Contact</th>
	<th>Emailid</th>
	<th>Photo</th>
	</tr>
<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
<tr>
	<td><?php echo $this->_tpl_vars['b']['fullname']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['address']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['pincode']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['district']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['city']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['gender']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['age']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['contact']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['emailid']; ?>
</td>
	<td><img src="<?php echo $this->_tpl_vars['b']['path']; ?>
" width="100px" height="100px"></td>
	<?php if ($this->_tpl_vars['b']['status'] == 1): ?>
    <td>Approved</td>
    <td><a href="rejectapp.php?v=<?php echo $this->_tpl_vars['b']['cakey']; ?>
" class="btn btn-danger">Reject</a></td>
	<?php elseif ($this->_tpl_vars['b']['status'] == 2): ?>
	<td>Rejected</td>
	<td><a href="approveapp.php?v=<?php echo $this->_tpl_vars['b']['cakey']; ?>
" class="btn btn-primary">Approve</a></td>
	<?php else: ?>
	<td><a href="approveapp.php?v=<?php echo $this->_tpl_vars['b']['cakey']; ?>
" class="btn btn-primary">Approve</a></td>
	<td><a href="rejectapp.php?v=<?php echo $this->_tpl_vars['b']['cakey']; ?>
" class="btn btn-danger">Reject</a></td>
	<?php endif; ?>
</tr><?php endforeach; endif; unset($_from); ?>
</table>
</form>
</body>
</html>