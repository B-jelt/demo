<?php /* Smarty version 2.6.26, created on 2021-02-08 07:51:08
         compiled from profileview.tpl */ ?>
<html>
<head><title>Edit Movie</title></head>
<body><form action="" method="post"  enctype="multipart/form-data">
<center><h3>Profile Edit</h3></center>
<table class="table table-bordered">
<tr>
	<th>Director Name</th>
	<th>Age</th>
	<th>Photo</th>
	<th>Gender</th>
	<th>Phone</th>
	<th>Email</th>
	

	</tr>
<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
<tr>
	<td><?php echo $this->_tpl_vars['b']['director']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['age']; ?>
</td>
	<td><img src="<?php echo $this->_tpl_vars['b']['path']; ?>
" width="100px" height="100px"></td>
	<td><?php echo $this->_tpl_vars['b']['gender']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['phone']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['email']; ?>
</td>
	

	<td><a href="profileupdate.php?v=<?php echo $this->_tpl_vars['b']['dkey']; ?>
" class="btn btn-primary">EDIT</a></td>
	<td><a href="profiledelete.php?v=<?php echo $this->_tpl_vars['b']['dkey']; ?>
" class="btn btn-danger">DELETE</a></td>
	</tr><?php endforeach; endif; unset($_from); ?>
</table>
</form>
</body>
</html>