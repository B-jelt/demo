<?php /* Smarty version 2.6.26, created on 2021-02-09 09:42:20
         compiled from dcast.tpl */ ?>
<html>
<head><title>CASTING</title></head>
<center><body><h3>CASTING</h3>
<form method="post" action="">
<input type="hidden" name="hidden" value="h">
<table>
<tr><td>Category</td><td><select name="category" class="form-control">
<OPTION value="select" class="form-control">select</OPTION>
<option>Hero</option>
<option>Heroine</option>
<option>Junior artist</option>
</select></td></tr>
<tr><td>Age From </td><td><input type="number" name="agefrom" class="form-control"></td></tr>
<tr><td>Age To</td><td><input type="number" name="ageto" class="form-control"></td></tr>
<tr><td>Gender</td><td><input type="radio" name="gender" value="male">Male
	<input type="radio" name="gender" value="female">Female</td></tr>

<tr><td>Last Date For Apply</td><td><input type="date" name="lastdate" class="form-control"></td></tr>
<tr><td>Other Details</td><td><textarea name="details" class="form-control"></textarea></td>
<tr><td><td><input type="submit" name="submit" value="SUBMIT"class="btn btn-success"></td></td></tr>
</table>
</form>
</body>
</center>
</html>