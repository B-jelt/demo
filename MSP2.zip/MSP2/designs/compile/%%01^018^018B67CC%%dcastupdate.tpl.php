<?php /* Smarty version 2.6.26, created on 2021-02-10 07:51:28
         compiled from dcastupdate.tpl */ ?>
<html>
<head><title>Update </title></head>
<body><form action="" method="post">
<center>	<h2>Update Casting Details</h2>
<table>	
<tr>
<input type="hidden" name="hidden" value="h"></tr><br>
<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>

<tr><td>Category</td><td><select name="category" class="form-control">
<OPTION value="<?php echo $this->_tpl_vars['b']['category']; ?>
" class="form-control"><?php echo $this->_tpl_vars['b']['category']; ?>
</OPTION>
<option>Hero</option>
<option>Heroine</option>
<option>Junior artist</option>
</select></td></tr><tr><td>Age from</td><td><input type="text" name="agefrom" value="<?php echo $this->_tpl_vars['b']['agefrom']; ?>
" class="form-control"></td></tr>
<tr><td>Age to</td><td><input type="number" name="ageto" value="<?php echo $this->_tpl_vars['b']['ageto']; ?>
" class="form-control"></td></tr>

<tr><td>Gender</td><td>
	<?php if ($this->_tpl_vars['b']['gender'] == male): ?>
	<input type="radio" name="gender" value="male" checked>Male
	<input type="radio" name="gender" value="female">Female</td></tr>
	<?php else: ?>
	<input type="radio" name="gender" value="male">Male
	<input type="radio" name="gender" value="female" checked>Female</td></tr>
	<?php endif; ?>
<tr><td>Last Date</td><td><input type="date" name="lastdate" value="<?php echo $this->_tpl_vars['b']['lastdate']; ?>
" class="form-control"></td></tr>
<tr><td>Other Details</td><td><textarea name="details" class="form-control"><?php echo $this->_tpl_vars['b']['details']; ?>
</textarea></td>

<?php endforeach; endif; unset($_from); ?>
<tr><td></td><td><input type="submit"  value="UPDATE" class="btn btn-success"></td></tr>
</table></center></form></body></html>