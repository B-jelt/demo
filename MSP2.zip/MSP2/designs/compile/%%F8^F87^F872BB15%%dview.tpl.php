<?php /* Smarty version 2.6.26, created on 2021-02-15 10:06:23
         compiled from dview.tpl */ ?>
<html>
<head><title>Edit Movie</title></head>
<body><form action="" method="post"  enctype="multipart/form-data">
<center><h3>Profile Edit</h3></center>
<table class="table table-bordered">
<tr>
	<th>Director Name</th>
	<th>Age</th>
	<th>Photo</th>
	<th>Gender</th>
	<th>Phone</th>
	<th>Email</th>

	</tr>
<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
<tr>
	<td><?php echo $this->_tpl_vars['b']['director']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['age']; ?>
</td>
	<td><img src="<?php echo $this->_tpl_vars['b']['path']; ?>
" width="100px" height="100px"></td>
	<td><?php echo $this->_tpl_vars['b']['gender']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['contact']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['email']; ?>
</td>
    <?php if ($this->_tpl_vars['b']['status'] == 1): ?>
    <td>Approved</td>
    <td><a href="reject.php?v=<?php echo $this->_tpl_vars['b']['loginkey']; ?>
" class="btn btn-danger">Reject</a></td>
	<?php elseif ($this->_tpl_vars['b']['status'] == 2): ?>
	<td>Rejected</td>
	<td><a href="approve.php?v=<?php echo $this->_tpl_vars['b']['loginkey']; ?>
" class="btn btn-primary">Approve</a></td>
	<?php else: ?>
	<td><a href="approve.php?v=<?php echo $this->_tpl_vars['b']['loginkey']; ?>
" class="btn btn-primary">Approve</a></td>
	<td><a href="reject.php?v=<?php echo $this->_tpl_vars['b']['loginkey']; ?>
" class="btn btn-danger">Reject</a></td>
	<?php endif; ?>
	</tr><?php endforeach; endif; unset($_from); ?>
</table>
</form>
</body>
</html>