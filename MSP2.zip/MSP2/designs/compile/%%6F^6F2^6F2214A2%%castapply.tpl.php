<?php /* Smarty version 2.6.26, created on 2021-03-09 15:34:41
         compiled from castapply.tpl */ ?>
<html>
<head><title>CAST APPLY</title></head>
<center><body><h3>CAST APPLY</h3>
<form method="post" action="" enctype="multipart/form-data">
<input type="hidden" name="hidden" value="h">
<table>
<tr><td>Full Name</td><td><input type="text" name="fullname" class="form-control"></td></tr>
<tr><td>Address</td><td><textarea name="address" class="form-control"></textarea></td>
</tr>
<tr><td>Pincode</td><td><input type="number" name="pincode" class="form-control"></td></tr>
<tr><td>District</td><td><input type="text" name="district" class="form-control"></td></tr>
<tr><td>City</td><td><input type="text" name="city" class="form-control"></td>	
<tr><td>Gender</td><td><input type="radio" name="gender" value="male">Male
	<input type="radio" name="gender" value="female">Female</td></tr>
<tr><td>Age</td><td><input type="number" name="age" class="form-control"></td>
<tr><td>Photo</td><td><input type="file" name="photo" class="form-control"></td>
<tr><td>Contact</td><td><input type="number" name="contact" class="form-control"></td>
<tr><td>Emailid</td><td><input type="email" name="emailid" class="form-control"></td>	
</tr>
<tr><td><td><input type="submit" name="submit" value="SUBMIT"class="btn btn-success"></td></td></tr>
</table>
</form>
</body>
</center>
</html>