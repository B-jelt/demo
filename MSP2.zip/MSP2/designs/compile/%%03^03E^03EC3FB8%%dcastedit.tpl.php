<?php /* Smarty version 2.6.26, created on 2021-02-10 10:00:12
         compiled from dcastedit.tpl */ ?>
<html>
<head><title>Edit Casting</title></head>
<body><form action="" method="post">
<center><h3>Edit Casting</h3></center>
<table class="table table-striped">

<tr>
	<th>Category</th>
	<th>Age From</th>
	<th>Age To</th>
	<th>Gender</th>
	<th>Last Date</th>
	<th>Details</th>
	<th>Current date</th>
	</tr>
<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
<tr>
	<td><?php echo $this->_tpl_vars['b']['category']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['agefrom']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['ageto']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['gender']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['lastdate']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['details']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['currentdate']; ?>
</td>

	<td><a href="dcastupdate.php?v=<?php echo $this->_tpl_vars['b']['ckey']; ?>
" class="btn btn-primary">EDIT</a></td>
	<td><a href="dcastdelete.php?v=<?php echo $this->_tpl_vars['b']['ckey']; ?>
" class="btn btn-danger">DELETE</a></td>
	</tr><?php endforeach; endif; unset($_from); ?>
</table>
</form>
</body>
</html>