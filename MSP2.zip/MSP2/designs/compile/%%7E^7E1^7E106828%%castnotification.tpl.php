<?php /* Smarty version 2.6.26, created on 2021-03-09 16:53:57
         compiled from castnotification.tpl */ ?>
<html>
<head><title>Approved user</title></head>
<body><form action="" method="post">
<center><h3>Approved user</h3></center>
<table class="table table-bordered">
<tr>
<?php if ($this->_tpl_vars['view'] == 1): ?>
<th> Your request has been approved</th>
<?php else: ?>
<th>your request has been rejected</th>
<?php endif; ?>
</tr>
</table>
</form>
</body>
</html>