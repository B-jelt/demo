<?php /* Smarty version 2.6.26, created on 2021-01-13 06:33:12
         compiled from otp.tpl */ ?>
<!DOCTYPE html>
<html>

<head>

  <meta charset="UTF-8">

  <title>OTP PAGE </title>

  <link rel="stylesheet" href="otp/css/reset.css">

    <link rel="stylesheet" href="otp/css/style.css" media="screen" type="text/css" />

</head>

<body>

  <div class="wrap">
		<div class="avatar">
      <img src="otp/avatar.png">

		</div>
		<form method="post" action="">
       <input type="hidden" name="hidden" value="h">

		<input type="number" name="mobilenumber" placeholder="Mobile number" required>
		
        <input type="submit" name="submit" value="SUBMIT" class="btn btn-success">
</form>

<form method="post" action="">
	 <input type="hidden" name="hidden1" value="h">

		<div class="bar">
			<i></i>
		</div>
        	<input type="password" name="otp" placeholder="enter otp" required>
        	<input type="submit" value="submit" class="btn btn-info">
	
	</div>

<?php echo '
  <script src="otp/js/index.js"></script>'; ?>


</form>
</body>

</html>