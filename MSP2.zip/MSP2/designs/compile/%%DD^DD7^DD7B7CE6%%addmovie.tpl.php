<?php /* Smarty version 2.6.26, created on 2021-01-05 06:31:55
         compiled from addmovie.tpl */ ?>
<html>
<head><title>ADD MOVIE</title></head>
<center><body><h3>ADD MOVIES</h3>
<form method="post" action="" enctype="multipart/form-data">
<input type="hidden" name="hidden" value="h">
<table>
<tr><td>Picture</td><td><input type="file" name="picture" class="form-control"></td></tr>

<tr><td>Movie</td><td><input type="text" name="moviename" class="form-control"></td></tr>
<tr><td>Genres</td><td><input type="text" name="genres" class="form-control"></td></tr>
<tr><td>Hero</td><td><input type="text" name="hero" class="form-control"></td></tr>
<tr><td>Heroine</td><td><input type="text" name="heroine" class="form-control"></td></tr>
<tr><td>Director</td><td><input type="text" name="director" class="form-control"></td>	
<tr><td>Producer</td><td><input type="text" name="producer" class="form-control"></td>
</tr>
<tr><td>Movie Details</td><td><textarea name="moviedetails" class="form-control"></textarea></td>
</tr>
<tr><td>Release Year</td><td><input type="date" name="releaseyear" class="form-control"></td></tr>
<tr><td><td><input type="submit" name="submit" value="SUBMIT"class="btn btn-success"></td></td></tr>
</table>
</form>
</body>
</center>
</html>