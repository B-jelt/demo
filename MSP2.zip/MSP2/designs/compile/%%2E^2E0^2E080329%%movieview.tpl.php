<?php /* Smarty version 2.6.26, created on 2021-01-05 06:18:54
         compiled from movieview.tpl */ ?>
<html>
<head><title>Edit Movie</title></head>
<body><form action="" method="post"  enctype="multipart/form-data">
<center><h3>Edit Movies</h3></center>
<table class="table table-bordered">
<tr><th>Picture</th>
	<th>Movie name</th>
	<th>Genre</th>
	<th>Hero</th>
	<th>Heroine</th>
	<th>Director</th>
	<th>Producer</th>
	<th>Movie details</th>
	<th>Release Year</th>
	<th>Current date</th>
	</tr>
<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
<tr><td><img src="<?php echo $this->_tpl_vars['b']['path']; ?>
" width="100px" height="100px"></td>
	<td><?php echo $this->_tpl_vars['b']['moviename']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['genres']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['hero']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['heroine']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['director']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['producer']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['moviedetails']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['releaseyear']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['currentdate']; ?>
</td>

	<td><a href="movieedit.php?v=<?php echo $this->_tpl_vars['b']['newkey']; ?>
" class="btn btn-primary">EDIT</a></td>
	<td><a href="moviedelete.php?v=<?php echo $this->_tpl_vars['b']['newkey']; ?>
" class="btn btn-danger">DELETE</a></td>
	</tr><?php endforeach; endif; unset($_from); ?>
</table>
</form>
</body>
</html>