<?php /* Smarty version 2.6.26, created on 2021-01-05 09:58:29
         compiled from movieeditv.tpl */ ?>
<html>
<head><title>Update details</title></head>
<body><form action="" method="post" enctype="multipart/form-data">
<center>	<h2>Update Details</h2>
<table>	
<tr>
<input type="hidden" name="hidden" value="h"></tr><br>
<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
<tr><td>Picture</td><td><input type="file" name="picture" class="form-control"></td></tr>

<tr><td>Movie Name</td><td><input type="text" name="moviename" value="<?php echo $this->_tpl_vars['b']['moviename']; ?>
"class="form-control"></td></tr>
<tr><td>Genres</td><td><input type="text" name="genres" value="<?php echo $this->_tpl_vars['b']['genres']; ?>
" class="form-control"></td></tr>
<tr><td>Hero</td><td><input type="text" name="hero" value="<?php echo $this->_tpl_vars['b']['hero']; ?>
" class="form-control"></td></tr>
<tr><td>Heroine</td><td><input type="text" name="heroine" value="<?php echo $this->_tpl_vars['b']['heroine']; ?>
" class="form-control"></td></tr>
<tr><td>Director</td><td><input type="text" name="director" value="<?php echo $this->_tpl_vars['b']['director']; ?>
" class="form-control"></td></tr>
<tr><td>Producer</td><td><input type="text" name="producer" value="<?php echo $this->_tpl_vars['b']['producer']; ?>
" class="form-control"></td></tr>
<tr><td>Movie details</td><td><textarea name="moviedetails" class="form-control"><?php echo $this->_tpl_vars['b']['moviedetails']; ?>
</textarea></td></tr>
<tr><td>Release Year</td><td><input type="date" name="releaseyear" value="<?php echo $this->_tpl_vars['b']['releaseyear']; ?>
" class="form-control"></td></tr>
<?php endforeach; endif; unset($_from); ?>
<tr><td><td><input type="submit" name="submit" value="UPDATE" class="btn btn-success"></td></td></tr>
</table></center></form></body></html>