<?php /* Smarty version 2.6.26, created on 2021-04-12 12:08:51
         compiled from predict.tpl */ ?>
<html>
<head><title>PREDICTION</title>
</head>
<center><body>
<form method="post" action="">
<input type="hidden" name="hidden" value="h">
<table>
<tr><td>Hero</td><td><select name="hero">
	<option>--Select--</option>
	<?php $_from = $this->_tpl_vars['hero']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['h']):
?>
	<option><?php echo $this->_tpl_vars['h']['hero']; ?>
</option>
	<?php endforeach; endif; unset($_from); ?>
</select></td></tr>
<tr><td>Heroine</td><td><select name="heroine">
	<option>--Select--</option>
	<?php $_from = $this->_tpl_vars['heroine']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['h']):
?>
	<option><?php echo $this->_tpl_vars['h']['heroine']; ?>
</option>
	<?php endforeach; endif; unset($_from); ?>
</select></td></tr>
<tr><td>Director</td><td><select name="director">
	<option>--Select--</option>
	<?php $_from = $this->_tpl_vars['director']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['h']):
?>
	<option><?php echo $this->_tpl_vars['h']['director']; ?>
</option>
	<?php endforeach; endif; unset($_from); ?>
</select></td></tr>
<tr><td>Producer</td><td><select name="producer">
	<option>--Select--</option>
	<?php $_from = $this->_tpl_vars['producer']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['h']):
?>
	<option><?php echo $this->_tpl_vars['h']['producer']; ?>
</option>
	<?php endforeach; endif; unset($_from); ?>
</select></td></tr>
<tr><td>Musician</td><td><select name="musician">
	<option>--Select--</option>
	<?php $_from = $this->_tpl_vars['musician']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['h']):
?>
	<option><?php echo $this->_tpl_vars['h']['musician']; ?>
</option>
	<?php endforeach; endif; unset($_from); ?>
</select></td></tr>

<tr><td><td><input type="submit" name="submit" value="SUBMIT"class="btn btn-success"></td></td></tr>
</table>
</form>
</body>
</center>
</html>