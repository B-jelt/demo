<?php /* Smarty version 2.6.26, created on 2021-04-12 19:18:14
         compiled from applicationlist.tpl */ ?>
<html>
<head><title>List of Applications</title></head>
<center><body><h3>List of Applications</h3>
<form method="post" action="" enctype="multipart/form-data">
<input type="hidden" name="hidden" value="h">
<table>
<tr><td>Register Id</td><td><input type="number" name="register" class="form-control"></td></tr>


<tr><td><td><input type="submit" name="submit" value="SUBMIT"class="btn btn-success"></td></td></tr>
</table>
<?php if ($this->_tpl_vars['view'] != null): ?>
<table>
	<tr>
	<th>Category</th>
	<th>Age from</th>
	<th>Age to</th>
	<th>Gender</th>
	<th>Last Date</th>
	<th>Details</th>
	

	</tr>
	<tr>

<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
		<th><?php echo $this->_tpl_vars['b']['category']; ?>
</th>
		<th><?php echo $this->_tpl_vars['b']['agefrom']; ?>
</th>
		<th><?php echo $this->_tpl_vars['b']['ageto']; ?>
</th>
		<th><?php echo $this->_tpl_vars['b']['gender']; ?>
</th>
		<th><?php echo $this->_tpl_vars['b']['lastdate']; ?>
</th>
		<th><?php echo $this->_tpl_vars['b']['details']; ?>
</th>
		<?php if ($this->_tpl_vars['b']['status'] == 0): ?>
		<th>pending</th>
		<?php elseif ($this->_tpl_vars['b']['status'] == 1): ?>
		<th><span class="blue">Shortlisted</span></th>
		<?php else: ?>
		<th>rejected</th>
		<?php endif; ?>

	</tr>
	<?php endforeach; endif; unset($_from); ?>
</table>
<?php endif; ?>
</form>
</body>
</center>
</html>