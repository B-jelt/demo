<?php /* Smarty version 2.6.26, created on 2021-02-12 06:55:53
         compiled from castview.tpl */ ?>
<html>
<head><title> Casting</title></head>
<body><form action="" method="post">
<center><h3>Casting Call</h3></center>
<table class="table table-striped">

<tr>

	<th>Category</th>
	<th>Age From</th>
	<th>Age To</th>
	<th>Gender</th>
	<th>Last Date</th>
	<th>Details</th>
	<th>Posting date</th>
	<th>Director Name</th>
	<th>Contact</th>
	</tr>
<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
<tr>
	<td><?php echo $this->_tpl_vars['b']['category']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['agefrom']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['ageto']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['gender']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['lastdate']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['details']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['currentdate']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['director']; ?>
</td>
	<td><?php echo $this->_tpl_vars['b']['contact']; ?>
</td>
	

	<td><a href="castapply.php?v=<?php echo $this->_tpl_vars['b']['ckey']; ?>
" class="btn btn-primary">APPLY</a></td>
	
	</tr><?php endforeach; endif; unset($_from); ?>
</table>
</form>
</body>
</html>