<?php /* Smarty version 2.6.26, created on 2020-12-30 10:12:11
         compiled from userreg.tpl */ ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="" method="post">
	<input type="hidden" name="hide" value="h">
	<table align="center">
		<tr>
		<td>NAME</td>
			<td>
				<input type="text" name="name" class="form-control">
			</td>
		</tr>
		<tr>
			<td>ADDRESS</td>
			<td><textarea name="address" class="form-control"></textarea></td>
		</tr>
		<tr>
		<td>PINCODE</td>
		<td><input type="text" name="pincode" class="form-control"></td>
		</tr>
		<tr>
			<td>GENDER</td>
			<td><input type="radio" name="gender" value="male">MALE
			<input type="radio" name="gender" value="female">FEMALE</td>
		</tr>
		<tr>
		<td>DATE OF BIRTH</td>
		<td><input type="date" name="dob" class="form-control"></td>
		</tr>
		<tr>
		<td>CONTACT NUMBER</td>
		<td><input type="text" name="contact" class="form-control"></td>
		</tr>
		<tr>
			<td>E-MAIL ID</td>
			<td><input type="email" name="email" class="form-control"></td>
		</tr>
		<tr>
		    <td>PASSWORD</td>
			<td><input type="password" name="password" class="form-control"></td>
		</tr>
		<tr>
		    <td>CONFIRM PASSWORD</td>
		    <td><input type="password" name="confirm" class="form-control"></td>
		</tr>
        <tr>
        	<td></td>
        	<td><input type="submit" name="submit" value="REGISTER" class="btn btn-success"></td>
        </tr>
	</table>
</form>
</body>
</html>