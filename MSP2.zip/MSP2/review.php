<?php
include_once "settings/settings.php";
include_once "classes/userclass.php";
$obj=new userclass();
$key=$_GET['v'];
if(isset($_POST['hidden'])AND($_POST['hidden'])=='h')
{
if(isset($_POST['username'])AND($_POST['username'])!=null)
{
if(isset($_POST['contact'])AND($_POST['contact'])!=null)
{
if(isset($_POST['review'])AND($_POST['review'])!=null)
{
	
$a=trim($_POST['username']);
$b=trim($_POST['contact']);
$c=trim($_POST['review']);


$obj->reviewadd($a,$b,$c,$key);
}
else
echo"<script>alert('please enter the review')</script>";
}
else
echo"<script>alert('please enter the contact number')</script>";
}
else
echo"<script>alert('please enter your name')</script>";
}

$smartyObj->display("moviesingle.tpl");

?>