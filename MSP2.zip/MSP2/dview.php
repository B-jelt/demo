<?php
include_once "settings/settings.php";
include_once "classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$s=$obj->dview();
$smartyObj->assign("view",$s);
$smartyObj->display("adminheader.tpl");
$smartyObj->display("dview.tpl");
$smartyObj->display("adminfooter.tpl");
}
else{header("location:login.php");}
?>