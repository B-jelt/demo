<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

	
	
$smartyObj->assign("view",$s);

$smartyObj->display("moviesingle.tpl");


?>