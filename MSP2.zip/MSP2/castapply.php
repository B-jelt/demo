<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
$key1=$_GET['v'];

if(isset($_POST['hidden'])AND($_POST['hidden'])=='h')
{
if(isset($_POST['fullname'])AND($_POST['fullname'])!=null)
{
if(isset($_POST['address'])AND($_POST['address'])!=null)
{
if(isset($_POST['pincode'])AND($_POST['pincode'])!=null)
{
if(isset($_POST['district'])AND($_POST['district'])!=null)
{
if(isset($_POST['city'])AND($_POST['city'])!=null)
{
if(isset($_POST['gender'])AND($_POST['gender'])!=null)
{
if(isset($_POST['age'])AND($_POST['age'])!=null)
{
if(isset($_POST['contact'])AND($_POST['contact'])!=null)
{
if(isset($_POST['emailid'])AND($_POST['emailid'])!=null)	
{	

$a=trim($_POST['fullname']);
$b=trim($_POST['address']);
$c=trim($_POST['pincode']);
$d=trim($_POST['district']);
$e=trim($_POST['city']);
$f=trim($_POST['gender']);
$g=trim($_POST['age']);
$h=trim($_POST['contact']);
$i=trim($_POST['emailid']);

$obj->castapply($a,$b,$c,$d,$e,$f,$g,$h,$i,$_FILES['photo'],$key1);
}
else
echo"<script>alert('Please enter email')</script>";
}
else
echo"<script>alert('please enter the contact')</script>";
}
else
echo"<script>alert('please enter the age')</script>";
}
else
echo"<script>alert('please enter gender')</script>";
}
else
echo"<script>alert('please enter city')</script>";
}
else
echo"<script>alert('please enter the district')</script>";
}
else
echo"<script>alert('please enter the pincode')</script>";
}
else
echo"<script>alert('please enter the address')</script>";
}
else
echo"<script>alert('please enter the full name')</script>";
}
 
  $smartyObj->display("subheader.tpl");
  $smartyObj->display("castapply.tpl");
  $smartyObj->display("footer.tpl");


 	
?>

