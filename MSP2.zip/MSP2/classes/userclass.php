<?php
class userclass
{
	function addmovie($a,$b,$c,$d,$e,$i,$f,$g,$file=NULL)
{
	$key=uniquekey("newmovie","newkey");
	$date=date('Y-m-d');
		$query="insert into newmovie(newkey,picture,moviename,genres,hero,heroine,director,producer,moviedetails,releaseyear,currentdate)values('".$key."','".$file['name']."','".$a."','".$b."','".$c."','".$d."','".$e."','".$i."','".$f."','".$g."','".$date."')";
		// echo $query;exit;
		$h="uploads/".$key;
		
		$exe=mysql_query($query);
		if($exe)
		{
			mkdir($h);
			move_uploaded_file($file["tmp_name"],$h."/".$file["name"]);
			echo "<script>alert('submission completed')</script>";

		}
		else
			echo"<script>alert('submission incomplete')</script>";
}
	 
function moviedelete($key)
{
		$id=keytoid("newmovie","newkey",$key);
        $qry="delete from newmovie where id='".$id."'"; 
        // echo $qry;exit;      
            $exe=mysql_query($qry);
            if($exe)
            	{echo"<script>alert('deleted successfully')</script>";}
            header("location:movieview.php");
         
}
function movieedit($a,$b,$c,$d,$e,$i,$f,$g,$file=NULL,$key)
{
	// echo $key;exit;
			$id=keytoid("newmovie","newkey",$key);
			$date=date('Y-m-d');
            $qry="update newmovie set picture='".$file["name"]."',moviename='".$a."',genres='".$b."',hero='".$c."',heroine ='".$d."',director='".$e."',producer='".$i."',moviedetails='".$f."',releaseyear='".$g."',currentdate='".$date."' where id='".$id."'";
            // echo $qry;exit;
			$h="uploads/".$key;
			// mkdir($h);
			$exe=mysql_query($qry);
			if($exe)
			{
				move_uploaded_file($file["tmp_name"],$h."/".$file["name"]);
				echo "<script>alert('Updation completed')</script>";

			}
			else
				echo"<script>alert('Updation incomplete')</script>";
}
function movieview()
{
        // $id=keytoid("newmovie","newkey",$key); 
        $query="select * from newmovie";
    	$exe=mysql_query($query);
    	$ar=array();
    	while($x=mysql_fetch_array($exe))
    	 {
    	$path="uploads/".$x['newkey']."/".$x["picture"];
            $x['path']=$path;
            $ar[]=$x;# code...

    	}
    	return $ar;
}
function movieselect($key)
    {   
    	$id=keytoid("newmovie","newkey",$key);                                             
    	$query="select * from newmovie where id='".$id."'";
    	// echo $query;exit;
    	$exe=mysql_query($query);
    	$ar = array();
    	while($x=mysql_fetch_array($exe))
    	 {
    	$path="uploads/".$x['newkey']."/".$x["picture"];
            $x['path']=$path;
            $ar[]=$x;# code
    	}
    	return $ar;
    }
    function movies($key)
    {   
        $id=keytoid("newmovie","newkey",$key);                                             
        $query="select * from newmovie where id='".$id."'";
        // echo $query;exit;
        $exe=mysql_query($query);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
        $path="uploads/".$x['newkey']."/".$x["picture"];
            $x['path']=$path;
            $ar[]=$x;# code
        }
        return $ar;
    }

    function keysel()
    {
$query="select * from newmovie";
        // echo $query;exit;
        $exe=mysql_query($query);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
         $path="uploads/".$x['newkey']."/".$x['picture'];
            $x['path']=$path;
            $ar[]=$x;# code
        }
        return $ar;

    }

   function reviewadd($a,$b,$c,$key)
   {
    $id=keytoid("newmovie","newkey",$key);
    $key1=uniquekey("review","rkey");
    $date=date('Y-m-d');
        $query="insert into review(rkey,movieid,username,contactnum,review,currentdate)values('".$key1."','".$id."','".$a."','".$b."','".$c."','".$date."')";
        //echo $query;exit;
       
        $exe=mysql_query($query);
        if($exe)
        {
        
            echo "<script>alert('submission completed')</script>";

        }
        else
            echo"<script>alert('submission incomplete')</script>";

} 
  function reviewselect($key)
  {
    $id=keytoid("newmovie","newkey",$key);                                             
        $query="select * from review where movieid='".$id."' order by id desc ";
        // echo $query;exit;
        $exe=mysql_query($query);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;
            
  }
  function rating($d,$key)
  {
     $id=keytoid("newmovie","newkey",$key);                
     $qry="update newmovie set rating=(rating+'".$d."')/2 where id='".$id."'";
            // echo $qry;exit;
        $exe=mysql_query($qry);
        if($exe)
        {
        
            echo "<script>alert('rating completed')</script>";

        }
        else
            echo"<script>alert('rating incomplete')</script>";
}
function login($a)
        {   
     
            $otp=rand(999,9999);
          
           
            $qry="update login set otp='".$otp."'";
            $exe=mysql_query($qry);
            if($exe)
        {
            echo"<script>alert('submission completed and otp is $otp')</script>";

        }
        else
            echo"<script>alert('submission incomplete')</script>";
}
function checkotp($b)
{
    $qry="select otp from login where otp='".$b."'";
    $exe=mysql_query($qry);
    if($exe)
        {
            echo "<script>alert('Valid otp');
            window.location.href='admin.php';
            </script>";

        }
        else
            echo"<script>alert('submission incomplete')</script>";

}
function logincheck($a,$b)
{
    $enc=md5($b);
    $qry="select loginkey,email,password,status,usertype from login where email='".$a."'and password='".$enc."'" ;
     // echo $qry;exit();
           $exe=mysql_query($qry);
            $key=null;
             $status=null;
            $usertype=null;
            $c=0;
            while($rr=mysql_fetch_array($exe))
            {
                $key=$rr['loginkey'];
                $status=$rr['status'];
                $usertype=$rr['usertype'];
                $c=$c+1;
             }
             if($c>0)
             {

           if($status==1)
           {
            setcookie("loginkey",$key);
        setcookie("logined",1);
        if($usertype==0)
        {
                     echo "<script>alert('Authentication successfull');
            window.location.href='otp.php';
            </script>";
        }
        // header("location:adminhome.php");
    elseif($usertype==1)
        header("location:dhome.php");
}
else
            echo "<script>alert('waiting for admin approval')</script>";
}
else
    echo"<script>alert('invalid user')</script>"; 


    // }
    //     else
    //     {
    //         echo"<script>alert('submission incomplete')</script>";


    //         }
  
}
function dreg($a,$b,$c,$d,$e,$f,$file=NULL)
    {
        $enc=md5($f);
        $key=uniquekey("login","loginkey");
       // echo $key;exit;
        $query="insert into login(loginkey,email,password,usertype)values('".$key."','".$e."','".$enc."','1')";
        $exe=mysql_query($query);
        $rr=keytoid("login","loginkey",$key);
        $key1=uniquekey("director","dkey");
        $qry="insert into director(dkey,director,gender,age,contact,photo,loginid)values('".$key1."','".$a."','".$c."','".$b."','".$d."','".$file['name']."','".$rr."')";
        $h="uploads/".$key1;
        $exe1=mysql_query($qry);
       // echo $qry;exit;
        if($exe&&$exe1)
        {
            mkdir($h);
            move_uploaded_file($file["tmp_name"],$h."/".$file["name"]);
            echo "<script>alert('registration completed')</script>";
        }
        else
        {
            echo "<script>alert('registration unsuccessfull')</script>";
        }
}
  function profilesel($key)
    {
        $k=keytoid("login","loginkey",$key);
        // $id=keytoid("director","dkey",$key);
        $query="select * from director inner join login on director.loginid=login.id where login.id='".$k."'";
        // echo $query;exit;
        $exe=mysql_query($query);
        $ar=array();
        while($x=mysql_fetch_array($exe))
         {
         $path="uploads/".$x['dkey']."/".$x["photo"];
            $x['path']=$path;
            $ar[]=$x;# code
         }
        return $ar;

    }
    function profileupdate($a,$b,$c,$d,$e,$key,$file=NULL)
{
// echo $key;exit;
            $id=keytoid("login","loginkey",$key);
            $q="select dkey from director where loginid='".$id."'";
            $ee=mysql_query($q);
            $rrr=null;
            while ($kk=mysql_fetch_array($ee)) 
            {
                $rrr=$kk['dkey'];
            }
            // echo $id;exit;
            $qry1="update login set email='".$e."' where id='".$id."'";
            // echo $qry1;exit;
            $exe1=mysql_query($qry1);
            $date=date('Y-m-d');
            $qry="update director set director='".$a."',age='".$b."',gender='".$c."',contact='".$d."',photo='".$file["name"]."' where loginid='".$id."'";
            // echo $qry;exit;
            $h="uploads/".$rrr;
            // mkdir($h);
            $exe=mysql_query($qry);
            if($exe&&$exe1)
            {
                move_uploaded_file($file["tmp_name"],$h."/".$file["name"]);
                echo "<script>alert('Updation completed')</script>";

            }
            else
                echo"<script>alert('Updation incomplete')</script>";
}
    function dview()
    {
        $query="select * from director inner join login on director.loginid=login.id";
        // echo $query;exit;
        $exe=mysql_query($query);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
         $path="uploads/".$x['dkey']."/".$x["photo"];
            $x['path']=$path;
            $ar[]=$x;# code
        }
        return $ar;

    }
    function approve($key)
{
    $k=keytoid("login","loginkey",$key);
    $query="update login set status='1' where id='".$k."'";
    //echo $query;exit;
    $exe=mysql_query($query);
    if($exe)
    { 
        header("location:dview.php");
}
else
{
    echo"<script>alert('Approval unsuccessfull')</script>";
}
}
function reject($key)
{
    $k=keytoid("login","loginkey",$key);
    $query="update login set status='2' where id='".$k."'";
    //echo $query;exit;
    $exe=mysql_query($query);
    if($exe)
    {
        
        echo"<script>alert('rejected successfully');
        window.location.href='dview.php';
            </script>";


        
    }
else
    echo "<script>alert('Rejection unsuccessfull')</script>";
}
function dcast($a,$b,$c,$d,$e,$f,$key)
{
    $id=keytoid("login","loginkey",$key);
    $key1=uniquekey("cast1","ckey");
    $date=date('Y-m-d');
    $query="insert into cast1(ckey,category,agefrom,ageto,gender,lastdate,details,loginid,currentdate)values('".$key1."','".$a."','".$b."','".$c."','".$d."','".$e."','".$f."','".$id."','".$date."')";
        // echo $query;exit;
       
        $exe=mysql_query($query);
        if($exe)
        {
        
            echo "<script>alert('submission completed')</script>";

        }
        else
            echo"<script>alert('submission incomplete')</script>";

}

function dcastselect($key)
    {
        $k=keytoid("login","loginkey",$key);
       
        $query="select * from cast1 where loginid='".$k."'";
        // echo $query;exit;
        $exe=mysql_query($query);
        $ar=array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;
                }
       function dcastupdate($a,$b,$c,$d,$e,$f,$key1)
{
    // echo $key;exit;
            $id=keytoid("cast1","ckey",$key1);
            $date=date('Y-m-d');
            $qry="update cast1 set category='".$a."',agefrom='".$b."',ageto='".$c."',gender='".$d."',lastdate='".$e."',details='".$f."',currentdate='".$date."' where id='".$id."'";
            // echo $qry;exit;
           
            // mkdir($h);
            $exe=mysql_query($qry);
            if($exe)
            {
                 echo "<script>alert('Updation completed')</script>";

            }
            else
                echo"<script>alert('Updation incomplete')</script>";
}
 function dcastselect1($key1)
 {
        $id=keytoid("cast1","ckey",$key1);                                             
        $query="select * from cast1 where id='".$id."'";
        // echo $query;exit;
        $exe=mysql_query($query);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;
   
 }
 function dcastdelete($key)
{
    
        $id=keytoid("cast1","ckey",$key);
        $qry="delete from cast1 where id='".$id."'"; 
        // echo $qry;exit;      
            $exe=mysql_query($qry);
            if($exe)
                {echo"<script>alert('deleted successfully')</script>";}
            header("location:dcastedit.php");
         

}
function castview()
{
      // $id=keytoid("cast1","ckey",$key1);                                             
      $query="select * from cast1 inner join director on cast1.loginid=director.loginid";
       
        // echo $query;exit;
        $exe=mysql_query($query);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;

}
function castapply($a,$b,$c,$d,$e,$f,$g,$h,$i,$file=NULL,$key1)
{
    $key=uniquekey("castapply","cakey");
    $id=keytoid("cast1","ckey",$key1);
    $date=date('Y-m-d');
    $r=time();
        $query="insert into castapply(cakey,fullname,address,pincode,district,city,gender,age,photo,contact,emailid,castid,currentdate,regid)values('".$key."','".$a."','".$b."','".$c."','".$d."','".$e."','".$f."','".$g."','".$file['name']."','".$h."','".$i."','".$id."','".$date."','".$r."')";
        //echo $query;exit;
        $j="uploads/".$key;
        
        $exe=mysql_query($query);
        if($exe)
        {
            mkdir($j);
            move_uploaded_file($file["tmp_name"],$j."/".$file["name"]);
            echo "<script>alert('submission completed, please note your Register id:$r')</script>";
      

        }
        else
            echo"<script>alert('submission incomplete')</script>";
}

function applydview($key)
{
      

        $id=keytoid("login","loginkey",$key); 
        $query="select * from castapply inner join cast1 on cast1.id=castapply.castid where cast1.loginid='".$id."'";
        $exe=mysql_query($query);
        $ar=array();
        while($x=mysql_fetch_array($exe))
         {
            $path="uploads/".$x['cakey']."/".$x["photo"];
            $x['path']=$path;
            $ar[]=$x;# code...

        }
        return $ar;
}
function approveapp($key)
{
    $k=keytoid("castapply","cakey",$key);
    $query="update castapply set status='1' where id='".$k."'";
    //echo $query;exit;
    $exe=mysql_query($query);
    if($exe)
    { 
        header("location:applydview.php");
}
else
{
    echo"<script>alert('Approval unsuccessfull')</script>";
}
}
function rejectapp($key)
{
    $k=keytoid("castapply","cakey",$key);
    $query="update castapply set status='2' where id='".$k."'";
    //echo $query;exit;
    $exe=mysql_query($query);
    if($exe)
    {
        echo"<script>alert('rejected successfully');
        window.location.href='applydview.php';
            </script>"; 
    }
else
    echo "<script>alert('Rejection unsuccessfull')</script>";
}
function applicationlist($a)
{
    $query="select * from castapply inner join cast1 on castapply.castid=cast1.id where castapply.regid='".$a."'";
       
        // echo $query;exit;
        $exe=mysql_query($query);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;

}

function hero()
{
    $qry="select distinct hero from movie";
      // echo $query;exit;
        $exe=mysql_query($qry);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;
}
function heroine()
{
    $qry="select distinct heroine from movie";
      // echo $query;exit;
        $exe=mysql_query($qry);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;
}
function director()
{
    $qry="select distinct director from movie";
      // echo $query;exit;
        $exe=mysql_query($qry);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;
}
function producer()
{
    $qry="select distinct producer from movie";
      // echo $query;exit;
        $exe=mysql_query($qry);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;
}
function musician()
{
    $qry="select distinct musician from movie";
      // echo $query;exit;
        $exe=mysql_query($qry);
        $ar = array();
        while($x=mysql_fetch_array($exe))
         {
            $ar[]=$x;
        }
        return $ar;
}

 function success_rate($a,$b,$c,$d,$e)
    {
            
        $qry="select count(id) from movie where director='".$c."'";
      // echo $query;exit;
        $exe=mysql_query($qry);
        $dir = null;
        while($x=mysql_fetch_array($exe))
         {
            $dir=$x['count(id)'];
        }
        $qry1="select count(id) from movie where director='".$c."' and result='hit'";
      // echo $query;exit;
        $exe1=mysql_query($qry1);
        $dir_hit = null;
        while($x1=mysql_fetch_array($exe1))
         {
            $dir_hit=$x1['count(id)'];
        }
        
       
        if($dir==0 || $dir_hit)
        $avg_dir=($dir_hit/$dir)*100;
        $qry2="select count(id) from movie where hero='".$a."'";
      // echo $query;exit;
        $exe2=mysql_query($qry2);
        $hero = null;
        while($x2=mysql_fetch_array($exe2))
         {
            $hero=$x2['count(id)'];
        }
        $qry3="select count(id) from movie where hero='".$a."' and result='hit'";
      // echo $query;exit;
        $exe3=mysql_query($qry3);
        $hero_hit = null;
        while($x3=mysql_fetch_array($exe3))
         {
            $hero_hit=$x3['count(id)'];
        }
        //echo $hero_hit;exit;
        $avg_hero=($hero_hit/$hero)*100;
         $qry4="select count(id) from movie where heroine='".$b."'";
      // echo $query;exit;
        $exe4=mysql_query($qry4);
        $heroine = null;
        while($x4=mysql_fetch_array($exe4))
         {
            $heroine=$x4['count(id)'];
        }
        $qry5="select count(id) from movie where heroine='".$b."' and result='hit'";
      // echo $query;exit;
        $exe5=mysql_query($qry5);
        $heroine_hit = null;
        while($x3=mysql_fetch_array($exe5))
         {
            $heroine_hit=$x5['count(id)'];
        }
        $avg_heroine=($heroine_hit/$heroine)*100;
         $qry6="select count(id) from movie where musician='".$a."'";
      // echo $query;exit;
        $exe6=mysql_query($qry6);
        $music = null;
        while($x2=mysql_fetch_array($exe6))
         {
            $music=$x6['count(id)'];
        }
        $qry7="select count(id) from movie where musician='".$a."' and result='hit'";
      // echo $query;exit;
        $exe7=mysql_query($qry7);
        $music_hit = null;
        while($x7=mysql_fetch_array($exe7))
         {
            $musician=$x7['count(id)'];
        }
        $avg_music=($music_hit/$music)*100;
         $qry8="select count(id) from movie where producer='".$a."'";
      // echo $query;exit;
        $exe8=mysql_query($qry8);
        $produ = null;
        while($x8=mysql_fetch_array($exe8))
         {
            $produ=$x8['count(id)'];
        }
        $qry9="select count(id) from movie where producer='".$a."' and result='hit'";
      // echo $query;exit;
        $exe9=mysql_query($qry9);
        $produ_hit = null;
        while($x9=mysql_fetch_array($exe9))
         {
            $produ_hit=$x9['count(id)'];
        }
        $avg_produ=($produ_hit/$produ)*100;
        $hit_avg=($avg_dir+$avg_hero+$avg_heroine+$avg_music+$avg_produ)/5;
        //echo $hit_avg;exit;
        $flop_avg=100-$hit_avg;

       header("location:result.php?hit_avg=$hit_avg && flop_avg=$flop_avg");
    
    }



}

             
?>