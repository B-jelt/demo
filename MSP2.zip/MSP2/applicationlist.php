<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
if(isset($_POST['hidden'])AND($_POST['hidden'])=='h')
{
if(isset($_POST['register'])AND($_POST['register'])!=null)
{	
$a=trim($_POST['register']);

$s=$obj->applicationlist($a);
$smartyObj->assign("view",$s);
}
else
echo"<script>alert('please enter the register id')</script>";
}
 $smartyObj->display("subheader.tpl");
 $smartyObj->display("applicationlist.tpl");
 $smartyObj->display("footer.tpl");	
?>

