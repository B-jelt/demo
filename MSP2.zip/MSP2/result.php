<br><br>
<html>
  <head>
 <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
 <script>
 	<?php 
 	$rate=$_GET['hit_avg'];
 	$flop=$_GET['flop_avg'];
 	?>
window.onload = function() {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Success Rate"
	},
	data: [{
		type: "pie",
		startAngle: 240,
		yValueFormatString: "##0.00\"%\"",
		indexLabel: "{label} {y}",
		dataPoints: [
			{y: <?php echo $rate; ?>, label: "Hit"},
			{y: <?php echo $flop; ?>, label: "Flop"}

			
		]
	}]
});
chart.render();

}
</script>
	</head>
  <body>


	<center>

          <br><br>
<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>

          </center>
    
</body>
</head>
</html>
<br><br>