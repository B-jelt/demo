<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
$s=$obj->keysel();
$smartyObj->assign("view",$s);
$smartyObj->display("index.tpl");


?>
