<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
if(isset($_POST['hidden'])AND($_POST['hidden'])=='h')
{
if(isset($_POST['email'])AND($_POST['email'])!=null)
{
if(isset($_POST['password'])AND($_POST['password'])!=null)
{
$a=trim($_POST['email']);
$b=trim($_POST['password']);
$obj->logincheck($a,$b);
}
else
echo"<script>alert('invalid password')</script>";
}
else
echo"<script>alert('invalid email')</script>";
}
$smartyObj->display("login.tpl");
?>
