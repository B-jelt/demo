<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
if(isset($_POST['hidden'])AND($_POST['hidden'])=='h')
{
if(isset($_POST['mobilenumber'])AND($_POST['mobilenumber'])!=null)
{
	
$a=trim($_POST['mobilenumber']);
$obj->login($a);
}
else
echo"<script>alert('please enter the mobile number')</script>";
}

if(isset($_POST['hidden1'])AND($_POST['hidden1'])=='h')
{
if(isset($_POST['otp'])AND($_POST['otp'])!=null)
{
	$b=trim($_POST['otp']);
	$obj->checkotp($b);
}
else
echo"<script>alert('please enter the otp')</script>";
}
$smartyObj->display("otp.tpl");
?>
