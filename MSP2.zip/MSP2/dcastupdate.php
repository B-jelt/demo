<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
$key=$_COOKIE['loginkey'];
$key1=$_GET['v'];
$k=$obj->dcastselect1($key1);
$smartyObj->assign("view",$k);
if(isset($_POST['hidden'])AND($_POST['hidden'])=='h')
{
if(isset($_POST['category'])AND($_POST['category'])!=null)
{
if(isset($_POST['agefrom'])AND($_POST['agefrom'])!=null)
{
if(isset($_POST['ageto'])AND($_POST['ageto'])!=null)
{
if(isset($_POST['gender'])AND($_POST['gender'])!=null)
{
if(isset($_POST['lastdate'])AND($_POST['lastdate'])!=null)
{
if(isset($_POST['details'])AND($_POST['details'])!=null)
{	

$a=trim($_POST['category']);
$b=trim($_POST['agefrom']);
$c=trim($_POST['ageto']);
$d=trim($_POST['gender']);
$e=trim($_POST['lastdate']);
$f=trim($_POST['details']);



$obj->dcastupdate($a,$b,$c,$d,$e,$f,$key1);
}
else
echo"<script>alert('please enter the details')</script>";
}
else
echo"<script>alert('please enter lastdate')</script>";
}
else
echo"<script>alert('please enter the gender')</script>";
}
else
echo"<script>alert('please enter the age to')</script>";
}
else
echo"<script>alert('please enter the age from')</script>";
}
else
echo"<script>alert('please enter the category')</script>";
}

 $smartyObj->display("dhomeheader.tpl");
 $smartyObj->display("dcastupdate.tpl");
 $smartyObj->display("dhomefooter.tpl");	
?>

