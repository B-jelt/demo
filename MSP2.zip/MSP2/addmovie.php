<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
if(isset($_POST['hidden'])AND($_POST['hidden'])=='h')
{
if(isset($_POST['moviename'])AND($_POST['moviename'])!=null)
{
if(isset($_POST['genres'])AND($_POST['genres'])!=null)
{
if(isset($_POST['hero'])AND($_POST['hero'])!=null)
{
if(isset($_POST['heroine'])AND($_POST['heroine'])!=null)
{
if(isset($_POST['director'])AND($_POST['director'])!=null)
{
if(isset($_POST['producer'])AND($_POST['producer'])!=null)
{
if(isset($_POST['moviedetails'])AND($_POST['moviedetails'])!=null)
{
if(isset($_POST['releaseyear'])AND($_POST['releaseyear'])!=null)
{	
$a=trim($_POST['moviename']);
$b=trim($_POST['genres']);
$c=trim($_POST['hero']);
$d=trim($_POST['heroine']);
$e=trim($_POST['director']);
$i=trim($_POST['producer']);
$f=trim($_POST['moviedetails']);
$g=trim($_POST['releaseyear']);


$obj->addmovie($a,$b,$c,$d,$e,$i,$f,$g,$_FILES['picture']);
}
else
echo"<script>alert('Please enter release year')</script>";
}
else
echo"<script>alert('please enter the movie details')</script>";
}
else
echo"<script>alert('please enter the producer name')</script>";
}
else
echo"<script>alert('please enter the director name')</script>";
}
else
echo"<script>alert('please enter the heroine')</script>";
}
else
echo"<script>alert('please enter the hero name')</script>";
}
else
echo"<script>alert('please enter the genres')</script>";
}
else
echo"<script>alert('please enter the movie name')</script>";
}

 $smartyObj->display("adminheader.tpl");
 $smartyObj->display("addmovie.tpl");
 $smartyObj->display("adminfooter.tpl");
}
 else
{
	Header("location:login.php");
}	
?>

