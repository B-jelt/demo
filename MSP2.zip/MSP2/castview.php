<?php
include_once "settings/settings.php";
include_once "classes/userclass.php";
$obj=new userclass();
{
$s=$obj->castview();
$smartyObj->assign("view",$s);
$smartyObj->display("subheader.tpl");
$smartyObj->display("castview.tpl");
$smartyObj->display("footer.tpl");
}
?>