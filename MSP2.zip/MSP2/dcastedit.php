<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$key=$_COOKIE['loginkey'];
// $key1=$_GET['v'];


$s=$obj->dcastselect($key);
$smartyObj->assign("view",$s);
$smartyObj->display("dhomeheader.tpl");
$smartyObj->display("dcastedit.tpl");
$smartyObj->display("dhomefooter.tpl");	
}
else{header("location:login.php");}
?>

