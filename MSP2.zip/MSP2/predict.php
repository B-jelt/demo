<?php
include_once "settings/settings.php";
include_once "classes/userclass.php";
$obj=new userclass();
	
//$key=$_GET['v'];
$hero=$obj->hero();
$smartyObj->assign("hero",$hero);
$heroine=$obj->heroine();
$smartyObj->assign("heroine",$heroine);
$director=$obj->director();
$smartyObj->assign("director",$director);
$producer=$obj->producer();
$smartyObj->assign("producer",$producer);
$musician=$obj->musician();
$smartyObj->assign("musician",$musician);
if(isset($_POST['hidden'])AND($_POST['hidden'])=='h')
{
if(isset($_POST['hero'])AND($_POST['hero'])!=null)
{
if(isset($_POST['heroine'])AND($_POST['heroine'])!=null)
{
if(isset($_POST['director'])AND($_POST['director'])!=null)
{
	if(isset($_POST['producer'])AND($_POST['producer'])!=null)
{
	
		if(isset($_POST['musician'])AND($_POST['musician'])!=null)
{
	
$a=trim($_POST['hero']);
$b=trim($_POST['heroine']);
$c=trim($_POST['director']);
$d=trim($_POST['producer']);
$e=trim($_POST['musician']);
$obj->success_rate($a,$b,$c,$d,$e);
//$obj->predict($a,$b,$c,$d,$e,$key);

}
else
echo"<script>alert('please enter the musician')</script>";
}
else
echo"<script>alert('please enter the producer')</script>";
}
else
echo"<script>alert('please enter the director')</script>";
}
else
echo"<script>alert('please enter the heroine')</script>";
}
else
echo"<script>alert('please enter the hero')</script>";
}
$smartyObj->display("subheader.tpl");
$smartyObj->display("predict.tpl");
$smartyObj->display("footer.tpl");

?>
                                                 
