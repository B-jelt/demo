<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];

$h=$obj->adminextensionview();
$smartyObj->assign("adminextensionview",$h);

$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('extensionview.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>