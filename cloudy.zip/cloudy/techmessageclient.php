<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];
$name=$_GET['name'];

$s=$obj->clientprofileview($key);
$smartyObj->assign("view",$s);

$f=$obj->techviewclientmessages($key,$name);
$smartyObj->assign("viewmessages",$f);

$f=$obj->techviewclientreplies($key,$name);
$smartyObj->assign("viewreplies",$f);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

        if(isset($_POST['message'])AND($_POST['message'])!=null)
	    {
            $a=trim($_POST['message']);
            $obj->techmessageclient($a,$name,$key);
        
        }  
        else				
            echo "<script> alert('message is empty!')</script>";					
}


$smartyObj->display('techmanagermainheader.tpl');
$smartyObj->display('techmessageclient.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>