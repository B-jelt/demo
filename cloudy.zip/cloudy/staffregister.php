<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$smartyObj->display('adminmainheader.tpl');

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['staffname'])AND($_POST['staffname'])!=null)
	{

        if (preg_match('/^[A-Z a-z]*$/', $_POST['staffname']))
		{

            if(isset($_POST['designation'])AND($_POST['designation'])!=null)
            {

                if(isset($_POST['contactno'])AND($_POST['contactno'])!=null)
                {

                    if (preg_match('/^[0-9]*$/', $_POST['contactno']))	
                    {

                        $nm1=strlen($_POST['contactno']);
                        if($nm1>=10 and $nm1<=12)
                        {

                            if(isset($_POST['email'])AND($_POST['email'])!=null)
                            {

                                        $a=trim($_POST['staffname']);
                                        $b=trim($_POST['designation']);
                                        $c=trim($_POST['contactno']);
                                        $g=trim($_POST['email']);
                                        $obj->staffregister($a,$b,$c,$g);

                            }
                            else
                                echo"<script>alert('email is empty')</script>";
                    }
                    else
                        echo"<script>alert('Enter atleast 10 - 12 numbers')</script>";
                }
                else
                    echo"<script>alert('contact no. is empty')</script>";
            }
            else
                echo"<script>alert('organization name is empty!')</script>";
        }
        else
            echo"<script>alert('Please enter only alphabets for naem!')</script>";
    }
    else				
        echo "<script> alert('name is empty!')</script>";					
}
}


$smartyObj->display('staffregister.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}

?>