<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['hostingplan'])AND($_POST['hostingplan'])!=null)
	{

        if(isset($_POST['amount'])AND($_POST['amount'])!=null)
	    {

            if(isset($_POST['ramspace'])AND($_POST['ramspace'])!=null)
	        {

                if(isset($_POST['bandwidth'])AND($_POST['bandwidth'])!=null)
                {

                    if(isset($_POST['storage'])AND($_POST['storage'])!=null)
                    {

                        if(isset($_POST['dbnumber'])AND($_POST['dbnumber'])!=null)
                        {

                            if(isset($_POST['otherdetails'])AND($_POST['otherdetails'])!=null)
                            {

                                $a=trim($_POST['hostingplan']);
                                $b=trim($_POST['amount']);
                                $c=trim($_POST['ramspace']);
                                $d=trim($_POST['bandwidth']);
                                $e=trim($_POST['storage']);
                                $f=trim($_POST['dbnumber']);
                                $g=trim($_POST['otherdetails']);
                                $obj->hostingplans($a,$b,$c,$d,$e,$f,$g);

                            }
                        
                            else
                                echo"<script>alert('otherdetails is empty')</script>";
                            }

                        else
                            echo"<script>alert('dbnumber is empty')</script>";
                        }
                            
                    else
                        echo"<script>alert('storage is empty')</script>";
                    }

                else
                    echo"<script>alert('bandwidth is empty')</script>";
                }

            else
                echo"<script>alert('ramspace is empty')</script>";
            }

        else
            echo"<script>alert('amount name is empty!')</script>";
        }
        
    else				
        echo "<script> alert('hostingplan is empty!')</script>";					
    }
    
$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('hostingplans.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}

?>