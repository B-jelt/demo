<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];

$e=$obj->extensionview($key);
$smartyObj->assign("extension",$e);

$r=$obj->renewplannotification($key);
$smartyObj->assign("renewplan",$r);


$s=$obj->clientplanview($key);
$smartyObj->assign("clientplanview",$s); 

$s=$obj->clientprofileview($key);
$smartyObj->assign("view",$s);

$s=$obj->profilepictureview($key);
$smartyObj->assign("profilepictureview",$s);

$h=$obj->hostingplansview();
$smartyObj->assign("hostingplans",$h);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['domainname'])AND($_POST['domainname'])!=null)
    {

        if(isset($_POST['extension'])AND($_POST['extension'])!=null)
        {

            $a=trim($_POST['domainname']);
            $b=trim($_POST['extension']);
            // $domain=$a.$b;
        
            $d=$obj->domainview($a,$b);
            $smartyObj->assign("domain",$d);
            $smartyObj->assign("domainname",$a);
            $smartyObj->assign("extension",$b);


        }
        else
            echo"<script>alert('extension is empty')</script>";
    }
    else
        echo"<script>alert('domain name is empty')</script>";
}


$smartyObj->display('clientmainheader.tpl');
$smartyObj->display('client.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>