<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$month = $_GET['key'];

$e=$obj->monthlyincomeview($month);
$smartyObj->assign("monthlyincomeview",$e);

$smartyObj->display('financemanagermainheader.tpl');
$smartyObj->display('financemanagermonthlyincomeview.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}

?>