<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE["loginkey"];
$amount=$_GET['amount'];
$productid = $_GET['id'];


if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	if(isset($_POST['nameoncard'])AND($_POST['nameoncard'])!=null)
	{
		if(isset($_POST['cardnumber'])AND($_POST['cardnumber'])!=null)
		{
			if(isset($_POST['expirymonth'])AND($_POST['expirymonth'])!=null)
			{
				if(isset($_POST['expiryyear'])AND($_POST['expiryyear'])!=null)
				{
					if(isset($_POST['cvv'])AND($_POST['cvv'])!=null)
		
					{
						$a=trim($_POST['nameoncard']);
						$b=trim($_POST['cardnumber']);
						$c=trim($_POST['expirymonth']);
						$d=trim($_POST['expiryyear']);
						$e=trim($_POST['cvv']);
						$obj->payment($a,$b,$c,$d,$e,$key,$amount,$productid);
					}
				
				else
					echo"<script>alert('nameoncard is empty')</script>";
				}
				else
					echo"<script>alert('cardnumber is empty')</script>";
				}
				else
					echo"<script>alert('expiremonth is empty')</script>";
				}
				
				else
					echo"<script>alert('expireyear is empty')</script>";
				}
				else
					echo"<script>alert('cvv is empty')</script>";
				}

	// $smartyObj->display('clientmainheader.tpl');
	$smartyObj->display('payment.tpl');
	// $smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}

?>