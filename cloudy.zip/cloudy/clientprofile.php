<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];

$s=$obj->clientprofileview($key);
$smartyObj->assign("view",$s);

$s=$obj->profilepictureview($key);
$smartyObj->assign("profilepictureview",$s);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['name'])AND($_POST['name'])!=null)
	{

        if(isset($_POST['orgname'])AND($_POST['orgname'])!=null)
	    {

            if(isset($_POST['address'])AND($_POST['address'])!=null)
            {
          
                if(isset($_POST['contactno'])AND($_POST['contactno'])!=null)
                {
                    
                    if(isset($_POST['email'])AND($_POST['email'])!=null)
                    {

                                $a=trim($_POST['name']);
                                $b=trim($_POST['orgname']);
                                $d=trim($_POST['address']);
                                $c=trim($_POST['contactno']);
                                $g=trim($_POST['email']);
                                $obj->clientprofileupdate($a,$b,$d,$c,$g,$key);
                                $obj->profilepictureupload($_FILES['profilepicture'],$key);

                    }
                    else
                        echo"<script>alert('email is empty')</script>";
                }

                else
                    echo"<script>alert('contact no. is empty')</script>";
            }

            else
                echo"<script>alert('address is empty')</script>";
        }

        else
            echo"<script>alert('organization name is empty!')</script>";
    }
            
    else				
        echo "<script> alert('name is empty!')</script>";

}

$smartyObj->display('clientmainheader.tpl');
$smartyObj->display('clientprofile.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>