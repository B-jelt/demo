<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['month'])AND($_POST['month'])!=null)
	{

       
            $a=trim($_POST['month']);
            $e=$obj->monthlyincome($a);
            $smartyObj->assign("monthlyincome",$e);

      
    }    
    else				
        echo "<script> alert('month is empty!')</script>";					
}


$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('monthlyincome.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}

?>