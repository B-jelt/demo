<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_GET['k'];
//$key=$_COOKIE['loginkey'];
$s=$obj->adminstaffview($key);
$smartyObj->assign("view",$s);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['staffname'])AND($_POST['staffname'])!=null)
	{

        if(isset($_POST['designation'])AND($_POST['designation'])!=null)
	    {
          
                if(isset($_POST['contactno'])AND($_POST['contactno'])!=null)
                {
                    
                    if(isset($_POST['email'])AND($_POST['email'])!=null)
                    {

                        $a=trim($_POST['staffname']);
                        $b=trim($_POST['designation']);
                        $c=trim($_POST['contactno']);
                        $g=trim($_POST['email']);
                        $obj->adminstaffupdate($a,$b,$c,$g,$key);
                        
                    }
                    else
                        echo"<script>alert('email is empty')</script>";
                    }

                else
                    echo"<script>alert('contact no. is empty')</script>";
                }

            

        else
            echo"<script>alert('designation is empty!')</script>";
        }
            
    else				
        echo "<script> alert('staff name is empty!')</script>";					
    }

$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('adminstaffedit.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>