<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];
$name=$_GET['name'];
$designation=$_GET['designation'];

$s=$obj->clientprofileview($key);
$smartyObj->assign("view",$s);

$f=$obj->adminviewstaffmessages($key,$name,$designation);
$smartyObj->assign("viewmessages",$f);

$f=$obj->adminviewstaffreplies($key,$name,$designation);
$smartyObj->assign("viewreplies",$f);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

        if(isset($_POST['message'])AND($_POST['message'])!=null)
	    {
            $a=trim($_POST['message']);
            $obj->adminmessagestaff($a,$name,$designation,$key);
        
        }  
        else				
            echo "<script> alert('message is empty!')</script>";					
}


$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('adminmessagestaff.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>