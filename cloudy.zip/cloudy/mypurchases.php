<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];

$s=$obj->clientprofileview($key);
$smartyObj->assign("view",$s);

$s=$obj->profilepictureview($key);
$smartyObj->assign("profilepictureview",$s);

$d=$obj->clientdomainview($key);
$smartyObj->assign("clientdomainview",$d);

$p=$obj->clientplanview($key);
$smartyObj->assign("clientplanview",$p);

$z=$obj->admindomainview();
$smartyObj->assign("admindomainview",$z);

$smartyObj->display('clientsubheader.tpl');
$smartyObj->display('mypurchases.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>