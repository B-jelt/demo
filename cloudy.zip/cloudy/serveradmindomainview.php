<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];

$z=$obj->admindomainview();
$smartyObj->assign("admindomainview",$z);

$smartyObj->display('serveradminmainheader.tpl');
$smartyObj->display('serveradmindomainview.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>