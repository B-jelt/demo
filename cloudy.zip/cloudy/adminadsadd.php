<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$key=$_COOKIE['loginkey'];

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['company'])AND($_POST['company'])!=null)
	{

       
            $a=trim($_POST['company']);
            $obj->advertisement($a,$_FILES['image']);

      
    }    
    else				
        echo "<script> alert('company is empty!')</script>";					
}
    
$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('adminadsadd.tpl');
$smartyObj->display('footer.tpl');
}
else
{	
	Header("location:index.php");
}

?>