<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

$e=$obj->indexextensionview();
$smartyObj->assign("extension",$e);

$h=$obj->hostingplansview();
$smartyObj->assign("hostingplans",$h);

$s=$obj->indexadsview();
$smartyObj->assign("indexadsview",$s);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['domainname'])AND($_POST['domainname'])!=null)
    {

        if(isset($_POST['extension'])AND($_POST['extension'])!=null)
        {

            $a=trim($_POST['domainname']);
            $b=trim($_POST['extension']);
            $d=$obj->domainview($a,$b);
            $smartyObj->assign("domain",$d);

        }
        else
            echo"<script>alert('extension is empty')</script>";
    }
    else
        echo"<script>alert('domain name is empty')</script>";
}

$smartyObj->display('index.tpl');
?>