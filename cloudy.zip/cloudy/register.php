`<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['name'])AND($_POST['name'])!=null)
	{

        if (preg_match('/^[A-Z a-z]*$/', $_POST['name']))
		{

            if(isset($_POST['orgname'])AND($_POST['orgname'])!=null)
            {

                if(isset($_POST['contactno'])AND($_POST['contactno'])!=null)
                {

                    if (preg_match('/^[0-9]*$/', $_POST['contactno']))	
                    {
                        $nm1=strlen($_POST['contactno']);
                        if($nm1>=10 and $nm1<=12)
                        {

                            if(isset($_POST['email'])AND($_POST['email'])!=null)
                            {

                                if(isset($_POST['pass'])AND($_POST['pass'])!=null)
                                {

                                    $a=trim($_POST['name']);
                                    $b=trim($_POST['orgname']);
                                    $c=trim($_POST['contactno']);
                                    $g=trim($_POST['email']);
                                    $h=trim($_POST['pass']);
                                    $obj->cloudy($a,$b,$c,$g,$h);

                                }
                                        
                                else
                                    echo"<script>alert('password is empty')</script>";
                            }
                            else
                                echo"<script>alert('email is empty')</script>";
                        }
                        else
                            echo"<script>alert('Enter atleast 10 to 12 numbers')</script>";
                    }
                    else
                        echo"<script>alert('contact no. is empty')</script>";
                }
                else
                    echo"<script>alert('organization name is empty!')</script>";
            }
            else				
                echo "<script> alert('Use only alphabets for the name!')</script>";					
        }
        else				
            echo "<script> alert('name is empty!')</script>";					
    }
}

$smartyObj->display('register.tpl');
?>