<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];
$s=$obj->clientprofileview($key);
$smartyObj->assign("view",$s);

$s=$obj->profilepictureview($key);
$smartyObj->assign("profilepictureview",$s);

$f=$obj->clientfeedbackview($key);
$smartyObj->assign("feedback",$f);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['title'])AND($_POST['title'])!=null)
	{

        if(isset($_POST['feedback'])AND($_POST['feedback'])!=null)
	    {
            $a=trim($_POST['title']);
            $b=trim($_POST['feedback']);
            $obj->clientfeedback($a,$b,$key);
        }
        else
            echo"<script>alert('title is empty!')</script>";
        
    }  
    else				
        echo "<script> alert('feedback is empty!')</script>";					
    }
$smartyObj->display('clientsubheader.tpl');
$smartyObj->display('clientfeedback.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>