<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];

$s=$obj->adminadsview();
$smartyObj->assign("adminadsview",$s);

$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('adminadsview.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>