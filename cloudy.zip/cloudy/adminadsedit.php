<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];
$key1 = $_GET['key'];

$h=$obj->adminadseditview($key1);
$smartyObj->assign("adminadseditview",$h);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['company'])AND($_POST['company'])!=null)
	{

       
            $a=trim($_POST['company']);
            $obj->advertisementedit($a,$_FILES['image'],$key1);
      
    }    
    else				
        echo "<script> alert('company is empty!')</script>";					
}
    
$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('adminadsedit.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}

?>