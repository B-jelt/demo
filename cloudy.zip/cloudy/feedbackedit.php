`<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];
$key1=$_GET['key'];

$f=$obj->feedbackeditview($key1);
$smartyObj->assign("feedback",$f);

$s=$obj->clientprofileview($key);
$smartyObj->assign("view",$s);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['title'])AND($_POST['title'])!=null)
	{

        if(isset($_POST['feedback'])AND($_POST['feedback'])!=null)
	    {
            $a=trim($_POST['title']);
            $b=trim($_POST['feedback']);
            $obj->feedbackedit($a,$b,$key1);
        }
        else
            echo"<script>alert('title is empty!')</script>";
        
    }  
    else				
        echo "<script> alert('feedback is empty!')</script>";					
    }
$smartyObj->display('clientmainheader.tpl');
$smartyObj->display('feedbackedit.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}

?>