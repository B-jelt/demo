<?php
	$dbpath="localhost";
	$dbusername="root";
	$dbpassword="";
	$dbname="cloudy";
?>