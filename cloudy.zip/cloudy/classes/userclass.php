<?php
class userclass
{
	function cloudy($a,$b,$c,$g,$h)  //client register
   {
      $enc=md5($h);
      $key1=uniquekey("login","loginkey");
      $qry1="insert into login(loginkey,email,password,usertype,status)values('".$key1."', '".$g."', '".$enc."','2','0')";
      $exe1=mysql_query($qry1);

      $cid=time();
      $pin=rand(999,9999);
      $key=uniquekey("register","cloudkey");
      $id=keytoid("login","loginkey",$key1);
      $qry="insert into register(cloudkey,name,orgname,contactno,custid,pin,loginid)values('".$key."', '".$a."', '".$b."', '".$c."','".$cid."','".$pin."', '".$id."')";
      //echo $qry;exit;
      $exe=mysql_query($qry);
      if ($exe && $exe1)
      {
         echo"<script>alert('Registration Successful')</script>";
      }
      else
      {
         echo"<script>alert('Registration Unsuccessful')</script>";
      }
   }

   function staffregister($a,$b,$c,$g)  //staff register
   {
      $pass = time();
      $enc=md5($pass);
      $key1=uniquekey("login","loginkey");
      $qry1="insert into login(loginkey,email,password,usertype,status)values('".$key1."', '".$g."', '".$enc."','1','1')";
      $exe1=mysql_query($qry1);

      $key=uniquekey("staffregister","staffkey");
      $id=keytoid("login","loginkey",$key1);
      $qry="insert into staffregister(staffkey,staffname,designation,contactno,loginid)values('".$key."', '".$a."', '".$b."', '".$c."', '".$id."')";
      //echo $qry;exit;
      $exe=mysql_query($qry);
      if ($exe && $exe1)
      {
         echo"<script>alert('Registration Successful. Your password is $pass')</script>";
      }
      else
      {
         echo"<script>alert('Registration Unsuccessful')</script>";
      }
   }

   function login($a,$b)
   {
      $enc=md5($b);
      $qry="select loginkey,usertype,status from login where email='".$a."' and password='".$enc."'";
      // echo $qry;exit();
      $exe=mysql_query($qry);
      // $key=null;
      $c=0;
      while($rr=mysql_fetch_array($exe))
      {
         $c=$c+1;
         $key=$rr['loginkey'];
         $u=$rr['usertype'];
         $s=$rr['status'];
         // echo $key;exit();
      }

      $id=keytoid("login","loginkey",$key);
      $qry1="select * from staffregister inner join login on staffregister.loginid=login.id where login.id='".$id."'";
      // echo $qry1; exit;
      $exe1=mysql_query($qry1);
      while($r=mysql_fetch_array($exe1))
      {
         $designation = $r['designation'];
      }
      // echo $u; exit;


      if($c>0)
      {
         setcookie("loginkey",$key);
         setcookie("logined",1);
         if($s==1)
         {
            if($u==0)
            {
                  header("location: admin.php");
            }
            else if($u==1)
            {
               if($designation == 'Server Admin')
               {
                  header("location: serveradmin.php"); //home page for server admin
               }
               else if($designation == 'Ads Manager')
               {
                  header("location: adsmanager.php"); //home page for ads manager
               }
               else if($designation == 'Technical Manager')
               {
                  header("location: techmanager.php"); //home page for technical manager
               }
               else if($designation == 'Finance Manager')
               {
                  header("location: financemanager.php"); //home page for finance manager
               }
            }
            else if($u==2)
            {
                  header("location: client.php");
            }
         }
         else
         {
            echo "<script>alert('Waiting for admin approval')</script>";
         }
      }
      else
      {
         echo "<script>alert('Invalid user')</script>";
      }
   }

   function clientprofileview($key)
   {
      $id=keytoid("login","loginkey",$key);
      $qry="select * from register inner join login on register.loginid=login.id where login.id='".$id."'";
      //echo $qry;exit;
      $exe=mysql_query($qry);
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      return $arr;
   }

   function clientprofileupdate($a,$b,$d,$c,$g,$key)
   {
      $id=keytoid("login","loginkey",$key);
      $qry="update login set email='".$g."' where id='".$id."'";
      $exe=mysql_query($qry);
      $qry1="update register set name='".$a."',orgname='".$b."',address = '".$d."',contactno='".$c."' where loginid='".$id."'";
      $exe1=mysql_query($qry1);
      if($exe&&$exe1)
      {
         echo "<script>alert('Profile Updated Successfully')</script>";
      }
      else
      {
         echo "<script>alert('Profile Not Updated Successfully')</script>";
      }
   }

   function clientmessagetechnicalmanager()
   {
       $qry="select * from staffregister where designation ='Technical Manager'";
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }   

   function clientadminview()
   {
       $qry="select * from register inner join login on register.loginid=login.id";
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }   

   function clientapprove($key)
   {
      $id=keytoid("login","loginkey",$key);
      $qry="update login set status='1' where id='".$id."'";
      $exe=mysql_query($qry);
      if($exe)
      {
         echo "<script>alert('Approved Successfully');
         window.location.href='adminclientdetails.php'</script>";
      }
      else
      {
         echo "<script>alert('Not Approved')</script>";
      }
   }

   function clientreject($key)
   {
      $id=keytoid("login","loginkey",$key);
      $qry="update login set status='2' where id='".$id."'";
      $exe=mysql_query($qry);
      if($exe)
      {
         echo "<script>alert('Rejected Successfully');
         window.location.href='adminclientdetails.php'</script>";
      }
      else
      {
         echo "<script>alert('Not Rejected')</script>";
      }
   }

   function domainview($a,$b)
   {
      
      $qry="select id from domains where domainname = '".$a."' and extension = '".$b."'";
      $exe=mysql_query($qry);
      //echo $qry;exit;
      $arr=null;
      while($rr=mysql_fetch_array($exe))
      {
         $arr=$rr['id'];
      }
     // echo $arr;exit;
      if($arr!=null)
      {
         return 'taken';
      }
      else{
         return 'available';
      }
      // return $a;
   }

   function extensionview($key)
   {
      
      $qry="select distinct extension from domains";
      $exe=mysql_query($qry);
      //echo $qry;exit;
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      return $arr;
   }

   function indexextensionview()
   {
      
      $qry="select distinct extension from domains";
      $exe=mysql_query($qry);
      //echo $qry;exit;
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      return $arr;
   }

   function adminstaffview() //staff details page on admin
   {
       $qry="select * from staffregister inner join login on staffregister.loginid=login.id limit 1";
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }   

   function staffadminview()  //staff profile edit page in admin
   {
       $qry="select * from staffregister inner join login on staffregister.loginid=login.id";
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }   

   function adminstaffupdate($a,$b,$c,$g,$key)
   {
      $id=keytoid("login","loginkey",$key);
     // echo $id;exit;
      $qry="update login set email='".$g."' where id='".$id."'";
     //echo $qry;exit;
      $exe=mysql_query($qry);
      $qry1="update staffregister set staffname='".$a."',designation='".$b."',contactno='".$c."' where loginid='".$id."'";
      $exe1=mysql_query($qry1);
     // echo $qry1;exit;
      if($exe1)
      {
         echo "<script>alert('Profile Updated Successfully')</script>";
      }
      else
      {
         echo "<script>alert('Profile Not Updated Successfully')</script>";
      }
   }

   function staffprofileview($key)
   {
      $id=keytoid("login","loginkey",$key);
      $qry="select * from staffregister inner join login on staffregister.loginid=login.id where login.id='".$id."'";
      //echo $qry;exit;
      $exe=mysql_query($qry);
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      return $arr;
   }

   function staffprofileupdate($a,$b,$c,$g,$key)
   {
      $id=keytoid("login","loginkey",$key);
      $qry="update login set email='".$g."' where id='".$id."'";
      $exe=mysql_query($qry);
      $qry1="update staffregister set staffname='".$a."',designation='".$b."',contactno='".$c."' where loginid='".$id."'";
      $exe1=mysql_query($qry1);
      if($exe&&$exe1)
      {
         echo "<script>alert('Profile Updated Successfully')</script>";
      }
      else
      {
         echo "<script>alert('Profile Not Updated Successfully')</script>";
      }
   }

   function staffdelete($key)
   {
      $id=keytoid("login","loginkey",$key);
      $qry="delete from login where id='".$id."'";
      $exe=mysql_query($qry);
      $qry1="delete from staffregister where id='".$id."'";
      $exe1=mysql_query($qry1);
      if($exe && $exe1)
      {
         echo "<script>alert('Staff Deleted Successfully');
         window.location.href='adminstaffdetails.php'</script>";
      }
      else
      {
         echo "<script>alert('Not Deleted')</script>";
      }
   }

   function clientfeedback($a,$b,$key)
   {
      $dt=date('y-m-d');
      $key1=uniquekey("feedback","feedkey");
      $id=keytoid("login","loginkey",$key);
      $qry="insert into feedback(feedkey,title,feedback,currentdate,loginid)values('".$key1."', '".$a."', '".$b."', '".$dt."', '".$id."')";
      //echo $qry;exit;
      $exe=mysql_query($qry);
      if ($exe)
      {
         echo"<script>alert('Feedback Sent Successfully');
         window.location.href='clientfeedback.php'</script>";
      }
      else
      {
         echo"<script>alert('Feedback Not Sent!')</script>";
      }
   }

   function adminfeedbackview()
   {
       $qry="select * from feedback inner join login on feedback.loginid=login.id inner join register on register.loginid=feedback.loginid";
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }   

   function clientfeedbackview($key)
   {
       $id=keytoid("login","loginkey",$key);
       $qry="select * from feedback where loginid='".$id."'";
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }    
   
   function feedbackedit($a,$b,$key1) 
   {
      $id=keytoid("feedback","feedkey",$key1);
      $date=date('Y-m-d');
      $qry="update feedback set title='".$a."',feedback='".$b."', currentdate='".$date."' where id='".$id."'";
      // echo $qry; exit; 
      $exe=mysql_query($qry);
      if($exe)
      {
         echo "<script>alert('Feedback Edited Successfully');
         window.location.href='clientfeedback.php'</script>";
      }
      else
      {
         echo "<script>alert('Feedback Not Updated')</script>";
      }
   }

   function feedbackeditview($key1)
   {
       $id=keytoid("feedback","feedkey",$key1);
       $qry="select * from feedback where id='".$id."'";
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }    

   function feedbackdelete($key)
   {
       $id=keytoid("feedback","feedkey",$key);
       $qry="delete from feedback where id='".$id."'";
       $exe=mysql_query($qry);
       if($exe)
       {
         echo "<script>alert('Feedback Deleted Successfully');
         window.location.href='clientfeedback.php'</script>";
       }
       else
       {
         echo "<script>alert('Feedback Not Deleted')</script>";
       }
   }

   function hostingplans($a,$b,$c,$d,$e,$f,$g)  //hostin plans
   {
      $key=uniquekey("hostingplans","hostkey");
      $qry="insert into hostingplans(hostkey,hostingplan,amount,ramspace,bandwidth,storage,dbnumber,otherdetails)values('".$key."', '".$a."', '".$b."', '".$c."','".$d."','".$e."', '".$f."', '".$g."')";
      //echo $qry;exit;
      $exe=mysql_query($qry);
      if ($exe)
      {
         echo"<script>alert('Hosting plan set Successfully')</script>";
      }
      else
      {
         echo"<script>alert('Hosting plan not set')</script>";
      }
   }

   function hostingplansview()
   {
      $qry="select * from hostingplans";
      $exe=mysql_query($qry);
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      return $arr;
   }

   function hostingplanseditview($key1)
   {
      $id=keytoid("hostingplans","hostkey",$key1);
      $qry="select * from hostingplans where id='".$id."'";
      $exe=mysql_query($qry);
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      return $arr;
   }

   function hostingplansedit($a,$b,$c,$d,$e,$f,$g,$key1)
   {
      $id=keytoid("hostingplans","hostkey",$key1);
      $qry="update hostingplans set hostingplan='".$a."',amount='".$b."', ramspace='".$c."', bandwidth='".$d."', storage='".$e."', dbnumber='".$f."', otherdetails='".$g."' where id='".$id."'";
      // echo $qry; exit; 
      $exe=mysql_query($qry);
      if($exe)
      {
         echo "<script>alert('Hosting Plan Edited Successfully');
         window.location.href='hostingplansview.php'</script>";
      }
      else
      {
         echo "<script>alert('Hosting Plan Not Updated')</script>";
      }
   }

   function hostingplansdelete($key)
   {
       $id=keytoid("hostingplans","hostkey",$key);
       $qry="delete from hostingplans where id='".$id."'";
       $exe=mysql_query($qry);
       if($exe)
       {
         echo "<script>alert('Hosting Plan Deleted Successfully');
         window.location.href='hostingplansview.php'</script>";
       }
       else
       {
         echo "<script>alert('Hosting Plan Not Deleted')</script>";
       }
   }

   function addtocart($a,$extension,$key)  //add to cart
   {
      $id=keytoid("login","loginkey",$key);
      $key1=uniquekey("cart","cartkey");
      $date = date('y-m-d');
      $qry1 = "select amount from domainextensions where extension = '".$extension."'";
      $exe1 = mysql_query($qry1);
      while($rr = mysql_fetch_assoc($exe1)){
         $b = $rr['amount'];
      }
      // echo $b;exit;
      $qry="insert into cart(cartkey,product,type,quantity,amount,purchasestatus,currentdate,loginid)values('".$key1."', '".$a."','domain','1','".$b."', '0','".$date."','".$id."')";
      $exe=mysql_query($qry);
      if ($exe)
      {
         echo"<script>alert('Added to cart Successfully');
         window.location.href='client.php'</script>";
      }
      else
      {
         echo"<script>alert('Not added to cart');
         window.location.href='client.php'</script>";
      }
   }

   function addplantocart($a,$b,$key)  //add plan to cart
   {
      $id=keytoid("login","loginkey",$key);
      $key1=uniquekey("cart","cartkey");
      $date = date('y-m-d');
      $qry="insert into cart(cartkey,product,type,quantity,amount,purchasestatus,currentdate,loginid)values('".$key1."', '".$a."', 'server','1','".$b."', '0','".$date."','".$id."')";
      // echo $qry;exit;
      $exe=mysql_query($qry);
      if ($exe)
      {
         echo"<script>alert('Added to cart Successfully');
         window.location.href='client.php'</script>";
      }
      else
      {
         echo"<script>alert('Not added to cart')</script>";
      }
   }

   function extensionadd($a,$b,$c)  //extension add - admin
   {
      $key=uniquekey("domainextensions","extkey");
      $qry="insert into domainextensions(extkey,extension,amount,validity)values('".$key."', '".$a."', '".$b."', '".$c."')";
      //echo $qry;exit;
      $exe=mysql_query($qry);
      if ($exe)
      {
         echo"<script>alert('Extension set Successfully')</script>";
      }
      else
      {
         echo"<script>alert('Extenstion not set')</script>";
      }
   }

   function adminextensionview() //for the admin to view the extensions
   {
       $qry="select * from domainextensions";
      //  echo $qry;exit;
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }


   function extensioneditview($key1)
   {
      $id=keytoid("domainextensions","extkey",$key1);
      $qry="select * from domainextensions where id='".$id."'";
      $exe=mysql_query($qry);
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      return $arr;
   }


   function extensionedit($a,$b,$c,$key1)
   {
      $id=keytoid("domainextensions","extkey",$key1);
      $qry="update domainextensions set extension='".$a."',amount='".$b."', validity='".$c."' where id='".$id."'";
      $exe=mysql_query($qry);
      // echo $qry; exit; 
      if($exe)
      {
         echo "<script>alert('Extension Edited Successfully');
         window.location.href='extensionview.php'</script>";
      }
      else
      {
         echo "<script>alert('Extension Not Updated')</script>";
      }
   }

   function serveradminextensionedit($a,$b,$c,$key1)
   {
      $id=keytoid("domainextensions","extkey",$key1);
      $qry="update domainextensions set extension='".$a."',amount='".$b."', validity='".$c."' where id='".$id."'";
      $exe=mysql_query($qry);
      // echo $qry; exit; 
      if($exe)
      {
         echo "<script>alert('Extension Edited Successfully');
         window.location.href='serveradminextensionview.php'</script>";
      }
      else
      {
         echo "<script>alert('Extension Not Updated')</script>";
      }
   }


   function extensiondelete($key)
   {
       $id=keytoid("domainextensions","extkey",$key);
       $qry="delete from domainextensions where id='".$id."'";
       $exe=mysql_query($qry);
       if($exe)
       {
         echo "<script>alert('Extension Deleted Successfully');
         window.location.href='extensionview.php'</script>";
       }
       else
       {
         echo "<script>alert('Extension Not Deleted')</script>";
       }
   }


   function serveradminextensiondelete($key)
   {
       $id=keytoid("domainextensions","extkey",$key);
       $qry="delete from domainextensions where id='".$id."'";
       $exe=mysql_query($qry);
       if($exe)
       {
         echo "<script>alert('Extension Deleted Successfully');
         window.location.href='serveradminextensionview.php'</script>";
       }
       else
       {
         echo "<script>alert('Extension Not Deleted')</script>";
       }
   }



   function cartitemsview($key)
   {
      $id=keytoid("login","loginkey",$key);
      $qry="select * from cart where loginid = '".$id."' and purchasestatus = '0'";
      // echo $qry;exit;
      $exe=mysql_query($qry);
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      if($arr!=null)
      {
         return $arr;
      }
      else{
         return 'empty';
      }
   }

   function cartitemsdelete($key)
   {
       $id=keytoid("cart","cartkey",$key);
       $qry="delete from cart where id='".$id."'";
       $exe=mysql_query($qry);
       if($exe)
       {
         echo "<script>alert('Cart Item Deleted Successfully');
         window.location.href='cart.php'</script>";
       }
       else
       {
         echo "<script>alert('Cart Item Not Deleted');
         window.location.href='cart.php'</script>";
       }
   }

   function payment($a,$b,$c,$d,$e,$key,$amount,$productid)
   {
      date_default_timezone_set('Asia/kolkata');
       $t=date('h:i:sa');
       $date=date('Y-m-d');
       $month=date('Y-m');
       $id=keytoid("login","loginkey",$key);
   
       $key1=uniquekey("payment","paykey");
   
       $qry="insert into payment(paykey,nameoncard,cardnumber,expirymonth,expiryyear,cvv,amount,currentdate,currentmonth,loginid) values('".$key1."','".$a."','".$b."','".$c."','".$d."','".$e."','".$amount."','".$date."','".$month."','".$id."')";
       $exe=mysql_query($qry);
       
       $qry="update banktable set totalamount = totalamount-".$amount." where cardnumber='".$b."' and cvv='".$e."'";
      //  echo $qry;exit;
            
        $exe=mysql_query($qry);

       
   
        if ($exe)
        {

         $qry2 = "update cart set purchasestatus = '1' where purchasestatus = '0' and id = '".$productid."'";
         mysql_query($qry2);


           echo"<script>alert('Payment Successful');
           window.location.href='client.php'</script>";
        }
        else
        {
           echo"<script>alert('Payment Unsuccessful')</script>";
        }  
   
      
   } 

   function checkout($a,$b,$c,$d,$e,$key)
   {
      date_default_timezone_set('Asia/kolkata');
       $t=date('h:i:sa');
       $date=date('Y-m-d');
       $month=date('Y-m');
       $id=keytoid("login","loginkey",$key);
   
       $key1=uniquekey("payment","paykey");
       
       $qry1 = "select sum(amount) from cart where purchasestatus = '0' and loginid = '".$id."'";
       $exe1 = mysql_query($qry1);
       while($rr = mysql_fetch_assoc($exe1)){
         $amount = $rr['sum(amount)'];
      }

      //  echo $amount;exit;
       
       
       $qry="insert into payment(paykey,nameoncard,cardnumber,expirymonth,expiryyear,cvv,amount,currentdate,currentmonth,loginid) values('".$key1."','".$a."','".$b."','".$c."','".$d."','".$e."','".$amount."','".$date."','".$month."','".$id."')";
       $exe=mysql_query($qry);
       
       $qry="update banktable set totalamount = totalamount-".$amount." where cardnumber='".$b."' and cvv='".$e."'";
       $exe=mysql_query($qry);
       
       
       if ($exe)
       {
         $qry2 = "update cart set purchasestatus = '1' where purchasestatus = '0' and loginid = '".$id."'";
         mysql_query($qry2);

         echo"<script>alert('Payment Successful');
         window.location.href='client.php'</script>";
        }
        else
        {
           echo"<script>alert('Payment Unsuccessful')</script>";
        }  
   
      
   } 

   function admindomainview() //for the admin to view purchased items
   {
       $qry="select * from cart inner join register on cart.loginid=register.loginid inner join login on login.id=cart.loginid where purchasestatus='1'";
      //  echo $qry;exit;
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }

   function profilepictureupload($file=NULL,$key)  //add profile picture important
   {
      $id=keytoid("login","loginkey",$key);
      $key1=uniquekey("profilepictures","pickey");
      $date = date('Y-m-d');
      $qry="insert into profilepictures(pickey,profilepicture,loginid)values('".$key."', '".$file['name']."', '".$id."')";
     // echo $qry;exit;
      $exe=mysql_query($qry);
      $doc = "profilepictures/".$key;
      mkdir($doc);
      if ($exe)
      {
         move_uploaded_file($file["tmp_name"],$doc."/".$file["name"]);
         echo"<script>alert('Profile picture set Successfully')</script>";
      }
      else
      {
         echo"<script>alert('Profile picture plan not set')</script>";
      }
   }

   function profilepictureview($key)
   {
      $id=keytoid("login","loginkey",$key);
       $qry="select * from profilepictures where loginid = '".$id."' order by id limit 1";
      //  echo $qry; exit;
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
            $path="profilepictures/".$rr['pickey']."/".$rr["profilepicture"];
			   $rr['path']=$path;
            $arr[]=$rr;
       }
       return $arr;
   }

   function clientdomainview($key) //for client to view domains
   {
      $id=keytoid("login","loginkey",$key);
       $qry="select * from cart where loginid = '".$id."' and type = 'domain' and purchasestatus ='1'";
      //  echo $qry;exit;
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }

   function clientplanview($key) //for client to view plans
   {
      $id=keytoid("login","loginkey",$key);
       $qry="select * from cart where loginid = '".$id."' and type = 'server' and purchasestatus ='1'";
      //  echo $qry;exit;
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $arr[]=$rr;
       }
       return $arr;
   }

   // function checkRenewal($purchasedate)  //function to check renewal.. this is defined after the userclass
   // {
   //    $actualdate = explode('-',$purchasedate);
   //    $year = $actualdate[0];
   //    $month = $actualdate[1];
   //    $day = $actualdate[2];

   //    $currentyear = $year + 1;
   //    $currentmonth = $month + 1;

   //    $renewaldate = $currentyear.'-'.$currentmonth.'-'.$day;
   //    $currentdate = date('Y-m-d');
      
   //    $t = strtotime($renewaldate);
   //    $t1 = strtotime($currentdate);
   //   //  echo $t1;exit;
   //   if ($t < $t1) {
   //      return true;
   //   } else {
   //      return false;
   //   }
   // }

   function renewplannotification($key)
   {
       $id=keytoid("login","loginkey",$key);
       $qry="select * from cart where loginid='".$id."' and purchasestatus = '1'";
       $exe=mysql_query($qry);

       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
           $purchasedate=$rr['currentdate'];
           if(checkRenewal($purchasedate))
           {
               $arr[]=$rr;
           }
       }
       return $arr;

   }

   function advertisement($a,$file=NULL)  //advertisement add to table
   {
      $key=uniquekey("advertisement","adkey");
      $date = date('Y-m-d');
      $qry="insert into advertisement(adkey,company,image,currentdate)values('".$key."', '".$a."', '".$file['name']."', '".$date."')";
     // echo $qry;exit;
      $exe=mysql_query($qry);
      $doc = "advertisement/".$key;
      if ($exe)
      {
         move_uploaded_file($file["tmp_name"],$doc."/".$file["name"]);
         echo"<script>alert('Advertisement set Successfully')</script>";
      }
      else
      {
         echo"<script>alert('Advertisement plan not set')</script>";
      }
   }

   function adminadsview()
   {
       $qry="select * from advertisement";
      //  echo $qry; exit;
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
            $path="advertisement/".$rr['adkey']."/".$rr["image"];
			   $rr['path']=$path;
            $arr[]=$rr;
       }
       return $arr;
   }

   function adminadseditview($key1)
   {
      $id=keytoid("advertisement","adkey",$key1);
       $qry="select * from advertisement where id='".$id."'";
      //  echo $qry; exit;
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
            $path="advertisement/".$rr['adkey']."/".$rr["image"];
			   $rr['path']=$path;
            $arr[]=$rr;
       }
       return $arr;
   }
   
   function advertisementedit($a,$file=NULL,$key1)
   {
      $id=keytoid("advertisement","adkey",$key1);
      $qry="update advertisement set company='".$a."',image='".$file['name']."' where id='".$id."'";
      //  echo $qry; exit; 
      $exe=mysql_query($qry);
      $doc = "advertisement/".$key1;
      mkdir($doc);
      if($exe)
      {
         move_uploaded_file($file["tmp_name"],$doc."/".$file["name"]);
         echo "<script>alert('Advertisement Edited Successfully');
         window.location.href='adminadsview.php'</script>";
      }
      else
      {
         echo "<script>alert('Advertisement Not Updated')</script>";
      }
   }


   function adsmanageradvertisementedit($a,$file=NULL,$key1)
   {
      $id=keytoid("advertisement","adkey",$key1);
      $qry="update advertisement set company='".$a."',image='".$file['name']."' where id='".$id."'";
      //  echo $qry; exit; 
      $exe=mysql_query($qry);
      $doc = "advertisement/".$key1;
      
      if($exe)
      {
         move_uploaded_file($file["tmp_name"],$doc."/".$file["name"]);
         echo "<script>alert('Advertisement Edited Successfully');
         window.location.href='adsmanageradsview.php'</script>";
      }
      else
      {
         echo "<script>alert('Advertisement Not Updated')</script>";
      }
   }




   function advertisementdelete($key)
   {
       $id=keytoid("advertisement","adkey",$key);
       $qry="delete from advertisement where id='".$id."'";
       $exe=mysql_query($qry);
      $doc = "advertisement/".$key;
      $files = glob($doc."/*"); //get all files in the directory
      foreach ($files as $file) {
         if(is_file($file)) {
            unlink($file); // delete all files
          }
      }
      rmdir($doc);
       if($exe)
       {
         echo "<script>alert('Advertisement Deleted Successfully');
         window.location.href='adminadsview.php'</script>";
       }
       else
       {
         echo "<script>alert('Advertisement Not Deleted')</script>";
       }
   }

   function adsmanageradvertisementdelete($key)
   {
       $id=keytoid("advertisement","adkey",$key);
       $qry="delete from advertisement where id='".$id."'";
       $exe=mysql_query($qry);
      $doc = "advertisement/".$key;
      $files = glob($doc."/*"); //get all files in the directory
      foreach ($files as $file) {
         if(is_file($file)) {
            unlink($file); // delete all files
          }
      }
      rmdir($doc);
       if($exe)
       {
         echo "<script>alert('Advertisement Deleted Successfully');
         window.location.href='adsmanageradsview.php'</script>";
       }
       else
       {
         echo "<script>alert('Advertisement Not Deleted')</script>";
       }
   }

   function indexadsview() //to view the ads in the index page
   {
       $qry="select * from advertisement order by 'id' asc limit 6";
      //  echo $qry; exit;
       $exe=mysql_query($qry);
       $arr=array();
       while($rr=mysql_fetch_array($exe))
       {
            $path="advertisement/".$rr['adkey']."/".$rr["image"];
			   $rr['path']=$path;
            $arr[]=$rr;
       }
       return $arr;
   }

   function dailyincomeview() //for admin to view daily income
   {
      $date=date('Y-m-d');
       $qry="select sum(amount), count(distinct loginid), count(distinct id) from payment where currentdate = '".$date."'";
      //  echo $qry;exit;
       $exe=mysql_query($qry);
       $arr=array();
       $a=null;
       $b=null;
       $c=null;
       while($rr=mysql_fetch_array($exe))
       {
           $a=$rr['sum(amount)'];
           $b=$rr['count(distinct loginid)'];
           $c=$rr['count(distinct id)'];
       }
       $arr[0]=$a;
       $arr[1]=$b;
       $arr[2]=$c;
      //   print_r($arr) ; exit;
       return $arr;
   }

   function monthlyincome($a) //for admin to view monthly income
   {
      // echo $a; exit;
       $qry="select * from payment where currentmonth = '".$a."'";
      // echo $qry;exit;
       $exe=mysql_query($qry);
      if($rr = mysql_fetch_array($exe))
      {
         echo "<script>window.location.href='monthlyincomeview.php?key=".$a."'</script>";
      }
      else
      {
         echo "<script>alert('No transactions this month');
         window.location.href='monthlyincome.php'</script>";
      }
   }

   function financemanagermonthlyincome($a) //for admin to view monthly income
   {
      // echo $a; exit;
       $qry="select * from payment where currentmonth = '".$a."'";
      // echo $qry;exit;
       $exe=mysql_query($qry);
      if($rr = mysql_fetch_array($exe))
      {
         echo "<script>window.location.href='financemanagermonthlyincomeview.php?key=".$a."'</script>";
      }
      else
      {
         echo "<script>alert('No transactions this month');
         window.location.href='financemanagermonthlyincome.php'</script>";
      }
   }

   function monthlyincomeview($month) //for admin to view monthly income
   {
       $qry="select sum(amount), count(distinct loginid), count(distinct id) from payment where currentmonth = '".$month."'";
      //  echo $qry;exit;
       $exe=mysql_query($qry);
       $arr=array();
       $a=null;
       $b=null;
       $c=null;
       while($rr=mysql_fetch_array($exe))
       {
           $a=$rr['sum(amount)'];
           $b=$rr['count(distinct loginid)'];
           $c=$rr['count(distinct id)'];
       }
       $arr[0]=$a;
       $arr[1]=$b;
       $arr[2]=$c;
      //   print_r($arr) ; exit;
       return $arr;
   }


   function adminsendsalary($a,$b,$key1)
   {
      // echo $key1;exit;
      $date=date('Y-m-d');

      $key122=uniquekey("salary","salarykey");
      
      $key12=keytoid("login","loginkey",$key1);
      //echo $key12;exit;
      $qry="insert into salary(salarykey,month,salary,staffid) values('".$key122."','".$a."','".$b."','".$key12."')";
      // echo $qry;exit;   
      
      $exe=mysql_query($qry);
      

      if ($exe)
      {
         echo"<script>alert('Salary payment Successful');
         window.location.href='adminsalarydetails.php'</script>";
      }
      else
      {
         echo"<script>alert('Salary payment Unsuccessful')</script>";
      }  

      
   } 


   function salaryview($key)
   {
      $id=keytoid("login","loginkey",$key);
      $qry="select * from salary inner join staffregister on salary.staffid=staffregister.loginid where salary.staffid='".$id."'";
      // echo $qry;exit;
   $exe=mysql_query($qry);
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      return $arr;
   }   
   
   
   function salarydetailsview()
   {
      $qry="select * from salary inner join staffregister on salary.staffid=staffregister.loginid inner join login on salary.staffid=login.id";
      // echo $qry;exit;
   $exe=mysql_query($qry);
      $arr=array();
      while($rr=mysql_fetch_array($exe))
      {
         $arr[]=$rr;
      }
      return $arr;
   }   



   function clientmessagetech($a,$name,$designation,$key)
 {
    $keyy=uniquekey("messages","msgkey");
    date_default_timezone_set('Asia/kolkata');
    $t=date('h:i:sa');
    $date=date('Y-m-d');
    $id=keytoid("login","loginkey",$key);

    $q1="select loginid from staffregister where staffname = '".$name."' and designation = '".$designation."'";
    $e1=mysql_query($q1);
    $v_id=NULL;
    while($r1=mysql_fetch_array($e1))
    {
        $v_id=$r1['loginid'];
    }
    $qry="insert into messages(msgkey,message,sendid,recid,currentdate,currenttime)
    values('".$keyy."', '".$a."','".$id."','".$v_id."','".$date."','".$t."')";
    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe)
     {
        echo"<script>alert('Message sent Successfully')</script>";
     }
     else
     {
        echo"<script>alert('Sending message Unsuccessful')</script>";
     } 
    } 



    function clientviewtechmessages($key,$name,$designation)
    {
        $id=keytoid("login","loginkey",$key);


        $q1="select loginid from staffregister where staffname = '".$name."' and designation = '".$designation."'";
        $e1=mysql_query($q1);
        $v_id=NULL;
        while($r1=mysql_fetch_array($e1))
        {
           $v_id=$r1['loginid'];
         }
         
         
         $qry="select * from messages where sendid='".$id."' and recid = '".$v_id."'";
         // echo $qry; exit;
        $exe=mysql_query($qry);
        $arr=array();
        while($rr=mysql_fetch_array($exe))
        {
            $arr[]=$rr;
        }
        return $arr;
    }  


    function clientviewtechreplies($key,$name,$designation)
    {
        $id=keytoid("login","loginkey",$key);


        $q1="select loginid from staffregister where staffname = '".$name."' and designation = '".$designation."'";
        $e1=mysql_query($q1);
        $v_id=NULL;
        while($r1=mysql_fetch_array($e1))
        {
           $v_id=$r1['loginid'];
         }
         
         
         $qry="select * from messages where sendid='".$v_id."' and recid = '".$id."'";
         // echo $qry; exit;
        $exe=mysql_query($qry);
        $arr=array();
        while($rr=mysql_fetch_array($exe))
        {
            $arr[]=$rr;
        }
        return $arr;
    }
    
    function techmanagerviewmessages($key)
    {
        $id=keytoid("login","loginkey",$key);

         $qry="select * from messages inner join register on messages.sendid = register.loginid where recid = '".$id."'";
         // echo $qry; exit;
        $exe=mysql_query($qry);
        $arr=array();
        while($rr=mysql_fetch_array($exe))
        {
            $arr[]=$rr;
        }
        return $arr;
    }


    function techmessageclient($a,$name,$key)
    {
       $keyy=uniquekey("messages","msgkey");
       date_default_timezone_set('Asia/kolkata');
       $t=date('h:i:sa');
       $date=date('Y-m-d');
       $id=keytoid("login","loginkey",$key);
   
       $q1="select loginid from register where name = '".$name."'";
       $e1=mysql_query($q1);
       $v_id=NULL;
       while($r1=mysql_fetch_array($e1))
       {
           $v_id=$r1['loginid'];
       }
       $qry="insert into messages(msgkey,message,sendid,recid,currentdate,currenttime)
       values('".$keyy."', '".$a."','".$id."','".$v_id."','".$date."','".$t."')";
       // echo  $qry;exit;
        $exe=mysql_query($qry);
        if ($exe)
        {
           echo"<script>alert('Message sent Successfully')</script>";
        }
        else
        {
           echo"<script>alert('Sending message Unsuccessful')</script>";
        } 
       } 
   


       
    function techviewclientmessages($key,$name)
    {
        $id=keytoid("login","loginkey",$key);


        $q1="select loginid from register where name = '".$name."'";
        $e1=mysql_query($q1);
        $v_id=NULL;
        while($r1=mysql_fetch_array($e1))
        {
           $v_id=$r1['loginid'];
         }
         
         
         $qry="select * from messages where sendid='".$id."' and recid = '".$v_id."'";
         // echo $qry; exit;
        $exe=mysql_query($qry);
        $arr=array();
        while($rr=mysql_fetch_array($exe))
        {
            $arr[]=$rr;
        }
        return $arr;
    }  


    function techviewclientreplies($key,$name)
    {
        $id=keytoid("login","loginkey",$key);


        $q1="select loginid from register where name = '".$name."'";
        $e1=mysql_query($q1);
        $v_id=NULL;
        while($r1=mysql_fetch_array($e1))
        {
           $v_id=$r1['loginid'];
         }
         
         
         $qry="select * from messages where sendid='".$v_id."' and recid = '".$id."'";
         // echo $qry; exit;
        $exe=mysql_query($qry);
        $arr=array();
        while($rr=mysql_fetch_array($exe))
        {
            $arr[]=$rr;
        }
        return $arr;
    }

    function techviewclients()
    {
        $qry="select * from register";
        $exe=mysql_query($qry);
        $arr=array();
        while($rr=mysql_fetch_array($exe))
        {
            $arr[]=$rr;
        }
        return $arr;
    }   



    function adminviewstaff()
    {
        $qry="select * from staffregister";
        $exe=mysql_query($qry);
        $arr=array();
        while($rr=mysql_fetch_array($exe))
        {
            $arr[]=$rr;
        }
        return $arr;
    }   


    function adminviewmessages($key)
    {
        $id=keytoid("login","loginkey",$key);

         $qry="select * from messages inner join staffregister on messages.sendid = staffregister.loginid where recid = '".$id."'";
         // echo $qry; exit;
        $exe=mysql_query($qry);
        $arr=array();
        while($rr=mysql_fetch_array($exe))
        {
            $arr[]=$rr;
        }
        return $arr;
    }



    function adminmessagestaff($a,$name,$designation,$key)
    {
       $keyy=uniquekey("messages","msgkey");
       date_default_timezone_set('Asia/kolkata');
       $t=date('h:i:sa');
       $date=date('Y-m-d');
       $id=keytoid("login","loginkey",$key);
   
       $q1="select loginid from staffregister where staffname = '".$name."' and designation = '".$designation."'";
       $e1=mysql_query($q1);
       $v_id=NULL;
       while($r1=mysql_fetch_array($e1))
       {
           $v_id=$r1['loginid'];
       }
       $qry="insert into messages(msgkey,message,sendid,recid,currentdate,currenttime)
       values('".$keyy."', '".$a."','".$id."','".$v_id."','".$date."','".$t."')";
       // echo  $qry;exit;
        $exe=mysql_query($qry);
        if ($exe)
        {
           echo"<script>alert('Message sent Successfully')</script>";
        }
        else
        {
           echo"<script>alert('Sending message Unsuccessful')</script>";
        } 
       } 




       function adminviewstaffmessages($key,$name,$designation)
       {
           $id=keytoid("login","loginkey",$key);
   
   
           $q1="select loginid from staffregister where staffname = '".$name."' and designation = '".$designation."'";
           $e1=mysql_query($q1);
           $v_id=NULL;
           while($r1=mysql_fetch_array($e1))
           {
              $v_id=$r1['loginid'];
            }
            
            
            $qry="select * from messages where sendid='".$id."' and recid = '".$v_id."'";
            // echo $qry; exit;
           $exe=mysql_query($qry);
           $arr=array();
           while($rr=mysql_fetch_array($exe))
           {
               $arr[]=$rr;
           }
           return $arr;
       }  




       function adminviewstaffreplies($key,$name,$designation)
       {
           $id=keytoid("login","loginkey",$key);
   
   
           $q1="select loginid from staffregister where staffname = '".$name."' and designation = '".$designation."'";
           $e1=mysql_query($q1);
           $v_id=NULL;
           while($r1=mysql_fetch_array($e1))
           {
              $v_id=$r1['loginid'];
            }
            
            
            $qry="select * from messages where sendid='".$v_id."' and recid = '".$id."'";
            // echo $qry; exit;
           $exe=mysql_query($qry);
           $arr=array();
           while($rr=mysql_fetch_array($exe))
           {
               $arr[]=$rr;
           }
           return $arr;
       }




       function staffmessageadmin($a,$key)
       {
          $keyy=uniquekey("messages","msgkey");
          date_default_timezone_set('Asia/kolkata');
          $t=date('h:i:sa');
          $date=date('Y-m-d');
          $id=keytoid("login","loginkey",$key);
      
          $qry="insert into messages(msgkey,message,sendid,recid,currentdate,currenttime)
          values('".$keyy."', '".$a."','".$id."','12','".$date."','".$t."')";
          // echo  $qry;exit;
           $exe=mysql_query($qry);
           if ($exe)
           {
              echo"<script>alert('Message sent Successfully')</script>";
           }
           else
           {
              echo"<script>alert('Sending message Unsuccessful')</script>";
           } 
          } 



          function staffviewadminmessages($key)
          {
              $id=keytoid("login","loginkey",$key);

              $qry="select * from messages where sendid='".$id."' and recid = '12'";
               // echo $qry; exit;
              $exe=mysql_query($qry);
              $arr=array();
              while($rr=mysql_fetch_array($exe))
              {
                  $arr[]=$rr;
              }
              return $arr;
          }  



          function staffviewadminreplies($key)
          {
              $id=keytoid("login","loginkey",$key);
      
               $qry="select * from messages where sendid='12' and recid = '".$id."'";
               // echo $qry; exit;
              $exe=mysql_query($qry);
              $arr=array();
              while($rr=mysql_fetch_array($exe))
              {
                  $arr[]=$rr;
              }
              return $arr;
          }



          function clientnotification($a)
          {
             $keyy=uniquekey("notifications","notificationkey");
             date_default_timezone_set('Asia/kolkata');
             $date=date('Y-m-d');
         
             $qry="insert into notifications(notificationkey,notification,currentdate,usertype)
             values('".$keyy."', '".$a."','".$date."','client')";
            //  echo  $qry;exit;
              $exe=mysql_query($qry);
              if ($exe)
              {
                 echo"<script>alert('Notification sent Successfully')</script>";
              }
              else
              {
                 echo"<script>alert('Notification message Unsuccessful')</script>";
              } 
             } 


             function clientnotificationview()
             {
                  $qry="select * from notifications where usertype = 'client'";
                  // echo $qry; exit;
                 $exe=mysql_query($qry);
                 $arr=array();
                 while($rr=mysql_fetch_array($exe))
                 {
                     $arr[]=$rr;
                 }
                 return $arr;
             }



             function staffnotification($a)
             {
                $keyy=uniquekey("notifications","notificationkey");
                date_default_timezone_set('Asia/kolkata');
                $date=date('Y-m-d');
            
                $qry="insert into notifications(notificationkey,notification,currentdate,usertype)
                values('".$keyy."', '".$a."','".$date."','staff')";
               //  echo  $qry;exit;
                 $exe=mysql_query($qry);
                 if ($exe)
                 {
                    echo"<script>alert('Notification sent Successfully')</script>";
                 }
                 else
                 {
                    echo"<script>alert('Notification message Unsuccessful')</script>";
                 } 
                } 
   
   
                function staffnotificationview()
                {
                     $qry="select * from notifications where usertype = 'staff'";
                     // echo $qry; exit;
                    $exe=mysql_query($qry);
                    $arr=array();
                    while($rr=mysql_fetch_array($exe))
                    {
                        $arr[]=$rr;
                    }
                    return $arr;
                }





}

function checkRenewal($purchasedate)
{
   $actualdate = explode('-',$purchasedate);
   $year = $actualdate[0];
   $month = $actualdate[1];
   $day = $actualdate[2];

   $currentyear = $year + 1;
   $currentmonth = $month + 1;

   $renewaldate = $currentyear.'-'.$currentmonth.'-'.$day;
   $currentdate = date('Y-m-d');
   
   $t = strtotime($renewaldate);
   $t1 = strtotime($currentdate);
  //  echo $t1;exit;
  if ($t < $t1) {
     return true;
  } else {
     return false;
  }
}
?>