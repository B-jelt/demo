<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];

$s=$obj->clientprofileview($key);
$smartyObj->assign("view",$s);


$s=$obj->cartitemsview($key);
$smartyObj->assign("cartitemsview",$s);
$smartyObj->assign("cartitems",$s);


$smartyObj->display('clientsubheader.tpl');
$smartyObj->display('cart.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:.pindexhp");
}

?>