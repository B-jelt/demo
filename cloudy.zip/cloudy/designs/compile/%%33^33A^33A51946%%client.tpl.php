<?php /* Smarty version 2.6.26, created on 2022-02-11 07:06:26
         compiled from client.tpl */ ?>
<!-- BEGIN: Content-->

<div class="row">
    <div class="col-xl-3 col-lg-5 col-md-12">
        <!--Project Timeline div starts-->



        <!--Project Timeline div ends-->
    </div>
</div>
</div>
<section id="search-website" class="card overflow-hidden">
    <div class="card-header">
        <a class="heading-elements-toggle">
            <i class="la la-ellipsis-v font-medium-3"></i>
        </a>
        <div class="heading-elements">
            <ul class="list-inline mb-0">
                <li>
                    <a data-action="collapse">
                        <i class="ft-minus"></i>
                    </a>
                </li>
                <li>
                    <a data-action="reload">
                        <i class="ft-rotate-cw"></i>
                    </a>
                </li>
                <li>
                    <a data-action="expand">
                        <i class="ft-maximize"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="card-content collapse show">
        <div class="card-body pb-0">
            <section class="find-domain-area section-padding-100-0">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-12 col-md-4">
                            <div class="domain-text mb-100">
                                <h2>Find Your Perfect Domain Name</h2>
                                <h6>Only $7 for the first year</h6>
                            </div>
                        </div>
                        <div class="col-12 col-md-8">
                            <div class="domain-search-form mb-100">
                                <form action="#" method="post" class="form-inline">
                                    <input type="hidden" name="hide" value="h">
                                    <input type="search" placeholder="Enter Your Domain Name Here" name="domainname">
                                    <select name="extension" id="domainExtension">
                                        <?php $_from = $this->_tpl_vars['extension']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['e']):
?>
                                        <option value="<?php echo $this->_tpl_vars['e']['extension']; ?>
"><?php echo $this->_tpl_vars['e']['extension']; ?>
</option>
                                        <?php endforeach; endif; unset($_from); ?>
                                    </select>
                                    <button type="submit">Search Domain</button>
                                </form>
                                <?php if ($this->_tpl_vars['domain'] == 'taken'): ?>
                                <div class="alert round bg-danger alert-icon-left alert-dismissible mb-2 mt-1" role="alert">
                                    <span class="alert-icon">
                                        <i class="ft-thumbs-down"></i>
                                    </span>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    <strong>Oh snap!</strong> your domain name is already taken... try something else.
                                    <!-- <a href="#" class="alert-link"></a> -->
                                </div>
                                <?php elseif ($this->_tpl_vars['domain'] == 'available'): ?>
                                <div class="alert round bg-success alert-icon-right alert-dismissible mb-2 mt-1" role="alert">
                                    <span class="alert-icon">
                                        <a href="addtocart.php?domainname=<?php echo $this->_tpl_vars['domainname']; ?>
&extension=<?php echo $this->_tpl_vars['extension']; ?>
"><i class="ft-shopping-cart white"></i></a>
                                    </span>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                    <strong>Your domain name <?php echo $this->_tpl_vars['domainname']; ?>
<?php echo $this->_tpl_vars['extension']; ?>
 is available!!</strong>
                                    <!-- <a href="#" class="alert-link">your attention</a>, and it's important. -->
                                </div>
                                <?php else: ?> <?php endif; ?>
                                <div class="domain-price-help mt-50 d-flex align-items-center justify-content-between ">
                                    <p>.COM ₹869</p>
                                    <p>.NET ₹999</p>
                                    <p>.ORG ₹849</p>
                                    <p>.IN ₹429</p>
                                    <p>.BIZ ₹1299</p>
                                    <p>.CO ₹1949</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <section class="hami-price-plan-area mt-50">
            <div class="container">
                <div class="row">

                    <div class="col-12">
                        <div class="section-heading text-center">
                            <h2>Choose Your Web Hosting Plan</h2>
                            <p>You want custom hosting plan. No hidden charge.</p>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">

                    <?php $_from = $this->_tpl_vars['hostingplans']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['h']):
?>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="single-price-plan mb-100">

                            <div class="price-plan-title">
                                <h4><?php echo $this->_tpl_vars['h']['hostingplan']; ?>
</h4>
                                <p>On sale - Save 50%</p>
                            </div>

                            <div class="price-plan-value">
                                <h2><span>₹</span><?php echo $this->_tpl_vars['h']['amount']; ?>
</h2>
                                <p>/per month</p>
                            </div>

                            <a href="addplantocart.php?hostingplan=<?php echo $this->_tpl_vars['h']['hostingplan']; ?>
&amount=<?php echo $this->_tpl_vars['h']['amount']; ?>
" class="btn hami-btn w-100 mb-30">Add to cart</a>

                            <div class="price-plan-desc">
                                <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['otherdetails']; ?>
</p>
                                <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['ramspace']; ?>
 RAM</p>
                                <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['bandwidth']; ?>
 bandwidth</p>
                                <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['storage']; ?>
</p>
                                <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['dbnumber']; ?>
 datbase(s)</p>
                            </div>

                            <a href="#" class="btn view-all-btn">Click here to see all features</a>
                        </div>
                    </div>
                    <?php endforeach; endif; unset($_from); ?>

                </div>
            </div>
        </section>


    </div>
    </div>
    </div>
    <!-- END: Content-->