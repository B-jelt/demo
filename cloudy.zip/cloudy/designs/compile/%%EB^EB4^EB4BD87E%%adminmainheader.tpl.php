<?php /* Smarty version 2.6.26, created on 2022-03-22 07:12:49
         compiled from adminmainheader.tpl */ ?>
<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Chameleon Admin is a modern Bootstrap 4 webapp &amp; admin dashboard html template with a large number of components, elegant design, clean and organized code.">
    <meta name="keywords" content="admin template, Chameleon admin template, dashboard template, gradient admin template, responsive admin template, webapp, eCommerce dashboard, analytic dashboard">
    <meta name="author" content="ThemeSelect">
    <link rel="apple-touch-icon" href="admin/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="https://themeselection.com/demo/chameleon-admin-template/app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,300i,400,400i,600,600i,700,700i%7CComfortaa:300,400,700" rel="stylesheet">
    <link href="admin/app-assets/fonts/line-awesome/css/line-awesome.min.css" rel="stylesheet">
    <link href="admin/app-assets/fonts/simple-line-icons/style.min.css" rel="stylesheet">
    <link href="admin/app-assets/fonts/feather/style.min.css" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="admin/app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/vendors/css/forms/toggle/switchery.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/plugins/forms/switch.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/core/colors/palette-switch.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/vendors/css/charts/chartist.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/vendors/css/charts/chartist-plugin-tooltip.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/vendors/css/tables/datatable/datatables.min.css">

    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/pages/login-register.min.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/core/menu/menu-types/horizontal-menu.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/core/colors/palette-gradient.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/fonts/line-awesome/css/line-awesome.min.css">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/pages/chat-application.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/pages/dashboard-analytics.min.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="admin/assets/css/style.css">
    <!-- END: Custom CSS-->

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="horizontal-layout horizontal-menu 2-columns  " data-open="hover" data-menu="horizontal-menu" data-color="bg-gradient-x-purple-blue" data-col="2-columns">

    <!-- BEGIN: Header-->
    <!-- fixed-top-->
    <nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow navbar-static-top navbar-light navbar-brand-center">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
                <li class="nav-item">
                    <a class="navbar-brand" href="admin.php"><img class="brand-logo" alt="creaative admin logo" src="user/img/core-img/xcloud-5.png.pagespeed.ic.ZM9oaDyLgP.png">
                        <h3 class="brand-text">Cloudy</h3>
                    </a>
                </li>
                <li class="nav-item d-md-none"><a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v"></i></a></li>
            </ul>
        </div>
        <div class="navbar-wrapper">
            <div class="navbar-container content">
                <div class="collapse navbar-collapse" id="navbar-mobile">
                    <ul class="nav navbar-nav mr-auto float-left">
                        <li class="nav-item d-none d-md-block"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu"></i></a></li>
                        <li class="nav-item d-none d-md-block"><a class="nav-link nav-link-expand" href="#"><i class="ficon ft-maximize"></i></a></li>
                        <li class="dropdown d-none d-md-block mr-1"><a class="dropdown-toggle nav-link" id="apps-navbar-links" href="#" data-toggle="dropdown">Feedback</a>
                            <div class="dropdown-menu">
                                <div class="arrow_box"><a class="dropdown-item" href="adminfeedback.php"><i class="ft-mail"></i>View Feedbacks</a></div>
                            </div>
                        </li>
                        <li class="nav-item dropdown navbar-search"><a class="nav-link dropdown-toggle hide" data-toggle="dropdown" href="#"><i class="ficon ft-search"></i></a>
                            <ul class="dropdown-menu">
                                <li class="arrow_box">
                                    <form>
                                        <div class="input-group search-box">
                                            <div class="position-relative has-icon-right full-width">
                                                <input class="form-control" id="search" type="text" placeholder="Search here...">
                                                <div class="form-control-position navbar-search-close"><i class="ft-x"></i></div>
                                            </div>
                                        </div>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav float-right">
                        <li class="nav-item"><a class="nav-link nav-link-label" href="staffnotification.php"><i class="ficon ft-bell bell-shake" id="notification-navbar-link"></i></a>

                        </li>
                        <li class="nav-item"><a class="nav-link nav-link-label" href="adminmessage.php"><i class="ficon ft-mail"></i></a>

                        </li>
                        <li class="dropdown dropdown-user nav-item">
                            <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown"> <span class="avatar avatar-online"><img src="admin/app-assets/images/portrait/small/admin.png" alt="avatar"></span></a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <div class="arrow_box_right">
                                    <a class="dropdown-item" href="#"><span class="avatar avatar-online"><img src="admin/app-assets/images/portrait/small/admin.png" alt="avatar"><span class="user-name text-bold-700 ml-1">Admin</span></span></a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="adminmessage.php"><i class="ft-mail"></i> My Inbox</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="logout.php"><i class="ft-power"></i> Logout</a>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <!-- END: Header-->


    <!-- BEGIN: Main Menu-->
    <div class="header-navbar navbar-expand-sm navbar navbar-horizontal navbar-fixed navbar-dark navbar-without-dd-arrow navbar-shadow" role="navigation" data-menu="menu-wrapper">
        <div class="navbar-container main-menu-content" data-menu="menu-container">
            <ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">
                <li class="nav-item"><a class="nav-link" href="admin.php"><i class="ft-home"></i><span>Home</span></a>
                </li>
                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><i class="ft-user"></i><span>Clients</span></a>
                    <ul class="dropdown-menu">
                        <div class="arrow_box">
                            <li data-menu=""><a class="dropdown-item" href="adminclientdetails.php" data-toggle="dropdown">Details</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="admindomainview.php" data-toggle="dropdown">Domains</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="adminfeedback.php" data-toggle="dropdown">Feedbacks</a>
                            </li>


                        </div>
                    </ul>
                </li>
                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="staffregister.php" data-toggle="dropdown"><i class="ft-users"></i><span>Staff</span></a>
                    <ul class="dropdown-menu">
                        <div class="arrow_box">
                            <li data-menu=""><a class="dropdown-item" href="staffregister.php" data-toggle="dropdown">Registration</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="adminstaffdetails.php" data-toggle="dropdown">Details</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="adminsalarydetails.php" data-toggle="dropdown">Salary</a>
                            </li>
                        </div>
                    </ul>
                </li>
                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="staffregister.php" data-toggle="dropdown"><i class="ft-server"></i><span>Hosting</span></a>
                    <ul class="dropdown-menu">
                        <div class="arrow_box">
                            <li data-menu=""><a class="dropdown-item" href="hostingplans.php" data-toggle="dropdown">Hosting Plans</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="hostingplansview.php" data-toggle="dropdown">Edit Plans</a>
                            </li>
                        </div>
                    </ul>
                </li>

                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="" data-toggle="dropdown"><i class="ft-globe"></i><span>Extensions</span></a>
                    <ul class="dropdown-menu">
                        <div class="arrow_box">
                            <li data-menu=""><a class="dropdown-item" href="extensionadd.php" data-toggle="dropdown">Add extensions</a>
                            </li>
                            <li data-menu=""><a class="dropdown-item" href="extensionview.php" data-toggle="dropdown">Edit extensions</a>
                            </li>
                        </div>
                    </ul>
                </li>

                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><i class="ft-grid"></i><span>Advertisements</span></a>
                    <ul class="dropdown-menu">
                        <div class="arrow_box">
                            <li data-menu=""><a class="dropdown-item" href="adminadsadd.php" data-toggle="dropdown">Add</a>
                                <a class="dropdown-item" href="adminadsview.php" data-toggle="dropdown">View</a>
                            </li>
                        </div>
                    </ul>
                </li>
                </li>
                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown"><i class="ft-bar-chart"></i><span>Accounts</span></a>
                    <ul class="dropdown-menu">
                        <div class="arrow_box">
                            <li data-menu="">
                                <a class="dropdown-item" href="monthlyincome.php" data-toggle="dropdown">Monthly Income</a>
                                <a class="dropdown-item" href="dailyincome.php" data-toggle="dropdown">Daily Income</a>
                            </li>
                        </div>
                    </ul>
                </li>


                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="" data-toggle="dropdown"><i class="ft-mail"></i><span>Messages</span></a>
                    <ul class="dropdown-menu">
                        <div class="arrow_box">
                            <li data-menu=""><a class="dropdown-item" href="adminmessage.php" data-toggle="dropdown">View</a>
                            </li>
                        </div>
                    </ul>
                </li>


                <li class="dropdown nav-item" data-menu="dropdown"><a class="dropdown-toggle nav-link" href="" data-toggle="dropdown"><i class="ft-bell"></i><span>Notifications</span></a>
                    <ul class="dropdown-menu">
                        <div class="arrow_box">
                            <li data-menu="">
                                <a class="dropdown-item" href="clientnotification.php" data-toggle="dropdown">Clients</a>
                                <a class="dropdown-item" href="staffnotification.php" data-toggle="dropdown">Staff</a>
                            </li>

                        </div>
                    </ul>
                </li>


            </ul>
        </div>
    </div>
    <!-- END: Main Menu-->


    <?php echo '
    <!-- BEGIN: Vendor JS-->
    <script src="admin/app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/vendors/js/forms/toggle/switchery.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/js/scripts/forms/switch.min.js" type="text/javascript"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script type="text/javascript" src="admin/app-assets/vendors/js/ui/jquery.sticky.js"></script>
    <script src="admin/app-assets/vendors/js/charts/chartist.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/vendors/js/charts/chartist-plugin-tooltip.min.js" type="text/javascript"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="admin/app-assets/js/core/app-menu.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/js/scripts/customizer.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/vendors/js/jquery.sharrre.js" type="text/javascript"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="admin/app-assets/js/scripts/pages/dashboard-analytics.min.js" type="text/javascript"></script>
    <!-- END: Page JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script type="text/javascript" src="admin/app-assets/vendors/js/ui/jquery.sticky.js"></script>
    <script src="admin/app-assets/vendors/js/pagination/jquery.twbsPagination.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/js/scripts/pagination/pagination.js" type="text/javascript"></script>
    <!-- END: Page Vendor JS-->


    <!-- BEGIN: datatable JS-->
    <script src="admin/app-assets/vendors/js/tables/datatable/datatables.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/js/scripts/tables/datatables/datatable-basic.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/js/scripts/tables/datatables/datatable-advanced.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/js/scripts/tables/datatables/datatable-styling.min.js" type="text/javascript"></script>
    <script src="admin/app-assets/js/scripts/tables/datatables/datatable-api.js" type="text/javascript"></script>
    <script src="admin/app-assets/js/scripts/tables/datatables-extensions/datatables-sources.min.js" type="text/javascript"></script>
    <!-- END: datatable JS-->

    <!-- BEGIN: datatable js 2 -->


    '; ?>