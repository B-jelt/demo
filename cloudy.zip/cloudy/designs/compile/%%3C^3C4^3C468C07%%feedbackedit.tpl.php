<?php /* Smarty version 2.6.26, created on 2022-01-16 11:44:23
         compiled from feedbackedit.tpl */ ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title" id="basic-layout-tooltip">Edit Your Feedback</h4>
            <a class="heading-elements-toggle">
                <i class="la la-ellipsis-v font-medium-3"></i>
            </a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li>
                        <a data-action="collapse">
                            <i class="ft-minus"></i>
                        </a>
                    </li>
                    <li>
                        <a data-action="reload">
                            <i class="ft-rotate-cw"></i>
                        </a>
                    </li>
                    <li>
                        <a data-action="expand">
                            <i class="ft-maximize"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="card-content collapse show">
            <div class="card-body">

                <form class="form" method="post" action="">
                    <?php $_from = $this->_tpl_vars['feedback']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['f']):
?>
                    <input type="hidden" name="hide" value="h">
                    <div class="form-body">

                        <div class="form-group">
                            <label for="projectinput1">Title</label>
                            <input type="text" id="projectinput1" class="form-control" placeholder="title" name="title" data-toggle="tooltip"
                             data-trigger="hover" data-placement="top" data-title="Title" value="<?php echo $this->_tpl_vars['f']['title']; ?>
">
                        </div>

                        <div class="form-group">
                            <label for="projectinput8">Feedback</label>
                            <textarea id="projectinput8" rows="5" class="form-control" name="feedback" placeholder="feedback" data-toggle="tooltip" data-trigger="hover"
                             data-placement="top" data-title="feedback"><?php echo $this->_tpl_vars['f']['feedback']; ?>
</textarea>
                        </div>

                    </div>

                    <div class="form-actions">
                        <button type="button" class="btn btn-danger mr-1">
                            <i class="ft-x"></i> Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="ft ft-check-circle"></i> Send
                        </button>
                    </div>
                    <?php endforeach; endif; unset($_from); ?>
                </form>
            </div>
        </div>
    </div>
</div>
</div>