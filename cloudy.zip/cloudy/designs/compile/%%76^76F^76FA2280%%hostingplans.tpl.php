<?php /* Smarty version 2.6.26, created on 2022-02-23 11:41:28
         compiled from hostingplans.tpl */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Set Hosting Plans - Admin</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="login/fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="login/css/style.css">
</head>

<body>

    <div class="main">

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Set Hosting Plans</h2>
                        <form method="POST" class="register-form" id="register-form" action="">
                            <input type="hidden" name="hide" value="h">
                            <div class="form-group">
                                <label for="hostingplan"><i class="zmdi zmdi-map material-icons-name"></i></label>
                                <input type="text" name="hostingplan" id="hostingplan" placeholder="Hosting Plan" />
                            </div>

                            <div class="form-group">
                                <label for="amount"><i class="zmdi zmdi-money material-icons-name"></i></label>
                                <input type="text" name="amount" id="amount" placeholder="Amount" />
                            </div>

                            <div class="form-group">
                                <label for="ramspace"><i class="zmdi zmdi-storage material-icons-name"></i></label>
                                <input type="text" name="ramspace" id="ramspace" placeholder="RAM Space" />
                            </div>

                            <div class="form-group">
                                <label for="bandwidth"><i class="zmdi zmdi-rss material-icons-name"></i></label>
                                <input type="text" name="bandwidth" id="bandwidth" placeholder="Bandwidth" />
                            </div>

                            <div class="form-group">
                                <label for="storage"><i class="zmdi zmdi-card-sd material-icons-name"></i></label>
                                <input type="text" name="storage" id="storage" placeholder="Storage" />
                            </div>

                            <div class="form-group">
                                <label for="dbnumber"><i class="zmdi zmdi-collection-item material-icons-name"></i></label>
                                <input type="text" name="dbnumber" id="dbnumber" placeholder="No. of databases" />
                            </div>

                            <div class="form-group">
                                <label for="otherdetails"><i class="zmdi zmdi-file-text material-icons-name"></i></label>
                                <input type="text" name="otherdetails" id="otherdetails" placeholder="Other details" />
                            </div>

                            <div class="form-group form-button">
                                <input type="submit" name="signup" id="signup" class="form-submit" value="Register" />
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="login/images/signup-image.jpg" alt="sing up image"></figure>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="login/vendor/jquery/jquery.min.js"></script>
    <script src="login/js/main.js"></script>
</body>

</html>