<?php /* Smarty version 2.6.26, created on 2022-03-19 10:04:16
         compiled from clientprofile.tpl */ ?>
<!-- BEGIN: Content-->


<!-- profile form start -->
<div class="card" style="height: auto;">
    <div class="card-header">
        <h4 class="card-title" id="basic-layout-round-controls">Edit Your Profile</h4>
        <a class="heading-elements-toggle">
            <i class="la la-ellipsis-v font-medium-3"></i>
        </a>
        <div class="heading-elements">
            <ul class="list-inline mb-0">
                <li>
                    <a data-action="collapse">
                        <i class="ft-minus"></i>
                    </a>
                </li>
                <li>
                    <a data-action="reload">
                        <i class="ft-rotate-cw"></i>
                    </a>
                </li>
                <li>
                    <a data-action="expand">
                        <i class="ft-maximize"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="card-content collapse show">
        <div class="card-body">
            <form class="form" method="post" action="" enctype="multipart/form-data">
                <input type="hidden" name="hide" value="h">
                <div class="form-body">

                    <?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>


                    <div class="form-group ">
                        <label for="complaintinput6">Profile Picture</label>
                        <input style="opacity: 75%; " type="file" id="complaintinput6 " class="form-control round pb-2" placeholder="Add Profile picture " name="profilepicture" value="<?php echo $this->_tpl_vars['b']['profilepicture']; ?>
">
                    </div>

                    <div class="form-group">
                        <label for="complaintinput1">Full Name</label>
                        <input style="opacity: 75%;" type="text" id="complaintinput1" class="form-control round" placeholder="full name" name="name" value="<?php echo $this->_tpl_vars['b']['name']; ?>
">
                    </div>

                    <div class="form-group ">
                        <label for="complaintinput2 ">Organization Name</label>
                        <input style="opacity: 75%;" type="text " id="complaintinput2 " class="form-control round " placeholder="organization name " name="orgname" value="<?php echo $this->_tpl_vars['b']['orgname']; ?>
">
                    </div>



                    <div class="form-group ">
                        <label for="complaintinput4 ">Contact No.</label>
                        <input style="opacity: 75%;" type="text " id="complaintinput4 " class="form-control round " placeholder="contact no " name="contactno" value="<?php echo $this->_tpl_vars['b']['contactno']; ?>
">
                    </div>

                    <div class="form-group ">
                        <label for="complaintinput6 ">E-mail</label>
                        <input style="opacity: 75%; " type="email " id="complaintinput6 " class="form-control round " placeholder="e-mail " name="email" value="<?php echo $this->_tpl_vars['b']['email']; ?>
">
                    </div>

                    <div class="form-group col-12 mb-2 ">
                        <label for="complaintinput3">Address</label>
                        <textarea rows="5" style="opacity: 75%;" id="complaintinput3" class="form-control round" name="address" placeholder="address" value="<?php echo $this->_tpl_vars['b']['address']; ?>
"><?php echo $this->_tpl_vars['b']['address']; ?>
</textarea>
                    </div>







                </div>

                <div class="form-actions ">
                    <a href="client.php" class="btn btn-danger mr-1">
                        <i class="ft-x "></i> Cancel
                    </a>

                    <button type="submit" name="submit" class="btn btn-primary ">
                        <i class="ft-check-circle"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php endforeach; endif; unset($_from); ?>
</div>
<!-- profile form end -->