<?php /* Smarty version 2.6.26, created on 2022-02-23 10:43:20
         compiled from serveradminhostingplansedit.tpl */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hosting Plans</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="login/fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="login/css/style.css">
</head>

<body>

    <div class="main">

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Edit Hosting Plans</h2>
                        <form method="POST" class="register-form" id="register-form" action="">
                            <?php $_from = $this->_tpl_vars['hostingplans']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['h']):
?>
                            <input type="hidden" name="hide" value="h">
                            <div class="form-group">
                                <label for="hostingplan"><i class="zmdi zmdi-map material-icons-name"></i></label>
                                <input type="text" name="hostingplan" id="hostingplan" placeholder="<?php echo $this->_tpl_vars['h']['hostingplan']; ?>
" value="<?php echo $this->_tpl_vars['h']['hostingplan']; ?>
" />
                            </div>

                            <div class="form-group">
                                <label for="amount"><i class="zmdi zmdi-money material-icons-name"></i></label>
                                <input type="text" name="amount" id="amount" placeholder="Hosting Plan" value="<?php echo $this->_tpl_vars['h']['amount']; ?>
" />
                            </div>

                            <div class="form-group">
                                <label for="ramspace"><i class="zmdi zmdi-storage material-icons-name"></i></label>
                                <input type="text" name="ramspace" id="ramspace" placeholder="RAM space" value="<?php echo $this->_tpl_vars['h']['ramspace']; ?>
" />
                            </div>

                            <div class="form-group">
                                <label for="bandwidth"><i class="zmdi zmdi-rss material-icons-name"></i></label>
                                <input type="text" name="bandwidth" id="bandwidth" placeholder="Bandwidth" value="<?php echo $this->_tpl_vars['h']['bandwidth']; ?>
" />
                            </div>

                            <div class="form-group">
                                <label for="storage"><i class="zmdi zmdi-card-sd material-icons-name"></i></label>
                                <input type="text" name="storage" id="storage" placeholder="Storage" value="<?php echo $this->_tpl_vars['h']['storage']; ?>
" />
                            </div>

                            <div class="form-group">
                                <label for="dbnumber"><i class="zmdi zmdi-collection-item material-icons-name"></i></label>
                                <input type="text" name="dbnumber" id="dbnumber" placeholder="no. of databases" value="<?php echo $this->_tpl_vars['h']['dbnumber']; ?>
" />
                            </div>

                            <div class="form-group">
                                <label for="otherdetails"><i class="zmdi zmdi-file-text material-icons-name"></i></label>
                                <input type="text" name="otherdetails" id="otherdetails" placeholder="Other details" value="<?php echo $this->_tpl_vars['h']['otherdetails']; ?>
" />
                            </div>

                            <div class="form-group form-button">
                                <input type="submit" name="signup" id="signup" class="form-submit" value="Register" />
                            </div>
                            <?php endforeach; endif; unset($_from); ?>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="login/images/signup-image.jpg" alt="sing up image"></figure>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="login/vendor/jquery/jquery.min.js"></script>
    <script src="login/js/main.js"></script>
</body>

</html>