<?php /* Smarty version 2.6.26, created on 2022-02-23 11:40:49
         compiled from adminstaffedit.tpl */ ?>
<title>Staff Profile Update - Admin</title>
<!-- BEGIN: Content-->


<!-- profile form start -->
<div class="card" style="height: 885.281px;">
    <div class="card-header">
        <h4 class="card-title" id="basic-layout-round-controls">Edit Staff Profile</h4>
        <a class="heading-elements-toggle">
            <i class="la la-ellipsis-v font-medium-3"></i>
        </a>
        <div class="heading-elements">
            <ul class="list-inline mb-0">
                <li>
                    <a data-action="collapse">
                        <i class="ft-minus"></i>
                    </a>
                </li>
                <li>
                    <a data-action="reload">
                        <i class="ft-rotate-cw"></i>
                    </a>
                </li>
                <li>
                    <a data-action="expand">
                        <i class="ft-maximize"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="card-content collapse show">
        <div class="card-body">
            <form class="form" method="post" action="">
                <input type="hidden" name="hide" value="h">
                <div class="form-body">

                    <?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['s']):
?>

                    <div class="form-group">
                        <label for="complaintinput1">Staff Name</label>
                        <input style="opacity: 75%;" type="text" id="complaintinput1" class="form-control round" placeholder="Staff name" name="staffname" value="<?php echo $this->_tpl_vars['s']['staffname']; ?>
">
                    </div>

                    <div class="col-xl-12">
                        <div class="form-group ">
                            <label for="default-select">Designation</label>
                            <select name="designation" class="select2 form-control rounded-pill" id="default-select" style="opacity: 75%;">
                                           <option value="<?php echo $this->_tpl_vars['s']['designation']; ?>
"><?php echo $this->_tpl_vars['s']['designation']; ?>
</option>
                                            <option value="Finance Manager">Finance Manager</option>
											<option value="Server Admin">Server Admin</option>
											<option value="Technical Manager">Technical Manager</option>
											<option value="Ads Manager">Ads Manager</option>
									</select>
                        </div>
                    </div>


                    <div class="form-group ">
                        <label for="complaintinput4 ">Contact No.</label>
                        <input style="opacity: 75%;" type="text " id="complaintinput4 " class="form-control round " placeholder="contact no " name="contactno" value="<?php echo $this->_tpl_vars['s']['contactno']; ?>
">
                    </div>

                    <div class="form-group ">
                        <label for="complaintinput6 ">E-mail</label>
                        <input style="opacity: 75%; " type="email " id="complaintinput6 " class="form-control round " placeholder="e-mail " name="email" value="<?php echo $this->_tpl_vars['s']['email']; ?>
">
                    </div>
                </div>

                <div class="form-actions ">
                    <a href="client.php" class="btn btn-danger mr-1">
                        <i class="ft-x "></i> Cancel</a>
                    <button type="submit" class="btn btn-primary ">
                                            <i class="ft-check-circle"></i> Save
                                        </button>
                </div>
            </form>
        </div>
    </div>
    <?php endforeach; endif; unset($_from); ?>
</div>
<!-- profile form end -->