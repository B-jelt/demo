<?php /* Smarty version 2.6.26, created on 2022-02-23 11:42:23
         compiled from hostingplansview.tpl */ ?>
<title>View Hosting Plans - Admin</title>
<!-- BEGIN: Content-->
<div class="content-body">
    <!-- Zero configuration table -->
    <section id="configuration">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Your Feedbacks</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body card-dashboard">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered zero-configuration">
                                    <thead>
                                        <tr>
                                            <th>Plan</th>
                                            <th>Amount</th>
                                            <th>RAM space</th>
                                            <th>Bandwidth</th>
                                            <th>Storage</th>
                                            <th>No. of Databases</th>
                                            <th>Other Details</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $_from = $this->_tpl_vars['hostingplans']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['h']):
?>
                                        <tr>
                                            <td><?php echo $this->_tpl_vars['h']['hostingplan']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['h']['amount']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['h']['ramspace']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['h']['bandwidth']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['h']['storage']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['h']['dbnumber']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['h']['otherdetails']; ?>
</td>
                                            <td><a href="hostingplansedit.php?key=<?php echo $this->_tpl_vars['h']['hostkey']; ?>
" class="btn btn-info">Edit</a></td>
                                            <td><a href="hostingplansdelete.php?key=<?php echo $this->_tpl_vars['h']['hostkey']; ?>
" class="btn btn-danger ">Delete</a></td>
                                        </tr>
                                        <?php endforeach; endif; unset($_from); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ Zero configuration table -->

    <!-- END: Content-->