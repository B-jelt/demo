<?php /* Smarty version 2.6.26, created on 2022-02-26 10:07:35
         compiled from index.tpl */ ?>
<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Cloudy - Domains & Web Hosting Solutions</title>

    <link rel="icon" href="user/img/core-img/xcloud-5.png.pagespeed.ic.ZM9oaDyLgP.png">


    <!-- BEGIN: Theme CSS-->
    <link href="admin/app-assets/fonts/line-awesome/css/line-awesome.min.css" rel="stylesheet">
    <link href="admin/app-assets/fonts/simple-line-icons/style.min.css" rel="stylesheet">
    <link href="admin/app-assets/fonts/feather/style.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="admin/app-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="user/prompt.css">
    <!-- END: Theme CSS-->

    <link rel="stylesheet" href="user/style.css"> <?php echo '


    <script>
        (function(w, d) {
            ! function(e, t, r, a, s) {
                e[r] = e[r] || {}, e[r].executed = [], e.zaraz = {
                    deferred: []
                };
                var n = t.getElementsByTagName("title")[0];
                e[r].c = t.cookie, n && (e[r].t = t.getElementsByTagName("title")[0].text), e[r].w = e.screen.width, e[r].h = e.screen.height, e[r].j = e.innerHeight, e[r].e = e.innerWidth, e[r].l = e.location.href, e[r].r = t.referrer, e[r].k = e.screen.colorDepth, e[r].n = t.characterSet, e[r].o = (new Date).getTimezoneOffset(), //
                    e[s] = e[s] || [], e.zaraz._preTrack = [], e.zaraz.track = (t, r) => e.zaraz._preTrack.push([t, r]), e[s].push({
                        "zaraz.start": (new Date).getTime()
                    });
                var i = t.getElementsByTagName(a)[0],
                    o = t.createElement(a);
                o.defer = !0, o.src = "../../cdn-cgi/zaraz/sd41d.js?" + new URLSearchParams(e[r]).toString(), i.parentNode.insertBefore(o, i)
            }(w, d, "zarazData", "script", "dataLayer");
        })(window, document);
    </script>
    '; ?>

</head>

<body>

    <div id="preloader">
        <div class="loader"></div>
    </div>


    <header class="header-area">

        <div class="top-header-area">
            <div class="container">
                <div class="row">
                    <div class="col-6">
                        <div class="top-header-content">
                            <a href="#"><i class="fa fa-phone" aria-hidden="true"></i> <span>Call Us: 001-1234-88888</span></a>
                            <a href="#"><i class="fa fa-envelope" aria-hidden="true"></i> <span>Email: <span class="__cf_email__" data-cfemail="234a4d454c0d404c4f4c4f4a4163444e424a4f0d404c4e">[email&#160;protected]</span></span></a>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="top-header-content">

                            <a href="login.php"><i class="fa fa-lock" aria-hidden="true"></i> <span>Login / Register</span></a>


                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="main-header-area">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">

                    <nav class="classy-navbar justify-content-between" id="hamiNav">

                        <a class="nav-brand" href="index.html"><img src="user/img/core-img/xlogo.png.pagespeed.ic.cpOUPeRNvj.png" alt=""></a>

                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <div class="classy-menu">

                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <div class="classynav">
                                <ul id="nav">
                                    <li class="active"><a href="#">Home</a></li>
                                    <li><a href="#features">Features</a></li>
                                    <li><a href="#domains">Domains</a></li>
                                    <li><a href="#servers">Servers</a></li>
                                    <li><a href="about.html">About</a></li>
                                </ul>

                                <div class="live-chat-btn ml-5 mt-4 mt-lg-0 ml-md-4">
                                    <a href="#" class="btn hami-btn live--chat--btn"><i class="fa fa-comments" aria-hidden="true"></i> Contact Us</a>
                                </div>
                            </div>

                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>


    <section class="welcome-area">

        <div class="welcome-pattern">
            <img src="user/img/core-img/xwelcome-pattern.png.pagespeed.ic.96dED43qjX.png" alt="">
        </div>

        <div class="welcome-slides owl-carousel">

            <div class="single-welcome-slide">

                <div class="welcome-content h-100">
                    <div class="container h-100">
                        <div class="row h-100 align-items-center">

                            <div class="col-12 col-md-9 col-lg-7">
                                <div class="welcome-text mb-50">
                                    <h2 data-animation="fadeInLeftBig" data-delay="200ms" data-duration="1s">The Best <br> Web Hosting</h2>
                                    <h3 data-animation="fadeInLeftBig" data-delay="400ms" data-duration="1s">Starting at <span>$7.99</span> $2.95/month*</h3>
                                    <p data-animation="fadeInLeftBig" data-delay="600ms" data-duration="1s">Everything you will EVER need to Host and Manage your Website!</p>
                                    <a href="#" class="btn hami-btn btn-2" data-animation="fadeInLeftBig" data-delay="800ms" data-duration="1s">Get Start Now!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="welcome-thumbnail">
                    <img src="user/img/bg-img/1.png" alt="">
                </div>
            </div>

            <div class="single-welcome-slide">

                <div class="welcome-content h-100">
                    <div class="container h-100">
                        <div class="row h-100 align-items-center">

                            <div class="col-12 col-md-9 col-lg-7">
                                <div class="welcome-text mb-50">
                                    <h2 data-animation="fadeInUpBig" data-delay="200ms" data-duration="1s">The Best <br> Web Hosting</h2>
                                    <h3 data-animation="fadeInUpBig" data-delay="400ms" data-duration="1s">Starting at <span>$7.99</span> $2.95/month*</h3>
                                    <p data-animation="fadeInUpBig" data-delay="600ms" data-duration="1s">Everything you will EVER need to Host and Manage your Website!</p>
                                    <a href="#" class="btn hami-btn btn-2" data-animation="fadeInUpBig" data-delay="800ms" data-duration="1s">Get Start Now!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="welcome-thumbnail">
                    <img src="user/img/bg-img/2.png" alt="">
                </div>
            </div>
        </div>

        <div class="clouds">
            <img src="user/img/core-img/xcloud-1.png.pagespeed.ic.iIKuycH7Nd.png" alt="" class="cloud-1">
            <img src="user/img/core-img/xcloud-2.png.pagespeed.ic.Is9oI46RmZ.png" alt="" class="cloud-2">
            <img src="user/img/core-img/xcloud-3.png.pagespeed.ic.jze25RQfT9.png" alt="" class="cloud-3">
            <img src="user/img/core-img/xcloud-4.png.pagespeed.ic.BjHvMPcXVt.png" alt="" class="cloud-4">
            <img src="user/img/core-img/xcloud-5.png.pagespeed.ic.ZM9oaDyLgP.png" alt="" class="cloud-5">
        </div>
    </section>


    <section class="find-domain-area section-padding-100-0" id="domains">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-md-4">
                    <div class="domain-text mb-100">
                        <h2>Find Your Perfect Domain Name</h2>
                        <h6>Only $7 for the first year</h6>
                    </div>
                </div>
                <div class="col-12 col-md-8">
                    <div class="domain-search-form mb-100">
                        <form action="#" method="post" class="form-inline">
                            <input type="hidden" name="hide" value="h">
                            <input type="search" placeholder="Enter Your Domain Name Here" name="domainname">
                            <select name="extension" id="domainExtension">
                                <?php $_from = $this->_tpl_vars['extension']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['e']):
?>
                                <option value="<?php echo $this->_tpl_vars['e']['extension']; ?>
"><?php echo $this->_tpl_vars['e']['extension']; ?>
</option>
                                <?php endforeach; endif; unset($_from); ?>
                            </select>
                            <button type="submit">Search Domain</button>
                        </form>
                        <?php if ($this->_tpl_vars['domain'] == 'taken'): ?>
                        <div class="alert round bg-danger alert-icon-left alert-dismissible mb-2 mt-1" style="border-radius: 25px;" role="alert">
                            <span class="alert-icon">
                                <i class="ft-thumbs-down"></i>
                            </span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"></span>
                            </button>
                            <strong>Oh snap!</strong> your domain name is already taken... try something else.
                            <!-- <a href="#" class="alert-link"></a> -->
                        </div>
                        <?php elseif ($this->_tpl_vars['domain'] == 'available'): ?>
                        <div class="alert round bg-success alert-icon-right alert-dismissible mb-2 mt-1" style="border-radius: 25px;" role="alert">
                            <span class="alert-icon">
                                <a href="client.php"><i class="ft-shopping-cart white" style="color: white;"></i></a>
                            </span>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"></span>
                            </button>
                            <strong>Your domain name is available!!</strong>
                            <!-- <a href="#" class="alert-link">your attention</a>, and it's important. -->
                        </div>
                        <?php else: ?> <?php endif; ?>
                        <div class="domain-price-help mt-50 d-flex align-items-center justify-content-between ">
                            <p>.COM $5.75</p>
                            <p>.NET $9.45</p>
                            <p>.ORG $7.50</p>
                            <p>.US $5.99</p>
                            <p>.BIZ $9.99</p>
                            <p>.CO $6.0</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="hami-features-area bg-gray section-padding-100" id="features">
        <div class="container">
            <div class="row">

                <div class="col-12">
                    <div class="section-heading text-center">
                        <h2>Overall Features</h2>
                        <p>Our revolutionary Cloud solution is powerful, simple, and surprisingly affordable.</p>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature-area d-flex mb-50">
                        <div class="feature-icon">
                            <i class="icon_cloud-upload_alt"></i>
                        </div>
                        <div class="feature-text">
                            <h5>Auto Updates</h5>
                            <p>Don't be distracted by criticism. Remember the only taste of success some people.</p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature-area d-flex mb-50">
                        <div class="feature-icon">
                            <i class="icon_adjust-vert"></i>
                        </div>
                        <div class="feature-text">
                            <h5>Optimized Software</h5>
                            <p>Don't be distracted by criticism. Remember the only taste of success some people.</p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature-area d-flex mb-50">
                        <div class="feature-icon">
                            <i class="icon_archive_alt"></i>
                        </div>
                        <div class="feature-text">
                            <h5>Daily Backups</h5>
                            <p>Don't be distracted by criticism. Remember the only taste of success some people.</p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature-area d-flex mb-50">
                        <div class="feature-icon">
                            <i class="icon_globe-2"></i>
                        </div>
                        <div class="feature-text">
                            <h5>Wide Networking</h5>
                            <p>Don't be distracted by criticism. Remember the only taste of success some people.</p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature-area d-flex mb-50">
                        <div class="feature-icon">
                            <i class="icon_shield"></i>
                        </div>
                        <div class="feature-text">
                            <h5>Protected</h5>
                            <p>Don't be distracted by criticism. Remember the only taste of success some people.</p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature-area d-flex mb-50">
                        <div class="feature-icon">
                            <i class="icon_headphones"></i>
                        </div>
                        <div class="feature-text">
                            <h5>Free Support</h5>
                            <p>Don't be distracted by criticism. Remember the only taste of success some people.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="feature-pattern">
            <img src="user/img/core-img/xwelcome-pattern.png.pagespeed.ic.96dED43qjX.png" alt="">
        </div>
    </section>


    <section class="hami-price-plan-area mt-50" id="servers">
        <div class="container">
            <div class="row">

                <div class="col-12">
                    <div class="section-heading text-center">
                        <h2>Choose Your Web Hosting Plan</h2>
                        <p>You want custom hosting plan. No hidden charge.</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">

                <?php $_from = $this->_tpl_vars['hostingplans']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['h']):
?>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-price-plan mb-100">

                        <div class="price-plan-title">
                            <h4><?php echo $this->_tpl_vars['h']['hostingplan']; ?>
</h4>
                            <p>On sale - Save 50%</p>
                        </div>

                        <div class="price-plan-value">
                            <h2><span>₹</span><?php echo $this->_tpl_vars['h']['amount']; ?>
</h2>
                            <p>/per month</p>
                        </div>

                        <a href="#" class="btn hami-btn w-100 mb-30">Add to cart</a>

                        <div class="price-plan-desc">
                            <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['otherdetails']; ?>
</p>
                            <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['ramspace']; ?>
 RAM</p>
                            <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['bandwidth']; ?>
 bandwidth</p>
                            <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['storage']; ?>
</p>
                            <p><i class="icon_check"></i> <?php echo $this->_tpl_vars['h']['dbnumber']; ?>
 datbase(s)</p>
                        </div>

                        <a href="#" class="btn view-all-btn">Click here to see all features</a>
                    </div>
                </div>
                <?php endforeach; endif; unset($_from); ?>

                <!-- <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-price-plan active mb-100">

                        <div class="popular-tag">
                            <i class="icon_star"></i> Best Plan <i class="icon_star"></i>
                        </div>

                        <div class="price-plan-title">
                            <h4>Advanced Hosting</h4>
                            <p>On sale - Save 70%</p>
                        </div>

                        <div class="price-plan-value">
                            <h2><span>$</span>3.99</h2>
                            <p>/per month</p>
                        </div>

                        <a href="#" class="btn hami-btn w-100 mb-30">Get Started</a>

                        <div class="price-plan-desc">
                            <p><i class="icon_check"></i> Unlimited Number of Websites</p>
                            <p><i class="icon_check"></i> Unlimited Email Accounts</p>
                            <p><i class="icon_check"></i> Unlimited Bandwidth</p>
                            <p><i class="icon_check"></i> 2X Processing Power &amp; Memory</p>
                        </div>

                        <a href="#" class="btn view-all-btn">Click here to see all features</a>
                    </div>
                </div>

                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-price-plan mb-100">

                        <div class="price-plan-title">
                            <h4>Unlimited Hosting</h4>
                            <p>On sale - Save 50%</p>
                        </div>

                        <div class="price-plan-value">
                            <h2><span>$</span>7.99</h2>
                            <p>/per month</p>
                        </div>

                        <a href="#" class="btn hami-btn w-100 mb-30">Get Started</a>

                        <div class="price-plan-desc">
                            <p><i class="icon_check"></i> Unlimited Number of Websites</p>
                            <p><i class="icon_check"></i> Unlimited Email Accounts</p>
                            <p><i class="icon_check"></i> Unlimited Bandwidth</p>
                            <p><i class="icon_check"></i> 2X Processing Power &amp; Memory</p>
                        </div>

                        <a href="#" class="btn view-all-btn">Click here to see all features</a>
                    </div>
                </div> -->
            </div>
        </div>
    </section>


    <section class="hami-call-to-action bg-gray section-padding-100-0">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="cta-thumbnail mb-100">
                        <img src="user/img/bg-img/2.png" alt="">
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="cta--content mb-100">
                        <h2>Up to 70% Discount with FREE Domain Name Registration Included!</h2>

                        <div class="cta-desc mb-50">
                            <h6><i class="icon_check"></i> FREE Domain Name</h6>
                            <h6><i class="icon_check"></i> FREE Email Address</h6>
                            <h6><i class="icon_check"></i> Plenty of Disk Space</h6>
                            <h6><i class="icon_check"></i> FREE Website Builder</h6>
                            <h6><i class="icon_check"></i> FREE Marketing Tools</h6>
                            <h6><i class="icon_check"></i> 1-Click WordPress Install</h6>
                        </div>

                        <a href="#" class="btn hami-btn">Get Start Now!</a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="hami-support-area bg-gray">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="support-text">
                        <h2>Need help? Call our award-winning support team 24/7: +65 1234-6868</h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="support-pattern" style="background-image:url(user/img/core-img/xsupport-pattern.png.pagespeed.ic.v6dSbBmWDr.png)"></div>
    </section>

    <section class="hami-suctapport-area">
        <div class="container">
            <div class="row cta-text p-5">
                <?php $_from = $this->_tpl_vars['indexadsview']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['a']):
?>
                <div class="col-2">
                    <img src="<?php echo $this->_tpl_vars['a']['path']; ?>
" alt="advertisement" width="250" height="250">
                </div>
                <?php endforeach; endif; unset($_from); ?>
            </div>
        </div>

    </section>


    <section class="hami-cta-area">
        <div class="container">
            <div class="cta-text">
                <h2>Proudly Hosting Over <span class="counter">800,000</span> Websites Since 2000</h2>
            </div>
        </div>
    </section>


    <footer class="footer-area section-padding-80-0">

        <div class="main-footer-area">
            <div class="container">
                <div class="row justify-content-between">

                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="single-footer-widget mb-80">

                            <h5 class="widget-title">Products</h5>

                            <ul class="footer-nav">
                                <li><a href="#">Shared hosting</a></li>
                                <li><a href="#">WordPress hosting</a></li>
                                <li><a href="#">Vps hosting</a></li>
                                <li><a href="#">Dedicated hosting</a></li>
                                <li><a href="#">Reseller hosting</a></li>
                                <li><a href="#">Hosting features</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="single-footer-widget mb-80">

                            <h5 class="widget-title">Programs</h5>

                            <ul class="footer-nav">
                                <li><a href="#">WordPress</a></li>
                                <li><a href="#">Affiliates</a></li>
                                <li><a href="#">Marketing services</a></li>
                                <li><a href="#">WordPress guide</a></li>
                                <li><a href="#">Testimonials</a></li>
                                <li><a href="#">Awards &amp; Reviews</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="single-footer-widget mb-80">

                            <h5 class="widget-title">Products</h5>

                            <ul class="footer-nav">
                                <li><a href="#">Shared hosting</a></li>
                                <li><a href="#">WordPress hosting</a></li>
                                <li><a href="#">Vps hosting</a></li>
                                <li><a href="#">Dedicated hosting</a></li>
                                <li><a href="#">Reseller hosting</a></li>
                                <li><a href="#">Hosting features</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-6 col-sm-4 col-lg-2">
                        <div class="single-footer-widget mb-80">

                            <h5 class="widget-title">Company</h5>

                            <ul class="footer-nav">
                                <li><a href="#">About</a></li>
                                <li><a href="#">Careers</a></li>
                                <li><a href="#">Contact</a></li>
                                <li><a href="#">Terms of service</a></li>
                                <li><a href="#">Privacy policy</a></li>
                                <li><a href="#">Blog</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-12 col-sm-8 col-lg-4">
                        <div class="single-footer-widget mb-80">

                            <h5 class="widget-title">Subscribe Newsletter</h5>
                            <p>Subscribe to our email newsletter for useful tips and valuable resources.</p>

                            <form action="https://preview.colorlib.com/theme/hami/index.html" class="nl-form">
                                <input type="email" class="form-control" placeholder="Your Mail">
                                <button type="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                            </form>

                            <div class="social-info">
                                <a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#" class="twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#" class="google-plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                <a href="#" class="instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="#" class="youtube"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bottom-footer-area bg-gray">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-6">

                        <div class="copywrite-text">
                            <p>
                                Copyright &copy; <?php echo '
                                <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
                                <script>
                                    document.write(new Date().getFullYear());
                                </script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com/" target="_blank">Colorlib</a>

                            </p>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">

                        <div class="payments-methods d-flex align-items-center">
                            <p>Payments We Accept</p>
                            <i class="fa fa-cc-visa" aria-hidden="true"></i>
                            <i class="fa fa-cc-mastercard" aria-hidden="true"></i>
                            <i class="fa fa-cc-discover" aria-hidden="true"></i>
                            <i class="fa fa-cc-amex" aria-hidden="true"></i>
                            <i class="fa fa-cc-paypal" aria-hidden="true"></i>
                            <i class="fa fa-cc-stripe" aria-hidden="true"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>



    <script src="user/js/jquery.min.js"></script>

    <script src="user/js/popper.min.js%2bbootstrap.min.js.pagespeed.jc.9bt6F4IgP2.js"></script>
    <script>
        eval(mod_pagespeed_Z7sDXObmXx);
    </script>

    <script>
        eval(mod_pagespeed_n1l_ORAqCR);
    </script>

    <script src="user/js/hami.bundle.js"></script>

    <script src="user/js/default-assets/active.js"></script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag(\'js\', new Date());

        gtag(\'config\', \'UA-23581568-13\');
    </script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon=\'{"rayId":"6c69791e8fd484ad","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2021.12.0","si":100}\'
        crossorigin="anonymous"></script>



    <!--Start of Tawk.to Script-->
    <script id="live-chat" type="text/javascript">
        var Tawk_API = Tawk_API || {},
            Tawk_LoadStart = new Date();
        (function() {
            var s1 = document.createElement("script"),
                s0 = document.getElementsByTagName("script")[0];
            s1.async = true;
            s1.src = \'https://embed.tawk.to/6219dedea34c245641287141/1fsqgtaou\';
            s1.charset = \'UTF-8\';
            s1.setAttribute(\'crossorigin\', \'*\');
            s0.parentNode.insertBefore(s1, s0);
        })();
    </script>
    <!--End of Tawk.to Script-->


    '; ?>


</body>


</html>