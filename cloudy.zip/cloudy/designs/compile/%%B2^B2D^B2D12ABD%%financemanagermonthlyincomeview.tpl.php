<?php /* Smarty version 2.6.26, created on 2022-02-25 08:36:27
         compiled from financemanagermonthlyincomeview.tpl */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Income</title>
</head>

<body>

    <section id="minimal-statistics-bg">
        <div class="card">
            <div class="row">
                <div class="col-12 mt-3 mb-1">
                    <h4 class="text-uppercase">Monthly Revenue</h4>
                    <p>Total revenue of the selected month and related details.</p>
                </div>
            </div>
            <div class="row py-5 px-2">
                <div class="col-xl-4 col-lg-6 col-12">
                    <div class="card bg-gradient-x-purple-red">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media d-flex">
                                    <div class="align-self-top">
                                        <i class="icon-users icon-opacity text-white font-large-4 float-left"></i>
                                    </div>
                                    <div class="media-body text-white text-right align-self-bottom mt-3">
                                        <span class="d-block mb-1 font-medium-1">Total Customers</span>
                                        <h1 class="text-white mb-0"><?php echo $this->_tpl_vars['monthlyincomeview'][1]; ?>
</h1>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-12">
                    <div class="card bg-gradient-x-blue-green">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media d-flex">
                                    <div class="align-self-top">
                                        <i class="icon-basket-loaded icon-opacity text-white font-large-4 float-left"></i>
                                    </div>
                                    <div class="media-body text-white text-right align-self-bottom mt-3">
                                        <span class="d-block mb-1 font-medium-1">Total Order</span>
                                        <h1 class="text-white mb-0"><?php echo $this->_tpl_vars['monthlyincomeview'][2]; ?>
</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-12">
                    <div class="card bg-gradient-x-orange-yellow">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media d-flex">
                                    <div class="align-self-top">
                                        <i class="icon-wallet icon-opacity text-white font-large-4 float-left"></i>
                                    </div>
                                    <div class="media-body text-white text-right align-self-bottom mt-3">
                                        <span class="d-block mb-1 font-medium-1">Total Revenue</span>
                                        <h1 class="text-white mb-0">₹<?php echo $this->_tpl_vars['monthlyincomeview'][0]; ?>
</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>

</html>