<?php /* Smarty version 2.6.26, created on 2022-03-22 07:36:37
         compiled from clientfeedback.tpl */ ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title" id="basic-layout-tooltip">Send Feedback</h4>
            <a class="heading-elements-toggle">
                <i class="la la-ellipsis-v font-medium-3"></i>
            </a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li>
                        <a data-action="collapse">
                            <i class="ft-minus"></i>
                        </a>
                    </li>
                    <li>
                        <a data-action="reload">
                            <i class="ft-rotate-cw"></i>
                        </a>
                    </li>
                    <li>
                        <a data-action="expand">
                            <i class="ft-maximize"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="card-content collapse show">
            <div class="card-body">

                <form class="form" method="post" action="">
                    <input type="hidden" name="hide" value="h">
                    <div class="form-body">

                        <div class="form-group">
                            <label for="projectinput1">Title</label>
                            <input type="text" id="projectinput1" class="form-control" placeholder="title" name="title" data-toggle="tooltip" data-trigger="hover" data-placement="top" data-title="Title">
                        </div>

                        <div class="form-group">
                            <label for="projectinput8">Feedback</label>
                            <textarea id="projectinput8" rows="5" class="form-control" name="feedback" placeholder="feedback" data-toggle="tooltip" data-trigger="hover" data-placement="top" data-title="feedback"></textarea>
                        </div>

                    </div>

                    <div class="form-actions">
                        <button type="button" class="btn btn-danger mr-1">
									<i class="ft-x"></i> Cancel
								</button>
                        <button type="submit" class="btn btn-primary">
									<i class="ft ft-check-circle"></i> Send
								</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>

<!-- BEGIN: Content-->
<div class="content-body">
    <!-- Zero configuration table -->
    <section id="configuration">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Your Feedbacks</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body card-dashboard">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered zero-configuration">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Feedback</th>
                                            <th>Date</th>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $_from = $this->_tpl_vars['feedback']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['f']):
?>
                                        <tr>
                                            <td><?php echo $this->_tpl_vars['f']['title']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['f']['feedback']; ?>
</td>
                                            <td><?php echo $this->_tpl_vars['f']['currentdate']; ?>
</td>
                                            <td><a href="feedbackedit.php?key=<?php echo $this->_tpl_vars['f']['feedkey']; ?>
" class="btn btn-info">Edit</a></td>
                                            <td><a href="feedbackdelete.php?key=<?php echo $this->_tpl_vars['f']['feedkey']; ?>
" class="btn btn-danger ">Delete</a></td>
                                        </tr>
                                        <?php endforeach; endif; unset($_from); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ Zero configuration table -->

    <!-- END: Content-->