<?php /* Smarty version 2.6.26, created on 2022-02-26 10:33:13
         compiled from cart.tpl */ ?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>







    <link rel="stylesheet" href="cart/bootstrap.min.css">
    <link rel="stylesheet" href="cart/all.css">
    <link rel="stylesheet" href="cart/style.css">

    <title>Cart</title>

</head>

<body>
    <div class="container mt-4 p-0 my-5">
        <div class="row px-md-4 px-2 pt-4">
            <div class="col-lg-8 pt-5">
                <p class="pb-2 fw-bold">Order</p>
                <div class="card">
                    <div>
                        <div class="table-responsive px-md-4 px-2 pt-3">
                            <table class="table table-borderless">
                                <tbody>


                                    <?php if ($this->_tpl_vars['cartitems'] == 'empty'): ?>

                                    <tr class="p-5">
                                        <td>
                                            <div class="d-flex align-items-center justify-content-center py-5">
                                                <p class="fw-bold text-muted">Oops... Seems like there's nothing in your cart yet!</p>
                                                <div class="ps-3">
                                                    <a href="client.php" class="btn btn-info text-white btn-bg-gradient-x-blue-cyan">Purchase</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    <?php else: ?> <?php $_from = $this->_tpl_vars['cartitemsview']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>

                                    <tr class="border-top border-bottom">
                                        <td>
                                            <div class="d-flex align-items-center py-4">
                                                <div class="ps-3 d-flex flex-column justify-content">
                                                    <p class="fw-bold"><?php echo $this->_tpl_vars['b']['product']; ?>
</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex py-4">
                                                <p class="pe-3"><span class="red">₹<?php echo $this->_tpl_vars['b']['amount']; ?>
</span></p>
                                                <p class="text-muted text-decoration-line-through">₹<?php echo $this->_tpl_vars['b']['amount']; ?>
</p>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center py-4"> <span class="pe-3 text-muted">Quantity</span> <span class="pe-3"> <input class="ps-2" type="number" value="<?php echo $this->_tpl_vars['b']['quantity']; ?>
"></span>
                                            </div>
                                        </td>
                                        <td><a href="cartitemsdelete.php?key=<?php echo $this->_tpl_vars['b']['cartkey']; ?>
" class="btn btn-danger my-4">Delete</a></td>
                                        <td><a href="payment.php?amount=<?php echo $this->_tpl_vars['b']['amount']; ?>
&id=<?php echo $this->_tpl_vars['b']['id']; ?>
" class="btn btn-info text-white my-4">Buy Now</a></td>
                                    </tr>

                                    <?php endforeach; endif; unset($_from); ?> <?php endif; ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 payment-summary pt-5">
                <p class="fw-bold pt-lg-0 pt-4 pb-2">Payment Summary</p>
                <div class="card px-md-3 px-2 pt-4">
                    <div class="d-flex justify-content-between pb-3"> <small class="text-muted">Transaction code</small>
                        <p class="">VC115665</p>
                    </div>
                    <div class="d-flex justify-content-between b-bottom"> <input type="text" class="ps-2" placeholder="COUPON CODE">
                        <div class="btn btn-primary">Apply</div>
                    </div>
                    <div class="d-flex flex-column b-bottom">
                        <div class="d-flex justify-content-between py-3"> <small class="text-muted">Order Summary</small>
                            <p>$122</p>
                        </div>
                        <div class="d-flex justify-content-between pb-3"> <small class="text-muted">Additional Service</small>
                            <p>$22</p>
                        </div>
                        <div class="d-flex justify-content-between"> <small class="text-muted">Total Amount</small>
                            <p>$132</p>
                        </div>
                    </div>
                    <div class="sale my-3"> <span>sale<span class="px-1">expiring</span><span>in</span>:</span><span class="red">21<span class="ps-1">hours</span>,31<span class="ps-1 ">minutes</span></span>
                    </div>
                </div>
                <a href="checkout.php"><button type="button" class="btn btn-block btn-bg-gradient-x-blue-cyan col-12 mr-1 mb-5 white">Checkout</button></a>
            </div>

        </div>
    </div>

</body>