<?php /* Smarty version 2.6.26, created on 2022-01-02 11:06:33
         compiled from subheader.tpl */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Hami - Web Hosting HTML Template</title>

    <link rel="icon" href="user/img/core-img/favicon.png">

    <link rel="stylesheet" href="user/A.style.css.pagespeed.cf.PHEI_QyW-K.css"> <?php echo '
    <script>
        (function(w, d) {
            ! function(e, t, r, a, s) {
                e[r] = e[r] || {}, e[r].executed = [], e.zaraz = {
                    deferred: []
                };
                var n = t.getElementsByTagName("title")[0];
                e[r].c = t.cookie, n && (e[r].t = t.getElementsByTagName("title")[0].text), e[r].w = e.screen.width, e[r].h = e.screen.height, e[r].j = e.innerHeight, e[r].e = e.innerWidth, e[r].l = e.location.href, e[r].r = t.referrer, e[r].k = e.screen.colorDepth, e[r].n = t.characterSet, e[r].o = (new Date).getTimezoneOffset(), //
                    e[s] = e[s] || [], e.zaraz._preTrack = [], e.zaraz.track = (t, r) => e.zaraz._preTrack.push([t, r]), e[s].push({
                        "zaraz.start": (new Date).getTime()
                    });
                var i = t.getElementsByTagName(a)[0],
                    o = t.createElement(a);
                o.defer = !0, o.src = "user/cdn-cgi/zaraz/sd41d.js?" + new URLSearchParams(e[r]).toString(), i.parentNode.insertBefore(o, i)
            }(w, d, "zarazData", "script", "dataLayer");
        })(window, document);
    </script>
</head>

<body>

    <div id="preloader">
        <div class="loader"></div>
    </div>


    <header class="header-area">

        <div class="top-header-area">
            <div class="container">
                <div class="row">
                    <div class="col-6">
                        <div class="top-header-content">
                            <a href="#"><i class="fa fa-phone" aria-hidden="true"></i> <span>Call Us: 001-1234-88888</span></a>
                            <a href="#"><i class="fa fa-envelope" aria-hidden="true"></i> <span>Email: <span class="__cf_email__" data-cfemail="b2dbdcd4dd9cd1dddedddedbd0f2d5dfd3dbde9cd1dddf">[email&#160;protected]</span></span></a>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="top-header-content">


                            <div class="dropdown">
                                <a class="btn pr-0 dropdown-toggle" href="#" role="button" id="langdropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="img/core-img/xeng.png.pagespeed.ic.AcRdUJk0O9.png" alt=""> English</a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="langdropdown">
                                    <a class="dropdown-item" href="#">- Latvian</a>
                                    <a class="dropdown-item" href="#">- Hindi</a>
                                    <a class="dropdown-item" href="#">- Bangla</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="main-header-area">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">

                    <nav class="classy-navbar justify-content-between" id="hamiNav">

                        <a class="nav-brand" href="index.html"><img src="user/img/core-img/xlogo.png.pagespeed.ic.cpOUPeRNvj.png" alt=""></a>

                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <div class="classy-menu">

                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <div class="classynav">
                                <ul id="nav">
                                    <li><a href="index.html">Home</a></li>
                                    <li><a href="hosting.html">Hosting</a></li>
                                    <li><a href="#">Pages</a>
                                        <ul class="dropdown">
                                            <li><a href="index.html">- Home</a></li>
                                            <li><a href="hosting.html">- Hosting</a></li>
                                            <li><a href="about.html">- About</a></li>
                                            <li><a href="blog.html">- Blog</a></li>
                                            <li><a href="single-blog.html">- Blog Details</a></li>
                                            <li><a href="404.html">- 404</a></li>
                                            <li><a href="coming-soon.html">- Coming Soon</a></li>
                                            <li><a href="#">- Dropdown</a>
                                                <ul class="dropdown">
                                                    <li><a href="#">- Dropdown Item</a></li>
                                                    <li><a href="#">- Dropdown Item</a></li>
                                                    <li><a href="#">- Dropdown Item</a></li>
                                                    <li><a href="#">- Dropdown Item</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="active"><a href="about.html">About</a></li>
                                    <li><a href="blog.html">Blog</a></li>
                                    <li><a href="#">Contact</a></li>
                                </ul>

                                <div class="live-chat-btn ml-5 mt-4 mt-lg-0 ml-md-4">
                                    <a href="#" class="btn hami-btn live--chat--btn"><i class="fa fa-comments" aria-hidden="true"></i> Live Chat</a>
                                </div>
                            </div>

                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    '; ?>