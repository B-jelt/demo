<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key=$_COOKIE['loginkey'];

$s=$obj->clientprofileview($key);
$smartyObj->assign("view",$s);

$f=$obj->clientnotificationview();
$smartyObj->assign("viewnotifications",$f);

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

        if(isset($_POST['notification'])AND($_POST['notification'])!=null)
	    {
            $a=trim($_POST['notification']);
            $obj->clientnotification($a);
        
        }  
        else				
            echo "<script> alert('notification is empty!')</script>";					
}


$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('clientnotification.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}
?>