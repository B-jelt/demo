<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{

$key1=$_GET['key'];


$h=$obj->extensioneditview($key1);
$smartyObj->assign("extensioneditview",$h);

$key=$_COOKIE['loginkey'];

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{

    if(isset($_POST['extension'])AND($_POST['extension'])!=null)
	{

        if(isset($_POST['amount'])AND($_POST['amount'])!=null)
	    {

            if(isset($_POST['validity'])AND($_POST['validity'])!=null)
	        {

                $a=trim($_POST['extension']);
                $b=trim($_POST['amount']);
                $c=trim($_POST['validity']);
                $obj->extensionedit($a,$b,$c,$key1);

            }

            else
                echo"<script>alert('validity is empty')</script>";
        }

        else
            echo"<script>alert('amount name is empty!')</script>";
    }
        
    else				
        echo "<script> alert('extension is empty!')</script>";					
}
    
$smartyObj->display('adminmainheader.tpl');
$smartyObj->display('extensionedit.tpl');
$smartyObj->display('footer.tpl');

}
else
{	
	Header("location:index.php");
}

?>