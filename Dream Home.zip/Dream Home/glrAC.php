<?php
include'DatabaseCon.php';
session_start();
$val=$_SESSION['uid'];
if(isset($_POST['submit']))
{
	$name=$_FILES['file']['name'];
	$nm=$_FILES['fle']['name'];
$tmpname=$_FILES['file']['tmp_name'];
	if(isset($name))
	{
		if(!empty($name))
		{
			$location='uploads/';
			echo"file is".$name;
			if(move_uploaded_file($tmpname,$location.$name))
			{
				$id=$_POST['t'];
				$vid=$_POST['t1'];
				$sql=mysqli_query($con,"insert into gallery(id,vid,name,image)values('$id','$vid','$name','$nm')");
				echo "<script>alert('Successfully Submitted');window.location='engineer home.php';</script>";

			}
		}
	}
}
?>
