<!--
Author: WebThemez
Author URL: http://webthemez.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
session_start();
			$val=$_SESSION['uid'];
			?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Interior-Design-Responsive-Website-Templates-Edge">
	<meta name="author" content="webThemez.com">
	<title>Building Plan</title>
	<link rel="icon" href="assets/images/logo1.jpg">
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen">
	<link rel="stylesheet" href="assets/css/style.css">
	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<![endif]-->
    <style>
	th,td
	{
		padding-bottom:10px;
		padding-left:30px;
		padding-right:40px;
		padding-top:10px;
		font-family:Georgia, "Times New Roman", Times, serif;
		font-weight:bold;
	}
	</style>
</head>

<body>
	<!-- Fixed navbar -->
		<div id="header-top">       
		<!--  HEADER TOP -->
        <div class="container">
        	<div class="row">
				<div class="col-md-6"> 
                    
                        <div class="text">
                            
							<p>Toll Free : (002) 124 2548</p>
                            
                        </div>      
                </div><!-- end -->
            	<div class="col-md-6">              	
                   <div class="social text-center pull-right">
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-dribbble"></i></a>
				<a href="#"><i class="fa fa-flickr"></i></a>
				<a href="#"><i class="fa fa-github"></i></a>
			</div>
                    
                </div><!-- end -->
            </div><!-- end .row -->
           </div> 
		</div>
	<div class="navbar navbar-inverse">
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
			<a class="navbar-brand" href="engineer home.php">
					<img src="assets/images/logo1.jpg" width="230%" height="150%" alt="Techro HTML5 template"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right mainNav">
						<li class="active"><a href="contractor home.php">Home</a></li>
                    <li><a href="Engineer plan view2.php">Plan</a></li>
					<li><a href="bidstatus.php">Bidding Status</a></li>
					<li><a href="viewnotif.php">Notification</a></li>
					
					
                    <!--<li><a href="Client Register.php">Clients</a></li>
                    <li><a href="Contractor Register.php">Contractor</a></li>
                    <li><a href="Client Login.php">Login</a></li>-->
					<li><a href="logout.php">Logout</a></li>


				</ul>
			</div>
			<!--/.nav-collapse -->
		</div>
	</div>
	<!-- /.navbar -->

	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>Bidding/h1>
				</div>
			</div>
		</div>
	</header>
    <div class="container">
				<div class="row">
					<div class="col-md-6">


<form class="form-light mt-20">
							<div class="form-group">
<table border="1">
<tr>
<th>Bidding Date</th>
<th>Bid Amount</th>
<th>Contractor Name</th>
<th>Message</th>
</tr>
<?php
include'DatabaseCon.php';
$q="select * from contractor_notification";
$w=mysqli_query($con,$q);
while($row=mysqli_fetch_array($w))
{
?>	
<tr>
<td><?php echo $row['bdt'];?></td>
<td><?php echo $row['bam'];?></td>
<td><?php echo $row['nm'];?></td>
<td><?php echo $row['msg'];?></td>
</tr>
<?php
}
?>
</table>
</div></div>
                    </div></div>
                           
<footer id="footer">
		<div class="container">
			<div class="social text-center">
				<a href="https://twitter.com/login?lang=en"><i class="fa fa-twitter"></i></a>
				<a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
				<a href="https://dribbble.com/tags/login"><i class="fa fa-dribbble"></i></a>
				<a href="https://www.flickr.com/photos/tags/login/"><i class="fa fa-flickr"></i></a>
				<a href="https://github.com/login"><i class="fa fa-github"></i></a>
                <a href="https://www.instagram.com/accounts/login/"><i class="fa fa-instagram"></i></a>
			</div>

			<div class="clear"></div>
			<!--CLEAR FLOATS-->
		</div>
		<div class="footer2">
			<div class="container">
				<div class="row">

					<div class="col-md-6 panel">
						<div class="panel-body">
							<p class="simplenav">
								<a href="index.html">Home</a> | 
								<a href="about.html">About</a> |
								<a href="services.html">Services</a> |
								
								<a href="projects.html">Projects</a> |
								<a href="contact.html">Contact</a>
							</p>
						</div>
					</div>

					<div class="col-md-6 panel">
						<div class="panel-body">
							<p class="text-right">
								Copyright &copy; 2019.  <a href="https://webthemez.com/free-bootstrap-templates/" target="_blank">Bootstrap Templates</a> by WebThemez.com
							</p>
						</div>
					</div>

				</div>
				<!-- /row of panels -->
			</div>
		</div>
	</footer>


	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="assets/js/custom.js"></script>

	<!-- Google Maps -->
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
	<script src="assets/js/google-map.js"></script>


</body>
</html>



	
	
	
	
	





	
	
	
	
	
