<?php
include 'DatabaseCon.php';
$uname=$_POST['nm'];
$upass=$_POST['pa'];
$sql="select * from login where uname='$uname' and upass='$upass'";
$rt=mysqli_query($con,$sql);
$row=mysqli_fetch_array($rt);
session_start();
if($row['utype']=="admin")
{
$_SESSION['uid']=$row['uid'];
header('location:admin home.php');	
}
else if($row['utype']=="contractor" && $row['status']=="Approved")
{
$_SESSION['uid']=$row['uid'];
header('location:contractor home.php');
}
else if($row['utype']=="client" && $row['status']=="Approved")
{
$_SESSION['uid']=$row['uid'];
header('location:client home.php');
}
else if($row['utype']=="engineer")
{
$_SESSION['uid']=$row['uid'];
header('location:engineer home.php');
}
else 
{
	echo "<script>alert('Invalid username or password');window.location='Client Login.php';</script>";
	}
?>