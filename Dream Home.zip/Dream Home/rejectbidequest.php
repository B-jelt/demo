<?php
include'DatabaseCon.php';
$id=$_GET['id'];
$sql="update bid_request set status='Reject' where id='$id'";
$sq=mysqli_query($con,$sql);
header('location:Bid request view.php');
?>