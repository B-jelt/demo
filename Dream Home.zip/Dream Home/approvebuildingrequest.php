<?php
include'DatabaseCon.php';
$id=$_GET['id'];
$sql="update building_request set status='Approved' where id='$id'";
$sq=mysqli_query($con,$sql);
header('location:bul reqst view.php');
?>