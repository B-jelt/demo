<?php
include'DatabaseCon.php';
$id=$_GET['id'];
$sql=mysqli_query($con,"delete from building_request where id='$id'");
echo "<script>alert('Successfully Deleted');window.location='bul reqst view.php';</script>";
?>