<?php
include'DatabaseCon.php';
$id=$_GET['id'];
$sql="update engineer_plan set status='Approve' where id='$id'";
$rs=mysqli_query($con,$sql);
echo "<script>alert('Successfully Approved');window.location='Engineer plan view.php';</script>";
?>