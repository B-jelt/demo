<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Building request view</title>
</head>

<body>
<table border="1">
<tr>
<th>Plan</th>
<th>Request Date</th>
<th>Customer Name</th>
<th>Phone Number</th>
<th>Suggestion</th>
</tr>
<?php
include'DatabaseCon.php';
$q="select * from building_request";
$w=mysqli_query($con,$q);
while($row=mysqli_fetch_array($w))
{
?>	
<tr>
<td><?php echo $row['pln'];?></td>
<td><?php echo $row['rdt'];?></td>
<td><?php echo $row['cstm'];?></td>
<td><?php echo $row['ph'];?></td>
<td><?php echo $row['sgg'];?></td>
<td><a href="bulupdate.php?id=<?php echo $row['id'];?>">UPDATE</a></td>
</tr>
<?php
}
?>
</table>

</body>
</html>





	
	
	
	
	
