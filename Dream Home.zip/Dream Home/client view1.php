<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>client View</title>
</head>

<body>
<table border="1">
<tr>
<th>Name</th>
<th>Address</th>
<th>Phone Number</th>
<th> Email</th>
<th>status</th>
<th>ACTION</th>
</tr>
<?php
include'DatabaseCon.php';
$q="select * from login inner join client_register on client_register.cid=login.uid where login.utype='client'";
$w=mysqli_query($con,$q);
while ($row=mysqli_fetch_array($w))
{
?>	
<tr>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['address'];?></td>
<td><?php echo $row['phno'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['status'];?></td>
<?php
if($row['status']=='nill')
{
	?>
    <td><a href="clapr.php?id=<?php echo $row['uid'];?>">ACCEPT</a></td>
    <td><a href="clrej.php?id=<?php echo $row['uid'];?>">REJECT</a></td>
    
    <?php
}
?>
</tr>
<?php
}
?>
</table>

</body>
</html>