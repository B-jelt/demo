<?php 
  session_start();
  if($_SESSION['uid']=="" || $_SESSION['uid']=='null')
  header('location:logout.php');
  ?>
<!--
Author: WebThemez
Author URL: http://webthemez.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Interior-Design-Responsive-Website-Templates-Edge">
	<meta name="author" content="webThemez.com">
	<title>DreamHome</title>
	<link rel="icon" href="assets/images/logo1.jpg">
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen">
	<link rel="stylesheet" href="assets/css/style.css">
	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
	<!-- Fixed navbar -->
		<div id="header-top">       
		<!--  HEADER TOP -->
        <div class="container">
        	<div class="row">
				<div class="col-md-6"> 
                    
                        <div class="text">
                            
							<p>Toll Free : (002) 124 2548</p>
                            
                        </div>      
                </div><!-- end -->
            	<div class="col-md-6">              	
                   <div class="social text-center pull-right">
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-dribbble"></i></a>
				<a href="#"><i class="fa fa-flickr"></i></a>
				<a href="#"><i class="fa fa-github"></i></a>
			</div>
                    
                </div><!-- end -->
            </div><!-- end .row -->
           </div> 
		</div>
	<div class="navbar navbar-inverse">
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
				<a class="navbar-brand" href="index.html">
					<img src="assets/images/logo1.jpg" width="230%" height="150%" alt="Techro HTML5 template"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right mainNav">
					<li class="active"><a href="admin home.php">Home</a></li>
					<li><a href="Contractor view.php">Contractors</a></li>
					<li><a href="client view.php">Clients</a></li>
					
					<li><a href="Engineer register.php">Engineers</a></li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">View <b class="caret"></b></a>
						<ul class="dropdown-menu">
                        <li><a href="Engineer view.php">Engineers</a></li>
							<li><a href="Engineer plan view.php">Building Structure</a></li>
							<li><a href="bul reqst view.php">Building Request</a></li>
							<li><a href="Bid request view.php">Biddings</a></li>
						</ul>
					</li>
                    <!--<li><a href="Client Register.php">Clients</a></li>
                    <li><a href="Contractor Register.php">Contractor</a></li>
                    <li><a href="Client Login.php">Login</a></li>-->
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</div>
			<!--/.nav-collapse -->
		</div>
	</div>
	<!-- /.navbar -->

	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>ENGINEERS DETAILS</h1>
				</div>
			</div>
		</div>
	</header>
    <div class="container">
				<div class="row">
					<div class="col-md-6">
			<form class="form-light mt-20" action="engregAC.php" role="form" method="post" onsubmit="return check();" enctype="multipart/form-data">
							<div class="form-group">

<label>Name:</label><input type="text" name="nm" id="nm" required class="form-control" placeholder="Enter Name" ></div>
<div class="form-group">
<label>Position:</label><input type="text" name="pn" required class="form-control" placeholder="Enter Position"/></div>
<div class="form-group">
<label>Company Id:</label><input type="text" name="ci" id="ci" required class="form-control" placeholder="Enter Company id"/ maxlength="10" minlength="10"></div>
<div class="form-group">
<label>Duty Time( Start Time And End Time):</label><input type="time"  name="dt" required class="form-control" placeholder="Enter Duty Time"/> <input type="time"  name="dtt" required class="form-control" placeholder="Enter Duty Time"/></div>
<div class="form-group">
<label>Phone Number:</label><input type="text" name="ph" id="ph" maxlength="10" minlength="10" required class="form-control" placeholder="Enter Phone Number"/></div>
<div class="form-group">
<label>Profile:</label><input type="file" name="file" required class="form-control" placeholder=""/></div>
<div class="form-group">
<label>Email id:</label><input type="email" name="em" required class="form-control" placeholder="Enter Email"/></div>
<div class="form-group">
<label>Password:</label><input type="password"name="pa" required class="form-control" placeholder="Enter Password"/></div>
<button type="submit" name="submit" >ADD</button><p><br/></p>
						</form>
					</div>
                  
<footer id="footer">
		<div class="container">
			<div class="social text-center">
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-dribbble"></i></a>
				<a href="#"><i class="fa fa-flickr"></i></a>
				<a href="#"><i class="fa fa-github"></i></a>
			</div>

			<div class="clear"></div>
			<!--CLEAR FLOATS-->
		</div>
		<div class="footer2">
			<div class="container">
				<div class="row">

					<div class="col-md-6 panel">
						<div class="panel-body">
							<p class="simplenav">
								<a href="index.html">Home</a> | 
								<a href="about.html">About</a> |
								<a href="services.html">Services</a> |
								
								<a href="projects.html">Projects</a> |
								<a href="contact.html">Contact</a>
							</p>
						</div>
					</div>

					<div class="col-md-6 panel">
						<div class="panel-body">
							<p class="text-right">
								Copyright &copy; 2019.  <a href="https://webthemez.com/free-bootstrap-templates/" target="_blank">Bootstrap Templates</a> by WebThemez.com
							</p>
						</div>
					</div>

				</div>
				<!-- /row of panels -->
			</div>
		</div>
	</footer>


	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="assets/js/custom.js"></script>

	<!-- Google Maps -->
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
	<script src="assets/js/google-map.js"></script>


</body>
</html>
<script type="text/javascript">
var letter=/^[a-z A-Z]+$/;
var number=/^[0-9]+$/;
function check()
{
	if(!document.getElementById("nm").value.match(letter))
	{
		alert('Input letters for name');
		return false;
	}
	
	else if(!document.getElementById("ci").value.match(number))
	{
	alert('Input digits for company id');
		return false;
	}
	else if(!document.getElementById("ph").value.match(number))
{
	alert('Input digits for phone number');
		return false;
	}
	else
	{
	return true;
	}

}
</script>