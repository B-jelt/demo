<?php
include 'DatabaseCon.php';

				$clnm=$_POST['nm'];
				$dt=$_POST['de'];
				$en=$_POST['en'];
				$cid=$_POST['t'];
				$pid=$_POST['tt'];
				$sql=mysqli_query($con,"insert into  client_send(nm,upl,dls,ename,status,clid,pid)values('$clnm','$name','$dt','$en','pending','$cid','$pid')");
echo "<script>alert('Successfully Submitted');window.location='admin home.php';</script>";
		
?>
