<?php
include 'DatabaseCon.php';
$id=$_GET['id'];
$pl=$_GET['pn'];
$rqdt=$_GET['rd'];
$nm=$_GET['nm'];
$pho=$_GET['phn'];
$sug=$_GET['sgg'];

$q="update building_request set pln='$pl',rdt='$rqdt',cstm='$nm',ph='$pho',sgg='$sug' where id='$id'";
$rs=mysqli_query($con,$q);
//echo $q;
header('location:bul reqst view.php');

?>