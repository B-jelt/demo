<?php
include 'DatabaseCon.php';
$id=$_GET['id'];
$nam=$_GET['nm'];
$poss=$_GET['pos'];
$com=$_GET['cmpid'];
$dat=$_GET['dt'];
$pho=$_GET['ph'];
$q="update engineer_register set ph='$pho', dt='$dat',cmpid='$com',pos='$poss' where eid='$id'";
$rs=mysqli_query($con,$q);
//echo $q;
header('location:Engineer view.php');

?>
