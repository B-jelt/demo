<?php
include'DatabaseCon.php';
$id=$_GET['id'];
$sql="update login set status='Reject' where uid='$id'";
$sq=mysqli_query($con,$sql);
header('location:client view.php');
?>