<?php
include'DatabaseCon.php';
$id=$_GET['id'];
$sql="delete from contractor_details where cid='$id'";
$rs=mysqli_query($con,$sql);
echo "<script>alert('Deleted Successfully');window.location='Contractor view.php';</script>";
?>