<?php
session_start();
$val=$_SESSION['uid'];
include 'DatabaseCon.php';
$cn=$_POST['nm'];
$up=$_POST['pr'];
$ds=$_POST['de'];

$q="insert into contractor_notification(bdt,bam,nm,msg)values('$cn','$up','$val','$ds')";
$rs=mysqli_query($con,$q);
header('location:admin home.php');
?>
