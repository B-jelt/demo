<?php
include'DatabaseCon.php';
$upl=$_POST['uplp'];
$dt=$_POST['dtl'];
$cnm=$_POST['nm'];
$cph=$_POST['cn'];

$q="insert into customer_plan(upl,dls,cstm,ph)values('$upl','$dt','$cnm','$cph')";
$rs=mysqli_query($con,$q);


?>