<?php
include'DatabaseCon.php';
$id=$_GET['t'];
$phn=$_GET['ph'];
$e=$_GET['em'];
$sql=mysqli_query($con,"update engineer_register set ph='$phn',em='$e' where eid='$id'");
header('location:engineer home.php');
?>