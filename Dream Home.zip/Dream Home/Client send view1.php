<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Client send view</title>
</head>

<body>
<table border="1">
<tr>
<th>Client Name</th>
<th>Upload Plan</th>
<th>Details</th>
</tr>
<?php
include'DatabaseCon.php';
$q="select * from client_send";
$w=mysqli_query($con,$q);
while($row=mysqli_fetch_array($w))
{
?>	
<tr>
<td><?php echo $row['nm'];?></td>
<td><?php echo $row['upl'];?></td>
<td><?php echo $row['dls'];?></td>
<td><a href="clsndup.php?id=<?php echo $row['cid']?>">Update</a></td>
</tr>
<?php
}
?>
</table>

</body>
</html>





	
	
	
	
	
