-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2022 at 02:26 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dream_home`
--

-- --------------------------------------------------------

--
-- Table structure for table `bid_request`
--

CREATE TABLE `bid_request` (
  `id` int(10) NOT NULL,
  `pln` varchar(70) NOT NULL,
  `amt` varchar(30) NOT NULL,
  `rdt` varchar(30) NOT NULL,
  `nm` varchar(30) NOT NULL,
  `cid` varchar(10) NOT NULL,
  `phno` varchar(12) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bid_request`
--

INSERT INTO `bid_request` (`id`, `pln`, `amt`, `rdt`, `nm`, `cid`, `phno`, `status`) VALUES
(1, 'AC', '543', '2022-01-06', 'AJ', '', '', ''),
(2, 'dfgb', '3456', '2022-01-18', 'tfgyhbj', '', '', ''),
(3, 'tttttttttt', '6546', '2022-02-22', 'hgfhgc', '1', '7654567656', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `building_request`
--

CREATE TABLE `building_request` (
  `id` int(10) NOT NULL,
  `pln` varchar(70) NOT NULL,
  `rdt` varchar(30) NOT NULL,
  `cstm` varchar(30) NOT NULL,
  `ph` varchar(12) NOT NULL,
  `sgg` varchar(50) NOT NULL,
  `cid` varchar(10) NOT NULL,
  `status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `building_request`
--

INSERT INTO `building_request` (`id`, `pln`, `rdt`, `cstm`, `ph`, `sgg`, `cid`, `status`) VALUES
(1, 'ttttttttttttttttttt', '2022-01-28', 'AJ', '54323456543', '', '', ''),
(2, 'dfgh', '2022-01-19', 'tgyhbj', '345678', 'uhgvc', '', ''),
(3, 'tttttttttt', '2022-02-06', 'qqqqqq', '666666666', 'cccccccccccc', '', ''),
(4, 'tttttttttt', '2022-02-15', 'mhf', '6584556475', 'bdgfbc g', '1', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `client_register`
--

CREATE TABLE `client_register` (
  `cid` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phno` varchar(12) NOT NULL,
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client_register`
--

INSERT INTO `client_register` (`cid`, `name`, `address`, `phno`, `email`) VALUES
(1, 'vfe', 'rtghj', '345678', 'w4@gmail.com'),
(2, 'vfe', 'rtghj', '345678', 'w4@gmail.com'),
(3, 'abcd', 'abcd', '2345676543', 'ab@gmail.com'),
(4, 'Alan', 'ktr', '8078991842', 'alan@gmail.com'),
(5, '', '', '', ''),
(6, 'qq', 'dfghjk', '654676', 'f@gmail.com'),
(7, 'ss', 'ssssss', '3456789876', 's@gmail.com'),
(8, 'alu', 'oyv', '1231231234', 'r@gmail.com'),
(9, 'alan', 'gdjgfg', '3264342643', 'alan@gmail.com'),
(10, 'saju', 'saju vilasam\r\noyo123', '9876543234', 'saju@gmail.com'),
(11, 'name', 'name', '1234567765', 'name@gmail.com'),
(12, 'client', 'ktr', '3456788765', 'client@gmail.com'),
(13, 'qqqqqqqqqq', 'qqqqqqqqqqqqqqqq', '5525255858', 'q@gmail.com'),
(14, 'w', 'wwwwwwwwwwwwwww', '4567654345', 'w@gmail.com'),
(15, 'rithin', 'ayur', '5676543456', 'rithin@gmail.com'),
(16, 'john', 'ktr', '3456787654', 'jo@gmail.com'),
(17, 'k', 'ktr', '6768545476', 'k@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `client_send`
--

CREATE TABLE `client_send` (
  `cid` int(10) NOT NULL,
  `nm` varchar(30) NOT NULL,
  `upl` varchar(80) NOT NULL,
  `dls` varchar(50) NOT NULL,
  `rqid` varchar(10) NOT NULL,
  `phno` varchar(12) NOT NULL,
  `eid` varchar(10) NOT NULL,
  `dte` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client_send`
--

INSERT INTO `client_send` (`cid`, `nm`, `upl`, `dls`, `rqid`, `phno`, `eid`, `dte`) VALUES
(2, 'Saju', 'aj1.jpg', 'dddd', '', '', '', ''),
(3, 'gfdyd', 'Screenshot (2).png', 'hgjhdg', '', '', '', ''),
(4, 'mhf', 'news2.jpg', '3 Bed room Home', '4', '6584556475', '1002', '2022-02-26');

-- --------------------------------------------------------

--
-- Table structure for table `contractor_details`
--

CREATE TABLE `contractor_details` (
  `cid` int(10) NOT NULL,
  `nm` varchar(30) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `em` varchar(30) NOT NULL,
  `ph` varchar(12) NOT NULL,
  `lic` varchar(30) NOT NULL,
  `ulic` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contractor_details`
--

INSERT INTO `contractor_details` (`cid`, `nm`, `addr`, `em`, `ph`, `lic`, `ulic`) VALUES
(1001, 'Alex', 'Alex Villa', 'alex@gmail.com', '8765445678', '8765', 'photo-4.jpg'),
(1003, 'contractor', 'ktr', 'contractor@gmail.com', '3245678976', '345678934', 'th.jfif'),
(1006, 'ajith', 'ayur', 'ajith@gmail.com', '4567897654', '45678765567', 'photo-1.jpg'),
(1007, 'j', 'kyr', 'j@gmail.com', '1234567890', '3456789876543', 'photo-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contractor_notification`
--

CREATE TABLE `contractor_notification` (
  `id` int(10) NOT NULL,
  `bdt` varchar(30) NOT NULL,
  `bam` varchar(30) NOT NULL,
  `nm` varchar(50) NOT NULL,
  `msg` varchar(50) NOT NULL,
  `rqid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contractor_notification`
--

INSERT INTO `contractor_notification` (`id`, `bdt`, `bam`, `nm`, `msg`, `rqid`) VALUES
(1, '2022-01-12', '34567', 'sdfgh', 'edrfg', ''),
(2, '2022-02-16', '6547546', 'jhfgy', 'hghgf', ''),
(3, '2022-02-22', '6546', 'hgfhgc', 'Your Bidding request has been accepted for this am', '3'),
(4, '2022-02-22', '6546', 'hgfhgc', 'Bidding request accepted please contact me', '3');

-- --------------------------------------------------------

--
-- Table structure for table `customer_plan`
--

CREATE TABLE `customer_plan` (
  `id` int(10) NOT NULL,
  `upl` varchar(70) NOT NULL,
  `dls` varchar(50) NOT NULL,
  `cstm` varchar(30) NOT NULL,
  `ph` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_plan`
--

INSERT INTO `customer_plan` (`id`, `upl`, `dls`, `cstm`, `ph`) VALUES
(1, 'aj1.jpg', 'sdfghj', 'wdfg', '456'),
(2, 'Screenshot (2).png', 'hgdhdf', 'hgdjh', '6546536354');

-- --------------------------------------------------------

--
-- Table structure for table `engineer_plan`
--

CREATE TABLE `engineer_plan` (
  `id` int(10) NOT NULL,
  `upl` varchar(70) NOT NULL,
  `dls` varchar(50) NOT NULL,
  `amt` varchar(30) NOT NULL,
  `nm` varchar(30) NOT NULL,
  `cmpid` varchar(30) NOT NULL,
  `dte` varchar(10) NOT NULL,
  `status` varchar(30) NOT NULL,
  `vid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `engineer_plan`
--

INSERT INTO `engineer_plan` (`id`, `upl`, `dls`, `amt`, `nm`, `cmpid`, `dte`, `status`, `vid`) VALUES
(2, 'news6.jpg', 'hgvlug', '374', 'yutdudf', '676', '', '', ''),
(3, 'news4.jpg', '2500 sqft', '250000', 'Home', '123', '2022-02-12', 'Approve', ''),
(4, 'bg_header.jpg', 'abcd', '400000', 'Home', '1234', '2022-02-26', 'Approve', '1002'),
(5, '940x250.png', '2500 sqft', '400000', 'Villa', '456', '2022-03-21', 'pending', ''),
(6, '940x250.png', '2500 sqft', '400000', 'Villa', '456', '2022-03-21', 'pending', '1002');

-- --------------------------------------------------------

--
-- Table structure for table `engineer_register`
--

CREATE TABLE `engineer_register` (
  `eid` int(10) NOT NULL,
  `nm` varchar(30) NOT NULL,
  `pos` varchar(30) NOT NULL,
  `cmpid` varchar(30) NOT NULL,
  `dt` varchar(20) NOT NULL,
  `ph` varchar(12) NOT NULL,
  `prf` varchar(70) NOT NULL,
  `em` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `engineer_register`
--

INSERT INTO `engineer_register` (`eid`, `nm`, `pos`, `cmpid`, `dt`, `ph`, `prf`, `em`) VALUES
(1002, 'Tom', 'Designer', '123', '4 hr', '9876543234', 'photo-1.jpg', 'tom@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `uid` int(10) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `upass` varchar(30) NOT NULL,
  `utype` varchar(30) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`uid`, `uname`, `upass`, `utype`, `status`) VALUES
(0, 'admin@gmail.com', 'admin', 'admin', 'Approve'),
(1002, 'tom@gmail.com', 'tom123', 'engineer', 'Approve'),
(10, 'saju@gmail.com', 'saju', 'client', 'Approve'),
(11, 'name@gmail.com', 'name', 'client', 'Approve'),
(10, 'name@gmail.com', 'name', 'contractor', 'Approve'),
(11, 'alex@gmail.com', 'alex123', 'contractor', 'Approve'),
(1002, 'john@gmail.com', 'john123', 'contractor', 'Approve'),
(12, 'client@gmail.com', 'client123', 'client', 'Approve'),
(1003, 'contractor@gmail.com', 'contractor123', 'contractor', 'Approve'),
(13, 'q@gmail.com', 'q123', 'client', 'Reject'),
(14, 'w@gmail.com', 'w', 'client', 'Approved'),
(1004, 'e@gmail.com', 'e', 'contractor', 'Reject'),
(1005, 'e@gmail.com', 'e', 'contractor', 'Approved'),
(15, 'rithin@gmail.com', 'rithin123', 'client', 'Approved'),
(1006, 'ajith@gmail.com', 'ajith123', 'contractor', 'Approved'),
(16, 'jo@gmail.com', 'jo123', 'client', 'Approved'),
(17, 'k@gmail.com', 'k123', 'client', 'Approved'),
(1007, 'j@gmail.com', 'j123', 'contractor', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `work_status`
--

CREATE TABLE `work_status` (
  `id` int(10) NOT NULL,
  `wrk` varchar(70) NOT NULL,
  `sts` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `work_status`
--

INSERT INTO `work_status` (`id`, `wrk`, `sts`) VALUES
(1, 'rtyu', 'dfg'),
(2, 'dfgh', ''),
(3, 'dfghj', 'sdfgh'),
(4, 'dfghjikj', 'sedrftgyhuj'),
(5, 'hchm', 'hfhgc');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bid_request`
--
ALTER TABLE `bid_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `building_request`
--
ALTER TABLE `building_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_register`
--
ALTER TABLE `client_register`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `client_send`
--
ALTER TABLE `client_send`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `contractor_details`
--
ALTER TABLE `contractor_details`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `contractor_notification`
--
ALTER TABLE `contractor_notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_plan`
--
ALTER TABLE `customer_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `engineer_plan`
--
ALTER TABLE `engineer_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `engineer_register`
--
ALTER TABLE `engineer_register`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `work_status`
--
ALTER TABLE `work_status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bid_request`
--
ALTER TABLE `bid_request`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `building_request`
--
ALTER TABLE `building_request`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `client_register`
--
ALTER TABLE `client_register`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `client_send`
--
ALTER TABLE `client_send`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contractor_details`
--
ALTER TABLE `contractor_details`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1008;

--
-- AUTO_INCREMENT for table `contractor_notification`
--
ALTER TABLE `contractor_notification`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer_plan`
--
ALTER TABLE `customer_plan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `engineer_plan`
--
ALTER TABLE `engineer_plan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `engineer_register`
--
ALTER TABLE `engineer_register`
  MODIFY `eid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1003;

--
-- AUTO_INCREMENT for table `work_status`
--
ALTER TABLE `work_status`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
