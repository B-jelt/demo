<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Customer Plan</title>
</head>

<body>

<center>
<form action="cusmplAC.php" method="post" onsubmit="return check();">
<table>
<tr><td>Upload Plan:</td><td><input type="file" name="uplp" required/></td></tr>
<tr><td>Details:</td><td><textarea name="dtl" required></textarea> </td></tr>
<tr><td>Customer Name:</td><td><input type="text" name="nm" id="nm"required /></td></tr>
<tr><td>Contact Number:</td><td><input type="text" name="cn" id="cn" maxlength="10"minlength="10" required/></td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="Add"/></td></tr>
</table>
</form>
</center>



</body>
</html>
<script type="text/javascript">
var letter=/^[a-z A-Z]+$/;
var number=/^[0-9]+$/;
function check()
{
	if(!document.getElementById("nm").value.match(letter))
	{
		alert('Input letter for name');
		return false;
	}
	else if(!document.getElementById("cn").value.match(number))

	{
		alert('Input number for Contact Number');
		return false;
	}
	else
	{
	return true;
	}

}
</script>