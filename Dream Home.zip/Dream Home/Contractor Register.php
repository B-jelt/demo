<!--
Author: WebThemez
Author URL: http://webthemez.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Interior-Design-Responsive-Website-Templates-Edge">
	<meta name="author" content="webThemez.com">
	<title>Dreamhome</title>
	<link rel="icon" href="assets/images/logo1.jpg">
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen">
	<link rel="stylesheet" href="assets/css/style.css">
	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<![endif]-->
    <style>
	input
	{
		font-family:Georgia, "Times New Roman", Times, serif;
		font-weight:bold;
	}
	</style>
</head>

<body>
	<!-- Fixed navbar -->
		<div id="header-top">       
		<!--  HEADER TOP -->
        <div class="container">
        	<div class="row">
				<div class="col-md-6"> 
                    
                        <div class="text">
                            
							<p>Toll Free : (002) 124 2548</p>
                            
                        </div>      
                </div><!-- end -->
            	<div class="col-md-6">              	
                   <div class="social text-center pull-right">
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-dribbble"></i></a>
				<a href="#"><i class="fa fa-flickr"></i></a>
				<a href="#"><i class="fa fa-github"></i></a>
			</div>
                    
                </div><!-- end -->
            </div><!-- end .row -->
           </div> 
		</div>
	<div class="navbar navbar-inverse">
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
				<a class="navbar-brand" href="index.html">
					<img src="assets/images/logo1.jpg" width="230%" height="150%" alt="Techro HTML5 template"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right mainNav">
					<li class="active"><a href="index.html">Home</a></li>
					<li><a href="about.html">About</a></li>
					<li><a href="services.html">Services</a></li>
					
					<li><a href="projects.html">Projects</a></li>
					<!--<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="sidebar-right.html">Right Sidebar</a></li>
							<li><a href="#">Dummy Link1</a></li>
							<li><a href="#">Dummy Link2</a></li>
							<li><a href="#">Dummy Link3</a></li>
						</ul>
					</li>-->
                    <li><a href="Client Register.php">Clients</a></li>
                    <li><a href="Contractor Register.php">Contractor</a></li>
                    <li><a href="Client Login.php">Login</a></li>
					<li><a href="contact.html">Contact</a></li>
				</ul>
			</div>
			<!--/.nav-collapse -->
		</div>
	</div>
	<!-- /.navbar -->

	<header id="head" class="secondary">
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<h1>CONTRACTOR REGISTERATION</h1>
				</div>
			</div>
		</div>
	</header>
				
<div class="container">
				<div class="row">
					<div class="col-md-6">
			<form class="form-light mt-20" role="form" action="CotregAC.php" method="post" onSubmit="return check();" enctype="multipart/form-data">
							<div class="form-group">
								<label>Name</label>
								<input type="text" class="form-control" placeholder="Enter Your Name"  name="nm"  id="nm" required>
							</div>
                            <div class="form-group">
								<label>Address</label>
								<textarea class="form-control" id="message" placeholder="Enter Your Address" style="height:100px;" name="adr" required></textarea>
							</div>
                            <div class="form-group">
								<label>Email id</label>
								<input type="text" class="form-control" placeholder="Enter Your Email"  name="em" required>
							</div>
                            <div class="form-group">
								<label>Phone No</label>
								<input type="text" class="form-control" placeholder="Enter Your Number"  name="ph" id="ph" required maxlength="10" minlength="10">
							</div>
                            <div class="form-group">
								<label>License Number</label>
								<input type="text" class="form-control" placeholder="Enter Your License Number"  name="ln" id="ln" required maxlength="10" minlength="10">
							</div>
                               <div class="form-group">
								<label>Upload License</label>
								<input type="file" class="form-control" placeholder="Upload License"  name="file" required>
							</div>
                               <div class="form-group">
								<label>Password</label>
								<input type="Password" class="form-control" placeholder="Enter Your Password"  name="pa" required>
							</div>
						<center><button type="submit" name="submit">REGISTER</button><p><br/></p></center>
						</form>
					</div>
                   
	<!-- /container -->

	

	<footer id="footer">
		<div class="container">
			<div class="social text-center">
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-dribbble"></i></a>
				<a href="#"><i class="fa fa-flickr"></i></a>
				<a href="#"><i class="fa fa-github"></i></a>
			</div>

			<div class="clear"></div>
			<!--CLEAR FLOATS-->
		</div>
		<div class="footer2">
			<div class="container">
				<div class="row">

					<div class="col-md-6 panel">
						<div class="panel-body">
							<p class="simplenav">
								<a href="index.html">Home</a> | 
								<a href="about.html">About</a> |
								<a href="services.html">Services</a> |
								
								<a href="projects.html">Projects</a> |
								<a href="contact.html">Contact</a>
							</p>
						</div>
					</div>

					<div class="col-md-6 panel">
						<div class="panel-body">
							<p class="text-right">
								Copyright &copy; 2019.  <a href="https://webthemez.com/free-bootstrap-templates/" target="_blank">Bootstrap Templates</a> by WebThemez.com
							</p>
						</div>
					</div>

				</div>
				<!-- /row of panels -->
			</div>
		</div>
	</footer>


	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="assets/js/custom.js"></script>

	<!-- Google Maps -->
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
	<script src="assets/js/google-map.js"></script>


</body>
</html>
<script type="text/javascript">
var letter=/^[a-z A-Z]+$/;
var number=/^[0-9]+$/;
function check()
{
	if(!document.getElementById("nm").value.match(letter))
	{
		alert('Input letters for name');
		return false;
	}
	else if(!document.getElementById("ph").value.match(number))
	{
	alert('Input digits for phone number');
		return false;
	}
	else if(!document.getElementById("ln").value.match(number))
	{
		alert('Input digits for license number');
		return false;
	}
	else
	{
	return true;
	}
}
</script>