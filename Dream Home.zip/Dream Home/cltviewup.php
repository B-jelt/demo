<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Updation</title>
</head>

<body>
<form action="clviewupAC.php">
<table>
<?php
include 'DatabaseCon.php';
$id=$_GET['id'];
$q="Select*from client_register where cid='$id'";
$rs=mysqli_query($con,$q);
while($row=mysqli_fetch_array($rs))
{
	?>
    <tr><td><input type="hidden" name="n" value="<?php echo $row ['cid'];?>" ></td></tr>
    <tr><td>Name</td>
    <td><input type ="text" name="nm" value="<?php echo $row['name'];?>"></td></tr>
    <tr><td>Address</td>
    <td><input type ="text" name="adr" value="<?php echo $row['address'];?>"></td></tr>
    <tr><td>Phone Number</td>
    <td><input type ="text" name="ph" value="<?php echo $row['phno'];?>"></td></tr>
	<tr><td>Email</td>
    <td><input type ="email" name="em" value="<?php echo $row['email'];?>"></td></tr>

   <?php
   }
   ?>
   <tr><td><input type ="submit"value="update" /></tr></td>
</table>
</form>
</body>
</html>