<?php
include'DatabaseCon.php';
session_start();
$val=$_SESSION['uid'];
if(isset($_POST['submit']))
{
	$name=$_FILES['file']['name'];
$tmpname=$_FILES['file']['tmp_name'];
	if(isset($name))
	{
		if(!empty($name))
		{
			$location='uploads/';
			echo"file is".$name;
			if(move_uploaded_file($tmpname,$location.$name))
			{
//$upu=$_POST['plup'];
$dtls=$_POST['dtl'];
$am=$_POST['am'];
$nm=$_POST['nm'];
$cmpi=$_POST['ci'];
$dt=date('Y-m-d');
$pl=$_POST['pl'];
$q="insert into engineer_plan(upl,dls,amt,nm,cmpid,dte,status,vid,pname)values('$name','$dtls','$am','$nm','$cmpi','$dt','pending','$val','$pl')";
$rs=mysqli_query($con,$q);
//echo $q;
echo "<script>alert('Successfully Submitted');window.location='engineer home.php';</script>";
			}
		}
	}
}
?>