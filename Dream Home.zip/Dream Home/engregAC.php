<?php
include 'DatabaseCon.php';
if(isset($_POST['submit']))
{
	$name=$_FILES['file']['name'];
$tmpname=$_FILES['file']['tmp_name'];
	if(isset($name))
	{
		if(!empty($name))
		{
			$location='uploads/';
			echo"file is".$name;
			if(move_uploaded_file($tmpname,$location.$name))
			{
$nm=$_POST['nm'];
$pos=$_POST['pn'];
$cmid=$_POST['ci'];
$dyt=$_POST['dt'];
$phn=$_POST['ph'];
//$prof=$_POST['pr'];
$eml=$_POST['em'];
$pass=$_POST['pa'];
$dtt=$_POST['dtt'];
$q="insert into engineer_register(nm,pos,cmpid,dt,st,ph,prf,em)values('$nm','$pos','$cmid','$dyt','$dtt','$phn','$name','$eml')";
$rs=mysqli_query($con,$q);
$q1="select max(eid) as id from engineer_register";
$q2=mysqli_query($con,$q1);
$row=mysqli_fetch_array($q2);
$eid=$row['id'];
$t="insert into login (uid,uname,upass,utype,status) values('$eid','$eml','$pass','engineer','nill')";
$d=mysqli_query($con,$t);
echo "<script>alert('Successfully Submitted');window.location='admin home.php';</script>";
			}
		}
	}
}
?>















