<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contractor View</title>
</head>

<body>
<table border="1">
<tr>
<th>Name</th>
<th>Address</th>
<th> Email</th>
<th>Phone Number</th>
<th>License No</th>
<th>upload license</th>
<th>ACTION</th>
</tr>
<?php
include'DatabaseCon.php';
//$id=$_GET['id'];
$q="select * from contractor_details";
$w=mysqli_query($con,$q);
while ($row=mysqli_fetch_array($w))
{
?>	
<tr>
<td><?php echo $row['nm'];?></td>
<td><?php echo $row['addr'];?></td>
<td><?php echo $row['em'];?></td>
<td><?php echo $row['ph'];?></td>
<td><?php echo $row['lic'];?></td>
<td><?php echo $row['ulic'];?></td>
<td><a href="contraupdate.php?id=<?php echo $row['cid'];?>">UPDATE</a></td>
</tr>
<?php
}
?>
</table>

</body>
</html>