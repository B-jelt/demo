<?php
include 'DatabaseCon.php';
$id=$_GET['id'];
$nam=$_GET['nm'];
$adr=$_GET['pn'];
$em=$_GET['ci'];
$pho=$_GET['ph'];
$q="update contractor_details set ph='$pho',em='$em',addr='$adr' where cid='$id'";
$rs=mysqli_query($con,$q);
//echo $q;
header('location:Contractor view1.php');

?>
