
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Work status</title>
</head>

<body>
<center>
<form action="wrkstAC.php" method="post">
<table>
<tr><td>Work:</td><td><input type="text" name="wr" id="wr" required/></td></tr>
<tr><td>Status:</td><td><textarea name="st" required></textarea></td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="Add"/></td></tr>
</table>
</form>
</center>


</body>
</html>
