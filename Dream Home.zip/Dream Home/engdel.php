<?php
include'DatabaseCon.php';
$id=$_GET['id'];
$sql="delete from engineer_register where eid='$id'";
mysqli_query($con,$sql);
echo"<script>alert('Successfully Deleted');window.location='Engineer view.php';</script>";
?>