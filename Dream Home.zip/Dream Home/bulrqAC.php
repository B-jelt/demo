<?php
include 'DatabaseCon.php';
session_start();
$val=$_SESSION['uid'];
$pl=$_POST['pl'];
$rq=$_POST['rd'];
$cn=$_POST['cn'];
$ph=$_POST['pn'];
$sg=$_POST['sgg'];
$pid=$_POST['t'];
$q="insert into building_request(pln,rdt,cstm,ph,sgg,cid,status,pid)values('$pl','$rq','$cn','$ph','$sg','$val','pending','$pid')";
$rs=mysqli_query($con,$q);
header('location:client home.php');
?>