<?php
include 'DatabaseCon.php';
$em=$_GET['nm'];
$sql="select * from login where uname='$em'";
$rs=mysqli_query($con,$sql);
$row=mysqli_fetch_array($rs);
$pass=$row['upass'];
echo "<script>alert('Your Password Is $pass');window.location='Client Login.php';</script>";
?>