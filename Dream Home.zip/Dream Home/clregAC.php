<?php
include'DatabaseCon.php';
session_start();
$val=$_SESSION['uid'];
if(isset($_POST['submit']))
{
	$name=$_FILES['file']['name'];
$tmpname=$_FILES['file']['tmp_name'];
	if(isset($name))
	{
		if(!empty($name))
		{
			$location='uploads/';
			echo"file is".$name;
			if(move_uploaded_file($tmpname,$location.$name))
			{
$nm=$_POST['nm'];
$adr=$_POST['adr'];
$ph=$_POST['ph'];
$ed=$_POST['em'];
$pass=$_POST['pa'];
$sql="select * from client_register where email='$ed'";
$rw=mysqli_query($con,$sql);
$aw=mysqli_fetch_array($rw);
$email=$aw['email'];
if($ed==$email)
{
	echo "<script>alert('This Email-id has already registered');window.location='index.html';</script>";
}
else
{

$q="insert into client_register(name,address,phno,email,aadhar)values('$nm','$adr','$ph','$ed','$name')";
$rs=mysqli_query($con,$q);
$q1="select max(cid) as id from client_register";
$q2=mysqli_query($con,$q1);
$row=mysqli_fetch_array($q2);
$eid=$row['id'];
$t="insert into login (uid,uname,upass,utype,status) values('$eid','$ed','$pass','client','nill')";
$d=mysqli_query($con,$t);
echo "<script>alert('Successfully Registered,Please wait for admin approval');window.location='index.html';</script>";
			}
		}
	}
}
}
?>