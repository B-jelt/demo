<?php
include 'DatabaseCon.php';
$nm=$_POST['nm'];
$adr=$_POST['adr'];
$ph=$_POST['ph'];
$eid=$_POST['em'];
$pass=$_POST['pa'];

$q="insert into client_register(name,address,phno,email)values('$nm','$adr','$ph','$eid','$pass')";
$rs=mysqli_query($con,$q);

?>