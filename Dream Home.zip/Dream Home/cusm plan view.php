<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Customer plan view</title>
</head>

<body>
<table border="1">
<tr>
<th>Upload plan</th>
<th>Details</th>
<th>Customer Name</th>
<th>Contact No</th>
</tr>
<?php
include'DatabaseCon.php';
$q="select * from customer_plan";
$w=mysqli_query($con,$q);
while($row=mysqli_fetch_array($w))
{
?>	
<tr>
<td><?php echo $row['upl'];?></td>
<td><?php echo $row['dls'];?></td>
<td><?php echo $row['cstm'];?></td>
<td><?php echo $row['ph'];?></td>
</tr>
<?php
}
?>
</table>

</body>
</html>





	
	
	
	
	
