<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bid request view</title>
</head>

<body>
<table border="1">
<tr>
<th>Plan</th>
<th>Amount</th>
<th>Request Date</th>
<th>Name</th>
</tr>
<?php
include'DatabaseCon.php';
$q="select * from bid_request";
$w=mysqli_query($con,$q);
while($row=mysqli_fetch_array($w))
{
?>	
<tr>
<td><?php echo $row['pln'];?></td>
<td><?php echo $row['amt'];?></td>
<td><?php echo $row['rdt'];?></td>
<td><?php echo $row['nm'];?></td>
</tr>
<?php
}
?>
</table>

</body>
</html>





	
	
	
	
	
