<?php
include 'DatabaseCon.php';
$bidt=$_POST['bd'];
$biam=$_POST['ba'];
$cnm=$_POST['cn'];
$mgg=$_POST['adr'];
$id=$_POST['t'];
$cid=$_POST['tt'];
$q="insert into contractor_notification(bdt,bam,nm,msg,rqid,cid)values('$bidt','$biam','$cnm','$mgg','$id','$cid')";
$rs=mysqli_query($con,$q);
echo "<script>alert('Successfully Send The Notification');window.location='admin home.php';</script>";
?>