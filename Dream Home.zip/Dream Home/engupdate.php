<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form action="engupdateaction.php">
<table>
<?php
include'DatabaseCon.php';
//
$id=$_GET['id'];
$sql="select * from engineer_register where eid='$id'";
$rt=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($rt))
{
	?>
    <input type="hidden" name="id" value="<?php echo $row['eid'];?>">
    <tr><td>Name:</td><td><input type="text" name="nm" value="<?php echo $row['nm'];?>" readonly="readonly"/></td></tr>
<tr><td>Position:</td><td><input type="text" name="pn" value="<?php echo $row['pos'];?>" /></td></tr>
<tr><td>Company Id:</td><td><input type="number" name="ci" value="<?php echo $row['cmpid'];?>" /></td></tr>
<tr><td>Duty Time:</td><td><input type="text" name="dt" value="<?php echo $row['dt'];?>"/></td></tr>
<tr><td>Phone Number:</td><td><input type="number" name="ph" value="<?php echo $row['ph'];?>"/></td></tr>
<tr><td>Email id:</td><td><input type="email" name="em" value="<?php echo $row['em'];?>" /></td></tr>
<?php
}
?>
   <tr><td><input type ="submit"value="update" /></tr></td>
</table>
</form>
</body>
</html>