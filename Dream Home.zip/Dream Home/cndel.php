<?php
include'DatabaseCon.php';
$id=$_GET['id'];
$sql="delete from client_register where cid='$id'";
$rs=mysqli_query($con,$sql);
echo "<script>alert('Deleted Successfully');window.location='client view.php';</script>";
?>