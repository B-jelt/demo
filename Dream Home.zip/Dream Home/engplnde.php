<?php
include'DatabaseCon.php';
$id=$_GET['id'];
$sql="delete from engineer_plan where id='$id'";
$rs=mysqli_query($con,$sql);
echo "<script>alert('Successfully Deleted');window.location='Engineer plan view.php';</script>";
?>