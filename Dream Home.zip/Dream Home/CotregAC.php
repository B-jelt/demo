<?php
include'DatabaseCon.php';
//session_start();
//$val=$_SESSION['uid'];
if(isset($_POST['submit']))
{
$name=$_FILES['file']['name'];
$tmpname=$_FILES['file']['tmp_name'];
if(isset($name))
{
if(!empty($name))
{
$location='uploads/';
echo"file is".$name;
if(move_uploaded_file($tmpname,$location.$name))
$nam=$_POST['nm'];
$addr=$_POST['adr'];
$eml=$_POST['em'];
$phn=$_POST['ph'];
$licn=$_POST['ln'];
//$ulinc=$_POST['id'];
$pas=$_POST['pa'];
$sql="select * from contractor_details where em='$eml'";
$rw=mysqli_query($con,$sql);
$aw=mysqli_fetch_array($rw);
$email=$aw['em'];
if($eml==$email)
{
	echo "<script>alert('This Email-id has already registered');window.location='index.html';</script>";
}
else
{
$q="insert into contractor_details(nm,addr,em,ph,lic,ulic)values('$nam','$addr','$eml','$phn','$licn','$name')";
$rs=mysqli_query($con,$q);

$q1="select max(cid) as id from contractor_details";
$q2=mysqli_query($con,$q1);
$row=mysqli_fetch_array($q2);
$rid=$row['id'];
$t=mysqli_query($con,"insert into login(uid,uname,upass,utype,status) values('$rid','$eml','$pas','contractor','nill')");
echo "<script>alert('Successfully Registered, Please wait for admin approval');window.location='index.html';</script>";
}
}
}
}
?>