<?php
session_start();
$val=$_SESSION['uid'];
include'DatabaseCon.php';
$pl=$_POST['pl'];
$am=$_POST['at'];
$rqd=$_POST['rd'];
$nm=$_POST['nm'];
$pid=$_POST['t'];
$m=$_POST['tt'];
$sql="select * from contractor_details where cid='$val'";
$rs=mysqli_query($con,$sql);
$row=mysqli_fetch_array($rs);
$ph=$row['ph'];
$q="insert into bid_request(pln,amt,rdt,nm,cid,phno,status,pid,img)values('$pl','$am','$rqd','$nm','$val','$ph','pending','$pid','$m')";
$rs=mysqli_query($con,$q);
header('location:contractor home.php');
?>
