<?php
include'DatabaseCon.php';
$wk=$_POST['wr'];
$sts=$_POST['st'];

$q="insert into work_status(wrk,sts)values('$wk','$sts')";
$rs=mysqli_query($con,$q);
?>