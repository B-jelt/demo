<?php /* Smarty version 2.6.26, created on 2021-02-23 11:44:18
         compiled from notificationedit.tpl */ ?>
<html>
<head>
	<title>Notification Edit</title>
</head>
<body >
	<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
	<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
	<tr><td>Message</td> <td><textarea name="notification" class="form-control"><?php echo $this->_tpl_vars['b']['notification']; ?>
</textarea></td></tr> 
	<tr><td></td><td><input type="submit" value="Update" class="btn btn-success"> </td></tr>
	<?php endforeach; endif; unset($_from); ?>
</form>
</table>
</body>
</html>