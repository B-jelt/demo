<?php /* Smarty version 2.6.26, created on 2021-03-04 06:49:31
         compiled from vnotification.tpl */ ?>
<html>
<head>
	<title>Notification View</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Message</th>
			<th>Date</th>
		 
		</tr>
				<?php $_from = $this->_tpl_vars['notification']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			<td><?php echo $this->_tpl_vars['Z']['notification']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['currentdate']; ?>
</td>

		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>