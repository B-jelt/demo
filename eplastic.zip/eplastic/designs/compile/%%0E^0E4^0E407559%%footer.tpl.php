<?php /* Smarty version 2.6.26, created on 2021-10-24 12:37:59
         compiled from footer.tpl */ ?>
<br><br>
<!-- Footer Top Area Start -->
<div id="footer-top-area" class="footer-top-area bg-dark section pt-100 pb-50">
    <div class="container">
        <div class="row">
            <!--  Footer Widget  -->
            <div class="footer-widget col-lg-4 col-md-6 col-12 mb-50">
                <!--  About Widget  -->
                <div class="about-widget">
                    <img src="user/img/logo-3.png" alt="">
                    <p></p>
                    <!-- Footer Social -->
                   
                </div>
            </div>
            <!--  Footer Widget  -->
           
            <!--  Footer Widget  -->
            
        </div>
    </div>
</div>
<!-- Footer Top Area End -->

<!-- Footer Bottom Area Start -->
<div id="footer-bottom-area" class="footer-bottom-area section">
<!-- Footer Top Area End -->
    <div class="container">
        <div class="row justify-content-between">
            <!-- Copyright -->
            <div class="copyright col-md-auto col-12">
                <p>Copyright &copy; <span>E-Waste Managment System</span> 2021. All right reserved</p>
            </div>
            <!-- Author Credit -->
            <div class="author-credit col-md-auto col-12">
                <p>Created by <a href=""></a> With <i class="fa fa-heart"></i></p>
            </div>
        </div>
    </div>
</div>
<!-- Footer Bottom Area End -->

</div>
<!-- Body main wrapper end -->

<!-- JS -->

<!-- jQuery JS
============================================ -->
<?php echo '
<script src="user/js/vendor/jquery-1.12.0.min.js"></script>
<!-- Bootstrap JS
============================================ -->
<script src="user/js/bootstrap.bundle.min.js"></script>
<!-- Plugins JS
============================================ -->
<script src="user/js/plugins.js"></script>
<!-- Ajax Mail JS
============================================ -->
<script src="user/js/ajax-mail.js"></script>
<!-- Main JS
============================================ -->
<script src="user/js/main.js"></script>
'; ?>

</body>


<!-- Mirrored from demo.hasthemes.com/greensoul-preview/greensoul/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 11 Feb 2021 05:13:40 GMT -->
</html>