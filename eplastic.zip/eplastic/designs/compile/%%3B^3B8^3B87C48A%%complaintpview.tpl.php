<?php /* Smarty version 2.6.26, created on 2021-10-13 12:02:20
         compiled from complaintpview.tpl */ ?>
<html>
<head>
	<title>Complaints</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Subject</th>
			<th>Complaint</th>
			<th>Date</th>
		    <th></th>
		    <th></th>
		</tr>
				<?php $_from = $this->_tpl_vars['complaint']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			<td><?php echo $this->_tpl_vars['Z']['subject']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['complaint']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['currentdate']; ?>
</td>
			<td><a href="complaintedit.php?key=<?php echo $this->_tpl_vars['Z']['ckey']; ?>
" class="btn btn-success">Edit</a></td>
			<td><a href="complaintdelete.php?key=<?php echo $this->_tpl_vars['Z']['ckey']; ?>
" class="btn btn-danger">Delete</a></td>

		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>