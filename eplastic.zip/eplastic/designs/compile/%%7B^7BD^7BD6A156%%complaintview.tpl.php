<?php /* Smarty version 2.6.26, created on 2021-02-23 07:15:24
         compiled from complaintview.tpl */ ?>
<html>
<head>
	<title>Complaints</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Name</th>
			<th>Subject</th>
			<th>Complaint</th>
			<th>Email</th>
				<th>Contact No</th>
		
		</tr>
				<?php $_from = $this->_tpl_vars['complaint']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			<td><?php echo $this->_tpl_vars['Z']['name']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['subject']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['complaint']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['email']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['contactnumber']; ?>
</td>
			
		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>