<?php /* Smarty version 2.6.26, created on 2021-02-23 06:42:58
         compiled from complaintsubheader.tpl */ ?>
<!doctype html>
<html class="no-js" lang="en">

<!-- Mirrored from demo.hasthemes.com/greensoul-preview/greensoul/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 11 Feb 2021 05:13:37 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>About us - Green Soul</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="user/img/favicon.ico">
    <!-- CSS -->
    <!-- Bootstrap CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/bootstrap.min.css">
    <!-- Icon Font CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- Plugins CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/plugins.css">
    <!-- Style CSS
	============================================ -->
    <link rel="stylesheet" href="user/style.css">
    <!-- Modernizer JS
	============================================ -->
	<?php echo '
    <script src="user/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<!-- Body main wrapper start -->
<div class="wrapper fix">

<!-- Header Area Start -->
<div id="header-area" class="header-area section">

<!-- Header Top Start -->
<div class="header-top">
    <div class="container">
        <div class="row justify-content-between">
            <!-- Header Top Left -->
            <div class="header-top-left col-md-auto col-12">
                <p><span>Phone:</span> +945 588 9966</p>
                <p><span>Email:</span> greensoul@email.com</p>
            </div>
            <!-- Header Top Right -->
            <div class="header-top-right col-md-auto col-12 d-none d-md-flex">
                <!-- Header Social -->
                <div class="header-social d-md-none d-lg-flex">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-rss"></i></a>
                    <a href="#"><i class="fa fa-google-plus"></i></a>
                    <a href="#"><i class="fa fa-pinterest-p"></i></a>
                    <a href="#"><i class="fa fa-instagram"></i></a>
                </div>
                <!-- Header Quote Button -->
                <a href="contact.html" class="get-quote">get a qoute</a>
            </div>
        </div>
    </div>
</div>
<!-- Header Top End -->

<!-- Header Bottom Start -->
<div class="header-bottom">
    <div class="container">
        <div class="row">
			<!-- Logo -->
			<div class="header-logo col align-self-center"><a class="logo" href="index.html"><img src="user/img/logo.png" alt=""></a></div>
			<!-- Main Menu -->
			<div id="main-menu" class="main-menu col-auto d-none d-lg-block">
				<nav>
					<ul>
						<li><a href="index.html">home</a>
							<ul>
								<li><a href="index.html">home (Default Slider)</a></li>
								<li><a href="index-2.html">home 2 (BG Image)</a></li>
								<li><a href="index-3.html">home 3 (BG Video)</a></li>
                                <li><a href="index-4.html">home 4 <span class="badge badge-success ml-2">New</span></a></li>
                                <li><a href="index-5.html">home 5 <span class="badge badge-success ml-2">New</span></a></li>
							</ul>
						</li>
                        <li><a href="panchayathprofile.php">Profile</a></li>
						<li><a href="complaint.php">Complaint</a>
							<ul>
								<li><a href="project.html">project</a></li>
								<li><a href="project-details.html">project details</a></li>
							</ul>
						</li>
						<li><a href="#">Registrations</a>
							<ul>
								<li><a href="volunteer.php">Volunteer</a></li>
								<li><a href="panchayatreg.php">Panchayath</a></li>
								<li><a href="publicreg.php">Public</a></li>
							</ul>
						</li>
						<li><a href="blog.html">blog</a>
							<ul>
								<li><a href="blog.html">blog</a></li>
								<li><a href="blog-details.html">blog details</a></li>
							</ul>
						</li>
						<li><a href="contact.html">contact</a></li>
					</ul>
				</nav>
			</div>
			<!-- Header Search Wrapper -->
			<div class="header-search-wrapper col-auto">
				<!-- Search Toggle -->
				<button class="search-toggle"><i class="zmdi zmdi-search-for"></i></button>
				<!-- Header Search Wrapper -->
				<div class="header-search">
					<form action="#" id="header-search-form">
						<input type="text" placeholder="Search here...">
						<button><i class="zmdi zmdi-search"></i></button>
					</form>
				</div>
			</div>
			<!-- Mobile Menu -->
			<div class="mobile-menu col-12 d-lg-none"></div>
        </div>
    </div>
</div>
<!-- Header Bottom End -->

</div>
<!-- Header Area End -->

<!-- Page Banner Area Start -->
<div class="page-banner-area section overlay gradient">
    <div class="container">
        <div class="row">
            <div class="page-banner col-12">
                <h2>ABOUT US</h2>
                <ul>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="#">about</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page Banner Area End -->
'; ?>

<br><br>