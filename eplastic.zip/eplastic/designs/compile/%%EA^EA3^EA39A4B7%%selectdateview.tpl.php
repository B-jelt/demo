<?php /* Smarty version 2.6.26, created on 2021-10-13 12:11:44
         compiled from selectdateview.tpl */ ?>
<html>
<head>
	<title>Collection Date View</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
						<th>Name</th>
		    <th>Address</th>
			<th>Other Details</th>
			<th>Date</th>
		    <th></th>
		    <th></th>
		    <th></th>
		    <th></th>
		</tr>
				<?php $_from = $this->_tpl_vars['selectdate']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
						<td><?php echo $this->_tpl_vars['Z']['name']; ?>
</td>
												<td><?php echo $this->_tpl_vars['Z']['address']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['otherdetails']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['date']; ?>
</td>
			<td><a href="volunteersel.php?key=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
" class="btn btn-info">Select Volunteer</a></td>
			<td><a href="assignedvolunteers.php?key=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
" class="btn btn-info">volunteers assigned </a></td>
			<td><a href="selectdateedit.php?key=<?php echo $this->_tpl_vars['Z']['dkey']; ?>
" class="btn btn-success">Edit</a></td>
			<td><a href="selectdatedelete.php?key=<?php echo $this->_tpl_vars['Z']['dkey']; ?>
" class="btn btn-danger">Delete</a></td>

		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>