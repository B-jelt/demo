<?php /* Smarty version 2.6.26, created on 2021-03-04 11:21:50
         compiled from wastereqedit.tpl */ ?>
<html>
<head>
	<title>Waste Req Edit</title>
</head>
<body >
	<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
		<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>

    <tr><td>Aadhar No</td> <td><input type="text" name="aadharno" class="form-control" value="<?php echo $this->_tpl_vars['b']['aadharno']; ?>
"></td></tr> <tr><td>&nbsp;</td></tr>
     <tr><td>Waste Material Details</td> <td><textarea input type="text" name="wastedetails" class="form-control" > <?php echo $this->_tpl_vars['b']['wastedetails']; ?>
</textarea></td></tr> <tr><td>&nbsp;</td></tr>

	<tr><td>Ward No</td> <td><input type="text" name="wardno" class="form-control" value="<?php echo $this->_tpl_vars['b']['wardno']; ?>
"></td></tr> <tr><td>&nbsp;</td></tr>
	<tr><td>House No</td> <td><input type="text" name="houseno" class="form-control" value="<?php echo $this->_tpl_vars['b']['houseno']; ?>
"></td></tr> <tr><td>&nbsp;</td></tr>
	<tr><td>Other Details</td> <td> <textarea input type="text" name="otherdetails" class="form-control"> <?php echo $this->_tpl_vars['b']['otherdetails']; ?>
</textarea></td></tr> <tr><td>&nbsp;</td></tr>
	<tr><td></td><td><input type="submit" value="register" class="btn btn-dark"> </td></tr>
		<?php endforeach; endif; unset($_from); ?>

</form>
</table>
</body>
</html>