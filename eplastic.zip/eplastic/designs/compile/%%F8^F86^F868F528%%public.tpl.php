<?php /* Smarty version 2.6.26, created on 2021-02-22 10:18:37
         compiled from public.tpl */ ?>
<html>
<head>
	<title>Public Details</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Name</th>
			<th>Address</th>
			<th>Pincode</th>
			<th>District</th>
			<th>City</th>
			<th>Contact Number</th>
			<th>Email</th>
		</tr>
		<?php $_from = $this->_tpl_vars['publicreg']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>
		<tr>
			<td><?php echo $this->_tpl_vars['Z']['name']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['address']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['pincode']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['district']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['city']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['contactnumber']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['email']; ?>
</td>
		</tr>
        <?php endforeach; endif; unset($_from); ?>
	</table>
</body>
</html>