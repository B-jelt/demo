<?php /* Smarty version 2.6.26, created on 2021-10-13 12:12:25
         compiled from volunteersview.tpl */ ?>
<html>
<head>
	<title>Public Details</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Name</th>
			<th>Address</th>
			<th>Contact Number</th>
			<th>Email</th>
			<th></th>
		</tr>
		<?php $_from = $this->_tpl_vars['volunteerreg']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>
		<tr>
			<td><?php echo $this->_tpl_vars['Z']['name']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['address']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['contactnumber']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['email']; ?>
</td>
<td><a href="salarycheck.php?key=<?php echo $this->_tpl_vars['Z']['ekey']; ?>
" class="btn btn-success">Salary</a></td>
		</tr>
        <?php endforeach; endif; unset($_from); ?>
	</table>
</body>
</html>