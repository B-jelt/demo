<?php /* Smarty version 2.6.26, created on 2021-10-25 07:29:00
         compiled from wastereqadmin.tpl */ ?>
<html>
<head>
	<title>Public Registration</title>
</head>
<body >
	<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
	<tr><td>&nbsp;</td></tr>
	<tr><td>District </td> <td>
		<select name="district" class="form-control">
			<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
			<option value="<?php echo $this->_tpl_vars['b']['district']; ?>
"><?php echo $this->_tpl_vars['b']['district']; ?>
</option>
			<?php endforeach; endif; unset($_from); ?>
		</select>
	</td></tr>
	<tr><td>&nbsp;</td></tr>
	<tr><td></td><td><input type="submit" value="View Panchayath" class="btn btn-success"> </td></tr>
	<tr><td><br><br></td></tr>

</form>
</table>
<?php if ($this->_tpl_vars['view1'] != null): ?>
<table class="table table-striped">
	
		<tr><th>Panchayath</th><th></th></tr>
		<?php $_from = $this->_tpl_vars['view1']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['x']):
?>
		<tr><td><?php echo $this->_tpl_vars['x']['panchayatname']; ?>
</td>
			<td><a href="wastereqstatusadmin.php?key=<?php echo $this->_tpl_vars['x']['ekey']; ?>
" class="btn btn-primary">View Request</a></td></tr>
		<?php endforeach; endif; unset($_from); ?>
	
</table>
<?php endif; ?>
</body>
</html>