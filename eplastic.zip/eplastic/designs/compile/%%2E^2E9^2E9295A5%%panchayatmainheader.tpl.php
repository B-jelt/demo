<?php /* Smarty version 2.6.26, created on 2021-10-27 06:24:57
         compiled from panchayatmainheader.tpl */ ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Panchayath</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="user/img/favicon.ico">
    <!-- CSS -->
    <!-- Bootstrap CSS
	============================================ -->

    <link rel="stylesheet" href="user/css/bootstrap.min.css">
    <!-- Icon Font CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="user/css/font-awesome.min.css">
    <!-- Plugins CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/plugins.css">
    <!-- Style CSS
	============================================ -->
    <link rel="stylesheet" href="user/style.css">
    <!-- Modernizer JS
	============================================ -->
        <?php echo '

    <script src="user/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<!-- Body main wrapper start -->
<div class="wrapper fix">

<!-- Header Area Start -->
<div id="header-area" class="header-area section">



<!-- Header Bottom Start -->
<div class="header-bottom">
    <div class="container">
        <div class="row">
			<!-- Logo -->
			<div class="header-logo col align-self-center"><a class="logo" href="index.html"><img src="user/img/logo-2.png" alt=""></a></div>
			<!-- Main Menu -->
			<div id="main-menu" class="main-menu col-auto d-none d-lg-block">
				<nav>
					<ul>
						<li><a href="panchayathome.php">home</a>
							
						</li>
						<li><a href="panchayathprofile.php">Profile</a></li>
						<li><a href="">Details</a>
							<ul>
								<li><a href="volunteersview.php">Volunteers</a></li>
							</ul>
						</li>
                        <li><a href="#">Messages</a>
                            <ul>
                                <li><a href="msgviewpan.php">View messages</a></li>

                            </ul>
                        </li>
						<li><a href="#">Notification</a>
							<ul>
								<li><a href="notification.php">Send</a></li>
								<li><a href="notificationview.php">view</a></li>
								

							</ul>
						</li>
			<li><a href="">Waste Collection</a>
                            <ul>
                                <li><a href="wastereqpview.php"> Requests</a></li>
                              <li><a href="selectdateview.php"> Collection Dates</a></li>
                               
                            </ul>
                        </li>
						</li>
                        <li><a href="logout.php">Logout</a>
                            
                        </li>
						
					</ul>
				</nav>
			</div>
			<!-- Header Search Wrapper -->
			
			<!-- Mobile Menu -->
			<div class="mobile-menu col-12 d-lg-none"></div>
        </div>
    </div>
</div>
<!-- Header Bottom End -->

</div>
<!-- Header Area End -->
<!-- Hero Area Start -->
<div id="hero-area" class="hero-area hero-video-bg section" data-property="{videoURL:\'iO3SA4YyEYU\', containment:\'.hero-video-bg\', showControls: false, loop: true, startAt:9, mute: 1, opacity:1}">
    <!-- Hero Caption -->
    <div class="hero-caption overlay gradient">
        <div class="container">
            <div class="row">
                <!-- Hero Content -->
                <div class="hero-content col-12">
                    <h1 class="wow cusFadeInRight" data-wow-duration=".5s" data-wow-delay="0.5s">E-Plastic Management System <br>We Care About You</h1>
                    <p class="wow cusFadeInRight" data-wow-duration=".5s" data-wow-delay="1s">Plastic in waste electronics (e-waste) is an environmental time bomb that has been overlooked.</p>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Hero Area End -->
'; ?>