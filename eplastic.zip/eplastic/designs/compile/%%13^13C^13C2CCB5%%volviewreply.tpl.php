<?php /* Smarty version 2.6.26, created on 2021-06-28 11:41:25
         compiled from volviewreply.tpl */ ?>
<html>
<head>
	<title>Reply View</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Contact</th>
			<th>Message</th>
			<th>Current Date</th>
			<th>Current Time</th>
		 		</tr>
				<?php $_from = $this->_tpl_vars['volsendmsg']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
	
			<td><?php echo $this->_tpl_vars['Z']['contactnumber']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['msg']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['currentdate']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['currenttime']; ?>
</td>


		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>