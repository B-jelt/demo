<?php /* Smarty version 2.6.26, created on 2021-10-25 07:42:16
         compiled from index.tpl */ ?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>E-Plastic Managment System</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="user/img/favicon.ico">
    <!-- CSS -->
    <!-- Bootstrap CSS
	============================================ -->

    <link rel="stylesheet" href="user/css/bootstrap.min.css">
    <!-- Icon Font CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="user/css/font-awesome.min.css">
    <!-- Plugins CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/plugins.css">
    <!-- Style CSS
	============================================ -->
    <link rel="stylesheet" href="user/style.css">
    <!-- Modernizer JS
	============================================ -->
        <?php echo '

    <script src="user/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<!-- Body main wrapper start -->
<div class="wrapper fix">

<!-- Header Area Start -->
<div id="header-area" class="header-area section">

<!-- Header Top Start -->
<div class="header-top">
    <div class="container">
        <div class="row justify-content-between">
            <!-- Header Top Left -->
           
            <!-- Header Top Right -->
            <div class="header-top-right col-md-auto col-12 d-none d-md-flex">
                <!-- Header Social -->
                <div class="header-social d-md-none d-lg-flex">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-rss"></i></a>
                    <a href="#"><i class="fa fa-google-plus"></i></a>
                    <a href="#"><i class="fa fa-pinterest-p"></i></a>
                    <a href="#"><i class="fa fa-instagram"></i></a>
                </div>
                <!-- Header Quote Button -->
            </div>
        </div>
    </div>
</div>
<!-- Header Top End -->

<!-- Header Bottom Start -->
<div class="header-bottom">
    <div class="container">
        <div class="row">
			<!-- Logo -->
			<div class="header-logo col align-self-center"><a class="logo" href="index.php"><img src="user/img/logo-2.png" alt=""></a></div>
			<!-- Main Menu -->
			<div id="main-menu" class="main-menu col-auto d-none d-lg-block">
				<nav>
					<ul>
						<li><a href="index.php">home</a>
							
						</li>
						                        <li><a href="aboutus.php">About Us</a></li>

						<li><a href="#">Registrations</a>
							<ul>
                                <li><a href="publicreg.php">Public</a></li>
								<li><a href="volunteer.php">Volunteer</a></li>
								<li><a href="panchayatreg.php">Panchayath</a></li>
								
								<!-- <li><a href="event-details.html">event details</a></li>
								<li><a href="gallery.html">gallery</a></li> -->
							</ul>
						</li>
						                      <li><a href="login.php">Login</a></li>

				</nav>
			</div>
			
			<!-- Mobile Menu -->
			<div class="mobile-menu col-12 d-lg-none"></div>
        </div>
    </div>
</div>
<!-- Header Bottom End -->

</div>
<!-- Header Area End -->

<!-- Hero Area Start -->
<div id="hero-area" class="hero-area hero-video-bg section" data-property="{videoURL:\'iO3SA4YyEYU\', containment:\'.hero-video-bg\', showControls: false, loop: true, startAt:9, mute: 1, opacity:1}">
    <!-- Hero Caption -->
    <div class="hero-caption overlay gradient">
        <div class="container">
            <div class="row">
                <!-- Hero Content -->
                <div class="hero-content col-12">
                    <h1 class="wow cusFadeInRight" data-wow-duration=".5s" data-wow-delay="0.5s">E-Plastic Management System <br>We Care About You</h1>
                    <p class="wow cusFadeInRight" data-wow-duration=".5s" data-wow-delay="1s">"The amount of e-waste increasing annually is tremendous".
<br>
"At the moment, we are generating roughly 50 million tonnes per year globally, and it is expected that it will reach 110 million tonnes in 2050 if we do not change our existing business and consumption practices."</p>
                    <a href="aboutus.php" class="learn-more wow cusFadeInRight" data-wow-duration=".5s" data-wow-delay="1.5s">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Hero Area End -->

<!-- Service Area Start -->
<div id="service-area" class="service-area section pt-120 pb-120">
    <div class="container">
        <!-- Section Title -->
        <div class="row">
            <div class="section-title text-center col-12 mb-80">
                <h1>1500+</h1>
                <h2>People Working with Us</h2>
                <p> </p>
            </div>
        </div>
        <div class="row">
			<!--  Single Service  -->
			<div class="single-service text-center col-lg-3 col-md-6 col-12">
				<img src="user/img/service/4.png" alt="">
				<h4>Registration</h4>
				<p>You can Register as Public or as a Volunteer.</p>
			</div>
			<!--  Single Service  -->
			<div class="single-service text-center col-lg-3 col-md-6 col-12">
				<img src="user/img/service/2.png" alt="">
				<h4>Processing/Scheduling</h4>
				<p>Forwarding Requests From Public and Scheduling Collection Dates.</p>
			</div>
			<!--  Single Service  -->
			<div class="single-service text-center col-lg-3 col-md-6 col-12">
				<img src="user/img/service/3.png" alt="">
				<h4>Collection</h4>
				<p>Assigned Volunteers Collect according to scheduled dates.</p>
			</div>
			<!--  Single Service  -->
			<div class="single-service text-center col-lg-3 col-md-6 col-12">
				<img src="user/img/service/1.png" alt="">
				<h4>Recycling</h4>
				<p></p>
			</div>
        </div>
    </div>
</div>
<!-- Service Area End -->


<!-- FunFact Area Start -->
<div id="funfact-area" class="funfact-area section pt-120 pb-100">
    <div class="container">
        <!-- Section Title -->
        <div class="row">
            <div class="section-title text-center col-12 mb-80">
                <h2>SOME FACTS</h2>
                <p>11% of household waste is plastic, 40% of which is plastic bottles. A plastic cup can take 50 - 80 years to decompose. An estimated 13 billion plastic bottles are disposed of each year. </p>
            </div>
        </div>
        
        </div>
    </div>
</div>
<!-- FunFact Area End -->

<!-- Video Area Start -->
<div id="video-area" class="video-area section overlay pt-150 pb-150">
    <div class="container">
        <div class="row">
            <!--  Video Wrapper  -->
            <div class="video-wrapper col-12 text-center">
                <h1>WATCH A VIDEO ON POLLUTION</h1>
                <p>Plastic in waste electronics (e-waste) is an environmental time bomb that has been overlooked.</p>
                <a class="video-popup" href="https://www.youtube.com/watch?v=AUZwH14kHTY"><i class="zmdi zmdi-play-circle-outline"></i></a>
            </div>
        </div>
    </div>
</div>
<!-- Video Area End -->


<!-- Client Area Start -->
<div id="client-area" class="client-area section pt-115 pb-115">
    <div class="container">
		<!--  Client Slider  -->
		<div class="client-slider row">
			<!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/1.png" alt=""></div>
			<!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/2.png" alt=""></div>
			<!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/3.png" alt=""></div>
			<!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/4.png" alt=""></div>
			<!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/5.png" alt=""></div>
			<!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/1.png" alt=""></div>
			<!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/2.png" alt=""></div>
			<!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/3.png" alt=""></div>
			<!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/4.png" alt=""></div>
			<!--  Client Item  -->                    <!--  Client Item  -->
			<div class="client-item col-12"><img src="user/img/clients/5.png" alt=""></div>
		</div>
	</div>
</div>
<!-- Client Area End -->
        <div class="row justify-content-center">
        </div>
<!-- Blog Area Start -->

<!-- Footer Top Area Start -->
<div id="footer-top-area" class="footer-top-area bg-dark section pt-100 pb-50">
    <div class="container">
        <div class="row">
            <!--  Footer Widget  -->
            <div class="footer-widget col-lg-4 col-md-6 col-12 mb-50">
                <!--  About Widget  -->
                <div class="about-widget">
                    <img src="user/img/logo-3.png" alt="">
                    <p>Plastic in waste electronics (e-waste) is an environmental time bomb that has been overlooked.</p>
                    <!-- Footer Social -->
                    <div class="footer-social fix">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-rss"></i></a>
                        <a href="#"><i class="fa fa-google-plus"></i></a>
                        <a href="#"><i class="fa fa-pinterest-p"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <!--  Footer Widget  -->
            
            <!--  Footer Widget  -->
            
        </div>
    </div>
</div>
<!-- Footer Top Area End -->

<!-- Footer Bottom Area Start -->
<div id="footer-bottom-area" class="footer-bottom-area section">
<!-- Footer Top Area End -->
    <div class="container">
        <div class="row justify-content-between">
            <!-- Copyright -->
            <div class="copyright col-md-auto col-12">
                <p>Copyright &copy; <span>E-Plastic Managment</span> 2019. All right reserved</p>
            </div>
            <!-- Author Credit -->
            <div class="author-credit col-md-auto col-12">
                <p>Created by <a href="https://hastech.company/"></a> With <i class="fa fa-heart"></i></p>
            </div>
        </div>
    </div>
</div>
<!-- Footer Bottom Area End -->

</div>
<!-- Body main wrapper end -->

<!-- JS -->

<!-- jQuery JS
============================================ -->
<script src="user/js/vendor/jquery-1.12.0.min.js"></script>
<!-- Bootstrap JS
============================================ -->
<script src="user/js/bootstrap.bundle.min.js"></script>
<!-- Plugins JS
============================================ -->
<script src="user/js/plugins.js"></script>
<!-- Ajax Mail JS
============================================ -->
<script src="user/js/ajax-mail.js"></script>
<!-- Main JS
============================================ -->
<script src="user/js/main.js"></script>
        '; ?>


</body>


<!-- Mirrored from demo.hasthemes.com/greensoul-preview/greensoul/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 11 Feb 2021 05:13:24 GMT -->
</html>