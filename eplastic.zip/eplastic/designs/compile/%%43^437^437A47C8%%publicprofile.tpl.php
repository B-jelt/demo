<?php /* Smarty version 2.6.26, created on 2021-10-13 11:53:27
         compiled from publicprofile.tpl */ ?>
<html>
<head>
	<title>Public Profile</title>
</head>
<body >

	<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
	
	<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
			<tr><td><br></td></tr>

	<tr><td>Name</td> <td><input type="text" name="name" class="form-control" value="<?php echo $this->_tpl_vars['b']['name']; ?>
"></td></tr>
	<tr><td>Address</td> <td><textarea name="address" class="form-control"><?php echo $this->_tpl_vars['b']['address']; ?>
</textarea></td></tr> 
	<tr><td>Pincode</td> <td><input type="text" name="pincode" class="form-control" value="<?php echo $this->_tpl_vars['b']['pincode']; ?>
"></td></tr> 
<tr><td>District</td> <td><select name="district" class="form-control">
	<option><?php echo $this->_tpl_vars['b']['district']; ?>
</option>
	<option>Thiruvananthapuram</option>
	<option>Kollam</option>
	<option>Pathanamthitta</option>
    <option>Alappuzha</option>
    <option>Kottayam</option>
    <option>Idukki</option>
    <option>Eranakulam</option>
    <option>Thrissur</option>
    <option>Palakkad</option>
    <option>Malappuram</option>
    <option>Kozhikode</option>
    <option>Wayanad</option>
    <option>Kannur</option>
    <option>Kasargode</option>

</select></td></tr>	<tr><td>City</td> <td><input type="text" name="city" class="form-control" value="<?php echo $this->_tpl_vars['b']['city']; ?>
"></td></tr>
	<tr><td>Contact Number</td> <td><input type="text" name="contactnumber" class="form-control" value="<?php echo $this->_tpl_vars['b']['contactnumber']; ?>
"></td></tr> 
	<tr><td>E-mail</td> <td><input type="email" name="email" class="form-control" value="<?php echo $this->_tpl_vars['b']['email']; ?>
"></td></tr> 
	<tr><td></td><td><input type="submit" value="Update" class="btn btn-success"> </td></tr>
	<?php endforeach; endif; unset($_from); ?>
</form>
</table>
</body>
</html>