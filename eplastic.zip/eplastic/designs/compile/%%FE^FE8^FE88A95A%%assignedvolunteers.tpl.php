<?php /* Smarty version 2.6.26, created on 2021-10-13 12:30:46
         compiled from assignedvolunteers.tpl */ ?>
<html>
<head>
	<title>Collection Date View</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
						<th>Assigned volunteers</th>
		    <th>Address</th>
			<th>Contact</th>
            <th></th>
		 
		</tr>
				<?php $_from = $this->_tpl_vars['volunteersel']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			 <td><?php echo $this->_tpl_vars['Z']['name']; ?>
</td>
		     <td><?php echo $this->_tpl_vars['Z']['address']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['contactnumber']; ?>
</td>			
			

		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>