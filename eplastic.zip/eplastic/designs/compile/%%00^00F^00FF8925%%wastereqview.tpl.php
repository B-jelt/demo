<?php /* Smarty version 2.6.26, created on 2021-06-29 08:11:19
         compiled from wastereqview.tpl */ ?>
<html>
<head>
	<title>Waste Requests</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			
				<th>Aadhar No</th>
<th>Waste Details</th>
<th>Ward No</th>
<th>House No</th>
<th>Other Details </th>
<th>Collection Date </th>
<th colspan="2">Status </th>
<th>Payment</th>

		</tr>
				<?php $_from = $this->_tpl_vars['wastereq']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>


		<tr>
			
			<td><?php echo $this->_tpl_vars['Z']['aadharno']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['wastedetails']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['wardno']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['houseno']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['otherdetails']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['date']; ?>
</td>
			

					<?php if ($this->_tpl_vars['Z']['approvestatus'] == 1): ?>
					<td>your request is approved </td>
					<?php elseif ($this->_tpl_vars['Z']['approvestatus'] == 2): ?>
					<td>your request is rejected </td>

 				<?php else: ?>
				<td><a href="wastereqedit.php?key=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
" class="btn btn-success">Edit</a></td>
		<td><a href="wastereqdelete.php?key=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
" class="btn btn-danger">Delete</a></td>

			<?php endif; ?>
			<td colspan="2"><a href="payment.php?key=150" class="btn btn-success">Pay</a></td>
		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>