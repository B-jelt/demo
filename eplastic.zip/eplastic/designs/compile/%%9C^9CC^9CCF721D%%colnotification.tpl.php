<?php /* Smarty version 2.6.26, created on 2021-04-16 11:02:43
         compiled from colnotification.tpl */ ?>
<html>
<head>
	<title>Colection Notification</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Name</th>
			<th>Adress</th>
			<th>Contact</th>
			<th>Ward number</th>
			<th>House number</th>
			<th>Waste details</th>
			<th>Other details</th>
			<th>Date</th>
		 
		</tr>
				<?php $_from = $this->_tpl_vars['notification']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			<td><?php echo $this->_tpl_vars['Z']['name']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['address']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['contactnumber']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['wardno']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['houseno']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['wastedetails']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['otherdetails']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['currentdate']; ?>
</td>

		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>