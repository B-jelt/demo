<?php /* Smarty version 2.6.26, created on 2021-10-13 12:16:57
         compiled from wastereq.tpl */ ?>
<html>
<head>
	<title>Waste Collection Request</title>
</head>
<body >
	<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
	<tr><td><br></td></tr>
    <tr><td>Aadhar No</td> <td><input type="text" name="aadharno" class="form-control"></td></tr> <tr><td>&nbsp;</td></tr>
     <tr><td>Waste Material Details</td> <td><textarea input type="text" name="wastedetails" class="form-control"></textarea></td></tr> <tr><td>&nbsp;</td></tr>

	<tr><td>Ward No</td> <td><input type="text" name="wardno" class="form-control"></td></tr> <tr><td>&nbsp;</td></tr>
	<tr><td>House No</td> <td><textarea name="houseno" class="form-control"></textarea></td></tr> <tr><td>&nbsp;</td></tr>
	<tr><td>Other Details</td> <td> <textarea input type="text" name="otherdetails" class="form-control"> </textarea></td></tr> <tr><td>&nbsp;</td></tr>
	<tr><td></td><td><input type="submit" value="Register" class="btn btn-dark"> </td></tr>
</form>
</table>
</body>
</html>