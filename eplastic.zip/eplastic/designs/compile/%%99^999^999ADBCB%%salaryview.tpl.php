<?php /* Smarty version 2.6.26, created on 2021-10-25 09:36:05
         compiled from salaryview.tpl */ ?>
<html>
<head>
	<title>Salary view</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Month</th>
			<th>Salary</th>


		</tr>
				<?php $_from = $this->_tpl_vars['salarytable']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['z']):
?>

		<tr>
			<td><?php echo $this->_tpl_vars['z']['month']; ?>
</td>
			<td><?php echo $this->_tpl_vars['z']['salary']; ?>
</td>

			
		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>