<?php /* Smarty version 2.6.26, created on 2021-02-23 08:08:50
         compiled from complaintedit.tpl */ ?>
<html>
<head>
	<title>Complaint Edit</title>
</head>
<body >
	<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
	<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
	<tr><td>Subject</td> <td><input type="text" name="subject" class="form-control" value="<?php echo $this->_tpl_vars['b']['subject']; ?>
"></td></tr>
	<tr><td>Complaint</td> <td><textarea name="complaint" class="form-control"><?php echo $this->_tpl_vars['b']['complaint']; ?>
</textarea></td></tr> 
	<tr><td></td><td><input type="submit" value="Update" class="btn btn-success"> </td></tr>
	<?php endforeach; endif; unset($_from); ?>
</form>
</table>
</body>
</html>