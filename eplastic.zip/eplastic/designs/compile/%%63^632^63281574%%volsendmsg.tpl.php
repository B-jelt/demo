<?php /* Smarty version 2.6.26, created on 2021-10-13 12:25:16
         compiled from volsendmsg.tpl */ ?>
<html>
<head>
	<title>Send Message</title>
</head>
<body >
		<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
	<tr><td><br></td></tr>
	<tr><td>Send Message</td> <td><textarea name="msg" class="form-control"></textarea></td></tr>
	<tr><td></td><td><input type="submit" value="Send" class="btn btn-success"> </td></tr>
</form>
</table>

<?php if ($this->_tpl_vars['view'] != null): ?>

	<tr><td><br></td></tr>

<table class="table table-striped">
		<tr>
			<th>Message</th>
			<th>Date</th>
			<th>Time</th>
			<th></th>
		</tr>
				<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			<td><?php echo $this->_tpl_vars['Z']['msg']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['currentdate']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['currenttime']; ?>
</td>
			<td><a href="volmsgdelete.php?key=<?php echo $this->_tpl_vars['Z']['msgkey']; ?>
" class="btn btn-danger">Delete</a></td>

		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
	<?php endif; ?>
</body>
</html>