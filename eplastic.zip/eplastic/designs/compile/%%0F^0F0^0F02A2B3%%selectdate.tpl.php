<?php /* Smarty version 2.6.26, created on 2021-09-21 12:43:30
         compiled from selectdate.tpl */ ?>
<html>
<head>
	<title></title>
</head>
<body>
	
	<table class="table table-striped">
		<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
		<tr>
			<th>Date</th>
			<th>Other Details</th>
		</tr>
		<tr>
			<td><input type="date" name="date" class="form-control"></td>
			<td><textarea  name="otherdetails" class="form-control"></textarea></td>
			<td><input type="hidden" name="hide" value="h"></td>
		</tr>
		<tr>
</tr>

<tr><td> 
		<center>
		<input  type="submit" value="Submit" class="btn btn-success"></center> </td></tr>
		</form>
</table>

<br>
<br>
</body>
</html>