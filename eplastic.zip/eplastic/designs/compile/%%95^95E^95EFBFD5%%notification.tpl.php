<?php /* Smarty version 2.6.26, created on 2021-10-25 07:10:32
         compiled from notification.tpl */ ?>
<html>
<head>
	<title>Notification </title>
</head>
<body >
		<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
	<tr><td><br></td></tr>
	<tr><td>Notification</td> <td><textarea name="message" class="form-control"></textarea></td></tr>
	<tr><td></td><td><input type="submit" value="Submit" class="btn btn-success"> </td></tr>
</form>
</table>
</body>
</html>