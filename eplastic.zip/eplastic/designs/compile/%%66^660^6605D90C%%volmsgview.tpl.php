<?php /* Smarty version 2.6.26, created on 2021-06-25 09:18:43
         compiled from volmsgview.tpl */ ?>
<html>
<head>
	<title>View Message</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Message</th>
			<th>Date</th>
			<th>Time</th>
		 
		</tr>
				<?php $_from = $this->_tpl_vars['volsendmsg']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			<td><?php echo $this->_tpl_vars['Z']['msg']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['date']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['t']; ?>
</td>
			<td><a href="complaintdelete.php?key=<?php echo $this->_tpl_vars['Z']['ckey']; ?>
" class="btn btn-danger">Delete</a></td>

		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>