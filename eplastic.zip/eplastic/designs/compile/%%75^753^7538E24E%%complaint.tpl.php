<?php /* Smarty version 2.6.26, created on 2021-10-13 11:53:59
         compiled from complaint.tpl */ ?>
<html>
<head>
	<title>Submit Complaints</title>
</head>
<body >
		<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
			<tr><td><br></td></tr>

    <tr><td>Subject</td> <td><input type="text" name="subject" class="form-control"></td></tr> 
	<tr><td>Complaint</td> <td><textarea name="complaint" class="form-control"></textarea></td></tr>
	<tr><td></td><td><input type="submit" value="Submit" class="btn btn-success"> </td></tr>
</form>
</table>
</body>
</html>