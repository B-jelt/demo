<?php /* Smarty version 2.6.26, created on 2021-04-14 08:19:24
         compiled from volunteersel.tpl */ ?>
<html>
<head>
	<title>Collection Date View</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
						<th>Name</th>
		    <th>Address</th>
			<th>Contact</th>
            <th></th>
		 
		</tr>
				<?php $_from = $this->_tpl_vars['volunteerreg']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			 <td><?php echo $this->_tpl_vars['Z']['name']; ?>
</td>
		     <td><?php echo $this->_tpl_vars['Z']['address']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['contactnumber']; ?>
</td>			
			<td><a href="volunteerconfirm.php?wastekey=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
&&vkey=<?php echo $this->_tpl_vars['Z']['vkey']; ?>
" class="btn btn-info">Select Volunteer</a></td>


		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>