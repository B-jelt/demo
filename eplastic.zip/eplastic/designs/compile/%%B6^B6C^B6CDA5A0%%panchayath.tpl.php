<?php /* Smarty version 2.6.26, created on 2021-10-25 07:30:35
         compiled from panchayath.tpl */ ?>
<html>
<head>
	<title>Panchayath Details</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Panchayath ID</th>
			<th>Panchayath Name</th>
			<th>Address</th>
			<th>Pincode</th>
			<th>District</th>
			<th>Taluk</th>
			<th>Village</th>
			<th>City</th>
			<th>Contact Number</th>
			<th>e-mail</th>
			<th>Approval</th>
			<th>Reject</th>
		</tr>
		<?php $_from = $this->_tpl_vars['panchayatreg']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>
		<tr>
			<td><?php echo $this->_tpl_vars['Z']['panchayatid']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['panchayatname']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['address']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['pincode']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['district']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['taluk']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['village']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['city']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['contactnumber']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['email']; ?>
</td>
			<?php if ($this->_tpl_vars['Z']['status'] == 1): ?>
			<td><b>Approved</b></td>
			<td><a href="panchayathreject.php?key=<?php echo $this->_tpl_vars['Z']['ekey']; ?>
" class="btn btn-danger">Reject</a></td>
			<?php elseif ($this->_tpl_vars['Z']['status'] == 2): ?>
			<td><a href="panchayathapprove.php?key=<?php echo $this->_tpl_vars['Z']['ekey']; ?>
" class="btn btn-success">Approve</a></td>
			<td><b>Rejected</b></td>
			<?php else: ?>
			<td><a href="panchayathapprove.php?key=<?php echo $this->_tpl_vars['Z']['ekey']; ?>
" class="btn btn-success">Approve</a></td>
			<td><a href="panchayathreject.php?key=<?php echo $this->_tpl_vars['Z']['ekey']; ?>
" class="btn btn-danger">Reject</a></td>
			<?php endif; ?>
		</tr>
        <?php endforeach; endif; unset($_from); ?>
	</table>
</body>
</html>