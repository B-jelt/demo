<?php /* Smarty version 2.6.26, created on 2021-04-14 10:48:10
         compiled from selectdateedit.tpl */ ?>
<html>
<head>
	<title> Edit</title>
</head>
<body >
	<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
	<?php $_from = $this->_tpl_vars['view']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['b']):
?>
	<tr><td>Other Details</td> <td><textarea name="otherdetails" class="form-control"><?php echo $this->_tpl_vars['b']['otherdetails']; ?>
</textarea></td></tr>
			<tr><td>Date</td><td><input type="date" name="date" value="<?php echo $this->_tpl_vars['b']['date']; ?>
" class="form-control"></td> </tr>
	<tr><td></td><td><input type="submit" value="Update" class="btn btn-success"> </td></tr>
	<?php endforeach; endif; unset($_from); ?>
</form>
</table>
</body>
</html>