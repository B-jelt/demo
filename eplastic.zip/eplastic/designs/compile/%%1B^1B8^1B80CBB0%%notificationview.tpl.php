<?php /* Smarty version 2.6.26, created on 2021-10-25 07:11:30
         compiled from notificationview.tpl */ ?>
<html>
<head>
	<title>Notification View</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Notification</th>
			<th>Date</th>
		 	<th></th>
		 	<th></th>
		</tr>
				<?php $_from = $this->_tpl_vars['notification']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			<td><?php echo $this->_tpl_vars['Z']['notification']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['currentdate']; ?>
</td>
			<td><a href="notificationedit.php?key=<?php echo $this->_tpl_vars['Z']['nkey']; ?>
" class="btn btn-success">Edit</a></td>
			<td><a href="notificationdelete.php?key=<?php echo $this->_tpl_vars['Z']['nkey']; ?>
" class="btn btn-danger">Delete</a></td>

		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>