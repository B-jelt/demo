<?php /* Smarty version 2.6.26, created on 2021-10-13 12:22:07
         compiled from subheader.tpl */ ?>
<!doctype html>
<html class="no-js" lang="en">

<!-- Mirrored from demo.hasthemes.com/greensoul-preview/greensoul/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 11 Feb 2021 05:13:37 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>About us - E-Plastic Managment System</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="user/img/favicon.ico">
    <!-- CSS -->
    <!-- Bootstrap CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/bootstrap.min.css">
    <!-- Icon Font CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- Plugins CSS
	============================================ -->
    <link rel="stylesheet" href="user/css/plugins.css">
    <!-- Style CSS
	============================================ -->
    <link rel="stylesheet" href="user/style.css">
    <!-- Modernizer JS
	============================================ -->
	<?php echo '
    <script src="user/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<!-- Body main wrapper start -->
<div class="wrapper fix">

<!-- Header Area Start -->
<div id="header-area" class="header-area section">

<!-- Header Top Start -->

<!-- Header Bottom Start -->
<div class="header-bottom">
    <div class="container">
        <div class="row">
			<!-- Logo -->
			<div class="header-logo col align-self-center"><a class="logo" href="index.html"><img src="user/img/logo.png" alt=""></a></div>
			<!-- Main Menu -->
			<div id="main-menu" class="main-menu col-auto d-none d-lg-block">
				<nav>
					<ul>
						<li><a href="index.php">home</a>
						
						</li>
                        <li><a href="aboutus.php">About Us</a></li>

						<li><a href="#">Registrations</a>
							<ul>
								<li><a href="volunteer.php">Volunteer</a></li>
								<li><a href="panchayatreg.php">Panchayath</a></li>
								<li><a href="publicreg.php">Public</a></li>
							</ul>
						</li>
                      <li><a href="login.php">Login</a></li>

						
					</ul>
				</nav>
			</div>
		
			<!-- Mobile Menu -->
			<div class="mobile-menu col-12 d-lg-none"></div>
        </div>
    </div>
</div>
<!-- Header Bottom End -->

</div>
<!-- Header Area End -->

<!-- Page Banner Area Start -->
<div class="page-banner-area section overlay gradient">
    <div class="container">
        <div class="row">
            <div class="page-banner col-12">
               
            </div>
        </div>
    </div>
</div>
<!-- Page Banner Area End -->
'; ?>

<br><br>