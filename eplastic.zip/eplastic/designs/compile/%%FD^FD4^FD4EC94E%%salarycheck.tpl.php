<?php /* Smarty version 2.6.26, created on 2021-10-25 07:08:54
         compiled from salarycheck.tpl */ ?>
<html>
<head>
	<title>Salary Check</title>
</head>
<body>
	<table class="table table-striped">
				<table align="center">
<form method="POST" action="">
	<input type="hidden" name="hide" value="h">
	<tr><td>Month</td> <td>
		<select name="month">
			<option value="1">January</option>
        <option value="2">February</option>
        <option value="3">March</option>
        <option value="4">April</option>
        <option value="5">May</option>
        <option value="6">June</option>
        <option value="7">July</option>
        <option value="8">August</option>
        <option value="9">September</option>
        <option value="10">October</option>
        <option value="11">November</option>
        <option value="12">December</option>
    </select>
    </td>
	</tr>
	<tr><td>Salary</td> <td><input type="number" name="salary" class="form-control"></input></td></tr>
	<tr><td></td><td><input type="submit" value="Submit" class="btn btn-success"></td></tr>
</form>
</table>
	</table>
</body>
</html>