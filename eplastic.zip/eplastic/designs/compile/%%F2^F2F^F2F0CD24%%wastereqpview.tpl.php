<?php /* Smarty version 2.6.26, created on 2021-10-25 07:13:13
         compiled from wastereqpview.tpl */ ?>
<html>
<head>
	<title>Waste Requests</title>
</head>
<body>
	<table class="table table-striped">
		<tr>
			<th>Name</th>
			<th>Address</th>
			<th>Pincode</th>
			<th>District</th>
			<th>City</th>
				<th>Contact No</th>
				<th>Aadhar No</th>
<th>Waste Details</th>
<th>Ward No</th>
<th>House No</th>
<th>Other Details </th>
<th colspan="2">Approval Status </th>

		</tr>
				<?php $_from = $this->_tpl_vars['wastereq']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['Z']):
?>

		<tr>
			<td><?php echo $this->_tpl_vars['Z']['name']; ?>
</td>
	          <td><?php echo $this->_tpl_vars['Z']['address']; ?>
</td>
   	          <td><?php echo $this->_tpl_vars['Z']['pincode']; ?>
</td>
          <td><?php echo $this->_tpl_vars['Z']['district']; ?>
</td>
          <td><?php echo $this->_tpl_vars['Z']['city']; ?>
</td>
   	          <td><?php echo $this->_tpl_vars['Z']['contactnumber']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['aadharno']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['wastedetails']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['wardno']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['houseno']; ?>
</td>
			<td><?php echo $this->_tpl_vars['Z']['otherdetails']; ?>
</td>
			<?php if ($this->_tpl_vars['Z']['approvestatus'] == 1): ?>
			<td><b>Approved</b></td>
			<td><a href="selectdate.php?key=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
" class="btn btn-primary">add date</a></td>
			<td><a href="wastereqreject.php?key=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
" class="btn btn-danger">Reject</a></td>
			<?php elseif ($this->_tpl_vars['Z']['approvestatus'] == 2): ?>
			<td><a href="wastereqapprove.php?key=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
" class="btn btn-success">Approve</a></td>
			<td><b>Rejected</b></td>
			<?php else: ?>
			<td><a href="wastereqapprove.php?key=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
" class="btn btn-success">Approve</a></td>
			<td><a href="wastereqreject.php?key=<?php echo $this->_tpl_vars['Z']['wkey']; ?>
" class="btn btn-danger">Reject</a></td>
			<?php endif; ?>
		</tr>
		        <?php endforeach; endif; unset($_from); ?>

	</table>
</body>
</html>