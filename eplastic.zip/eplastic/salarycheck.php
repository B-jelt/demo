<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();

session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$key=$_COOKIE['ekey'];
$key1=$_GET['key'];
//$z=$obj->salarycheck($key);
//$smartyObj->assign("salarytable",$z);


if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	if(isset($_POST['month'])AND($_POST['month'])!=null)
	{

	if(isset($_POST['salary'])AND($_POST['salary'])!=null)
	{
	
			        $a=trim($_POST['month']);
					$b=trim($_POST['salary']);
					$obj->paymentpan($a,$b,$key,$key1);
				}
				
			
				else
					echo"<script>alert('salary is empty')</script>";
			     }
			else
					echo"<script>alert('month is empty')</script>";
			}




$smartyObj->display("panchayathsubheader.tpl");
$smartyObj->display('salarycheck.tpl'); 
$smartyObj->display("footer.tpl");
}
else
{	
	Header("location:index.php");
}
?>