<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$key=$_COOKIE['ekey'];
$sel=$obj->updpanchayath($key);
$smartyObj->assign("view",$sel);
if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	if(isset($_POST['panchayatid'])AND($_POST['panchayatid'])!=null)
	{

	if(isset($_POST['panchayatname'])AND($_POST['panchayatname'])!=null)
	{
		if(isset($_POST['address'])AND($_POST['address'])!=null)
		{
		if(isset($_POST['pincode'])AND($_POST['pincode'])!=null)
		{
			if(isset($_POST['district'])AND($_POST['district'])!=null)
		{
			if(isset($_POST['taluk'])AND($_POST['taluk'])!=null)
		{
			if(isset($_POST['village'])AND($_POST['village'])!=null)
		{
			if(isset($_POST['city'])AND($_POST['city'])!=null)
		{
			if(isset($_POST['contactnumber'])AND($_POST['contactnumber'])!=null)
		{

			if(isset($_POST['email'])AND($_POST['email'])!=null)
			{
			        $a=trim($_POST['panchayatid']);
					$b=trim($_POST['panchayatname']);
					$c=trim($_POST['address']);
					$d=trim($_POST['pincode']);
				    $e=trim($_POST['district']);
				    $f=trim($_POST['taluk']);
				    $g=trim($_POST['village']);
                    $h=trim($_POST['city']);
                    $i=trim($_POST['contactnumber']);
					$j=trim($_POST['email']);
					 $obj->updatepanchayath($a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$key);
				}
				else
					echo"<script>alert('email is empty')</script>";
				}
				else
					echo"<script>alert('contactnumber is empty')</script>";
				}
				
				else
					echo"<script>alert('city is empty')</script>";

				}
				else
					echo"<script>alert('village is empty')</script>";

				}

				else
					echo"<script>alert('taluk is empty')</script>";

				}

				else
					echo"<script>alert('district is empty')</script>";
				}
				else
					echo"<script>alert('pincode is empty')</script>";
				
				}
				else
					echo"<script>alert('address is empty')</script>";
				}
				else
					echo"<script>alert('panchayatname is empty')</script>";
			     }
			else
					echo"<script>alert('panchayatid is empty')</script>";
			}

			 $smartyObj->display('panchayathsubheader.tpl');

			$smartyObj->display('panchayathprofile.tpl');

			 $smartyObj->display('footer.tpl');
}
else
{	
	Header("location:index.php");
}
			 
			?>
