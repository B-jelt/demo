<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$key=$_GET['key'];
$sel=$obj->editnotification($key);
$smartyObj->assign("view",$sel);
if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	
		if(isset($_POST['notification'])AND($_POST['notification'])!=null)
		{
		
					$b=trim($_POST['notification']);
					 $obj->notificationedit($b,$key);
				}
				
				
				else
					echo"<script>alert('message is empty')</script>";
			}

			 $smartyObj->display('panchayathsubheader.tpl');

			$smartyObj->display('notificationedit.tpl');

			 $smartyObj->display('footer.tpl');
		
}
else
{	
	Header("location:index.php");
}
?>