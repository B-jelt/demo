<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$key=$_COOKIE['ekey'];
$sel=$obj->updpublic($key);
$smartyObj->assign("view",$sel);
if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	if(isset($_POST['name'])AND($_POST['name'])!=null)
	{
		if(isset($_POST['address'])AND($_POST['address'])!=null)
		{
		if(isset($_POST['pincode'])AND($_POST['pincode'])!=null)
		{
			if(isset($_POST['district'])AND($_POST['district'])!=null)
		{
			if(isset($_POST['city'])AND($_POST['city'])!=null)
		{
			if(isset($_POST['contactnumber'])AND($_POST['contactnumber'])!=null)
		{

			if(isset($_POST['email'])AND($_POST['email'])!=null)
			{
					$a=trim($_POST['name']);
					$b=trim($_POST['address']);
					$c=trim($_POST['pincode']);
				    $d=trim($_POST['district']);
                    $e=trim($_POST['city']);
                    $f=trim($_POST['contactnumber']);
					$g=trim($_POST['email']);
					 $obj->updatepublic($a,$b,$c,$d,$e,$f,$g,$key);
				}
				else
					echo"<script>alert('email is empty')</script>";
				}
				else
					echo"<script>alert('contactnumber is empty')</script>";
				}
				
				else
					echo"<script>alert('city is empty')</script>";

				}
				else
					echo"<script>alert('district is empty')</script>";
				}
				else
					echo"<script>alert('pincode is empty')</script>";
				
				}
				else
					echo"<script>alert('address is empty')</script>";
				}
				else
					echo"<script>alert('name is empty')</script>";
			}

			 $smartyObj->display('publicsubheader.tpl');

			$smartyObj->display('publicprofile.tpl');

			 $smartyObj->display('footer.tpl');
			 }
else
{	
	Header("location:index.php");
}
			?>
