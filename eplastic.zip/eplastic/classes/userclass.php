<?php
class userclass
{
function eplastic($a,$b,$c,$d,$z,$e,$f,$g,$h)  
{
    $enc=md5($h);
    $key1=uniquekey("login","ekey");
    $qry1="insert into login(ekey,email,password,usertype,status)values('".$key1."', '".$g."', '".$enc."','3','1')";
    $exe1=mysql_query($qry1);
    $key=uniquekey("publicreg","pkey");
    $id=keytoid("login","ekey",$key1);
    $qry="insert into publicreg(pkey,name, address,pincode,district,panchayatname,city,contactnumber,loginid)
    values('".$key."', '".$a."', '".$b."', '".$c."', '".$d."', '".$z."','".$e."','".$f."','".$id."')";
    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe && $exe1)
     {
        echo"<script>alert('Registration Successful')</script>";
     }
     else
     {
        echo"<script>alert('Registration Unsuccessful')</script>";
     }
 }
 
 function seldistrict()
 {
 $qry="select * from panchayatreg";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
} 

 function selpanchayat($a)
 {
 $qry="select * from panchayatreg inner join login on panchayatreg.loginid=login.id where district='".$a."'";
 // echo $qry;exit();
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
} 

 function panchayat($a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k)
 {
   $enc=md5($k);
    $key1=uniquekey("login","ekey");
    $qry1="insert into login(ekey,email,password,usertype)values('".$key1."', '".$j."', '".$enc."','1')";
    $exe1=mysql_query($qry1); 
    $key=uniquekey("panchayatreg","qkey");
    $id=keytoid("login","ekey",$key1);
    $qry="insert into panchayatreg(qkey,panchayatid,panchayatname,address,pincode,district,taluk,village,city,contactnumber,loginid)
    values('".$key."', '".$a."', '".$b."', '".$c."', '".$d."','".$e."','".$f."','".$g."','".$h."','".$i."','".$id."')";
    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe && $exe1)
     {
        echo"<script>alert('Registration Successful')</script>";
     }
     else
     {
        echo"<script>alert('Registration Unsuccessful')</script>";
     } 
     }	

     function volunteer($a,$b,$c,$d,$z,$e,$f,$g,$h)
 {
   $enc=md5($h);
    $key1=uniquekey("login","ekey");
    $qry1="insert into login(ekey,email,password,usertype)values('".$key1."', '".$g."', '".$enc."','2')";
    $exe1=mysql_query($qry1); 
    $key=uniquekey("volunteerreg","vkey");
    $id=keytoid("login","ekey",$key1);
    $qry="insert into volunteerreg(vkey,name,address,pincode,district,panchayathname,city,contactnumber,loginid)
    values('".$key."', '".$a."', '".$b."', '".$c."', '".$d."', '".$z."','".$e."','".$f."','".$id."')";
    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe && $exe1)
     {
        echo"<script>alert('Registration Successful')</script>";
     }
     else
     {
        echo"<script>alert('Registration Unsuccessful')</script>";
     } 
     }
     function login($a,$b)
    {
    $enc=md5($b);
    $qry="select ekey,status,usertype from login where email='".$a."' and password='".$enc."'";
    // echo $qry;exit();
    $exe=mysql_query($qry);
    // $key=null;
    $c=0;
    while($rr=mysql_fetch_array($exe))
    {
        $c=$c+1;
        $key=$rr['ekey'];
        $u=$rr['usertype'];
        $s=$rr['status'];
        // echo $key;exit();
    }
    if($c>0)
    {
        setcookie("ekey",$key);
        setcookie("logined",1);
        if($s==1)
        {
            if($u==0)
            {
                header("location:adminhome.php");
            }
            elseif($u==1)
            {
                header("location:panchayathome.php");
            }
            elseif($u==2)
            {
                header("location:volunteerhome.php");
            }
            else
            {
                header("location:publichome.php");
            }
        }
        else
        {
            echo "<script>alert('Waiting for admin approval')</script>";
        }
    }
    else
    {
        echo "<script>alert('Invalid user')</script>";
    }
} 
function selectpanchayath()
{
    $qry="select * from panchayatreg inner join login on panchayatreg.loginid=login.id";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
} 	
function panchayathapprove($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="update login set status='1' where id='".$id."'";
    $exe=mysql_query($qry);
    if($exe)
    {
        echo "<script>alert('Approved Successfully');
        window.location.href='panchayath.php'</script>";
    }
    else
    {
        echo "<script>alert('Not Approved')</script>";
    }
}
function panchayathreject($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="update login set status='2' where id='".$id."'";
    $exe=mysql_query($qry);
    if($exe)
    {
        echo "<script>alert('Rejected Successfully');
        window.location.href='panchayath.php'</script>";
    }
    else
    {
        echo "<script>alert('Not Rejected')</script>";
    }
}

    function selectvolunteers()
{
    $qry="select * from volunteerreg inner join login on volunteerreg.loginid=login.id";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}   
function volunteersapprove($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="update login set status='1' where id='".$id."'";
    $exe=mysql_query($qry);
    if($exe)
    {
        echo "<script>alert('Approved Successfully');
        window.location.href='volunteers.php'</script>";
    }
    else
    {
        echo "<script>alert('Not Approved')</script>";
    }
}
function volunteersreject($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="update login set status='2' where id='".$id."'";
    $exe=mysql_query($qry);
    if($exe)
    {
        echo "<script>alert('Rejected Successfully');
        window.location.href='volunteers.php'</script>";
    }
    else
    {
        echo "<script>alert('Not Rejected')</script>";
    }
}


function publics()
{
    $qry="select * from publicreg inner join login on publicreg.loginid=login.id";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}   
function updpublic($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from publicreg inner join login on publicreg.loginid=login.id where login.id='".$id."'";
    //echo $qry;exit;
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}
function updatepublic($a,$b,$c,$d,$e,$f,$g,$key)
{
     $id=keytoid("login","ekey",$key);
     $qry="update login set email='".$g."' where id='".$id."'";
     $exe=mysql_query($qry);
     $qry1="update publicreg set name='".$a."',address='".$b."',pincode='".$c."',district='".$d."',city='".$e."',contactnumber='".$f."' where loginid='".$id."'";
     $exe1=mysql_query($qry1);
     if($exe&&$exe1)
     {
        echo "<script>alert('Profile Updated Successfully')</script>";
     }
     else
     {
         echo "<script>alert('Profile Not  Updated Successfully')</script>";
     }
 }

 function updvolunteer($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from volunteerreg inner join login on volunteerreg.loginid=login.id where login.id='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}
function updatevolunteer($a,$b,$c,$d,$z,$e,$f,$g,$key)
{
     $id=keytoid("login","ekey",$key);
     $qry="update login set email='".$g."' where id='".$id."'";
     $exe=mysql_query($qry);
     $qry1="update volunteerreg set name='".$a."',address='".$b."',pincode='".$c."',district='".$d."',panchayathname='".$z."',city='".$e."',contactnumber='".$f."' where loginid='".$id."'";
     $exe1=mysql_query($qry1);
     if($exe&&$exe1)
     {
        echo "<script>alert('Profile Updated Successfully')</script>";
     }
     else
     {
         echo "<script>alert('Profile Not  Updated Successfully')</script>";
     }
 }


 function updpanchayath($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from panchayatreg inner join login on panchayatreg.loginid=login.id where login.id='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}
function updatepanchayath($a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$key)
{
     $id=keytoid("login","ekey",$key);
     $qry="update login set email='".$j."' where id='".$id."'";
     $exe=mysql_query($qry);
     $qry1="update panchayatreg set panchayatid='".$a."',panchayatname='".$b."',address='".$c."',pincode='".$d."',district='".$e."',taluk='".$f."',village='".$g."',city='".$h."',contactnumber='".$i."' where loginid='".$id."'";
     // echo $qry1;exit;
     $exe1=mysql_query($qry1);
     if($exe&&$exe1)
     {
        echo "<script>alert('Profile Updated Successfully')</script>";
     }
     else
     {
         echo "<script>alert('Profile Not  Updated Successfully')</script>";
     }
 }

function complaint($a,$b,$key)
 {
    $keyy=uniquekey("complaint","ckey");
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);
    $qry="insert into complaint(ckey,subject,complaint,loginid,currentdate)
    values('".$keyy."', '".$a."', '".$b."','".$id."','".$date."')";
    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe)
     {
        echo"<script>alert('Complaint Submission Successful')</script>";
     }
     else
     {
        echo"<script>alert('Complaint Submission Unsuccessful')</script>";
     } 
    } 

    function complaintview()
{
    $qry="select * from complaint inner join login on complaint.loginid=login.id inner join publicreg on publicreg.loginid=complaint.loginid";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    

 function complaintpview($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from complaint where loginid='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    

function editcomplaint($key)
{
    $id=keytoid("complaint","ckey",$key);
    $qry="select * from complaint where id='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}

function complaintedit($a,$b,$key)
{
     $id=keytoid("complaint","ckey",$key);
     $date=date('Y-m-d');
     $qry1="update complaint set subject='".$a."',complaint='".$b."',currentdate='".$date."' where id='".$id."'";
     $exe1=mysql_query($qry1);
     if($exe1)
     {
        echo "<script>alert('Complaint Updated Successfully');
        window.location.href='complaintpview.php'</script>";
     }
     else
     {
         echo "<script>alert('Complaint Not  Updated Successfully')</script>";
     }
 }
 function complaintdelete($key)
 {
     $id=keytoid("complaint","ckey",$key);
     $qry="delete from complaint where id='".$id."'";
    $exe1=mysql_query($qry);
     if($exe1)
     {
        echo "<script>alert('Complaint Deleted Successfully');
        window.location.href='complaintpview.php'</script>";
     }
     else
     {
         echo "<script>alert('Complaint Not  Deleted')</script>";
     }
 }
 function selpanchayath()
 {
    $qry="select * from panchayatreg";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
 }
 function volunteersview($key)
 {
    $id=keytoid("login","ekey",$key);
    $qry="select * from volunteerreg inner join login on volunteerreg.loginid=login.id where volunteerreg.panchayathname='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
 }

 function notification($b,$key)
 {
    $keyy=uniquekey("notification","nkey");
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);
    $qry="insert into notification(nkey,notification,loginid,currentdate)
    values('".$keyy."','".$b."','".$id."','".$date."')";
    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe)
     {
        echo"<script>alert('Messaage Sent Successful')</script>";
     }
     else
     {
        echo"<script>alert('Message Sent Unsuccessful')</script>";
     } 
    } 
function notificationview($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from notification where loginid='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    


function editnotification($key)
{
    $id=keytoid("notification","nkey",$key);
    $qry="select * from notification where id='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}

function notificationedit($b,$key)
{
     $id=keytoid("notification","nkey",$key);
     $date=date('Y-m-d');
     $qry1="update notification set notification='".$b."',currentdate='".$date."' where id='".$id."'";
     $exe1=mysql_query($qry1);
     if($exe1)
     {
        echo "<script>alert('Message Updated Successfully');
        window.location.href='notificationview.php'</script>";
     }
     else
     {
         echo "<script>alert('Message Not  Updated Successfully')</script>";
     }
 }

 function notificationdelete($key)
 {
     $id=keytoid("notification","nkey",$key);
     $qry="delete from notification where id='".$id."'";
    $exe1=mysql_query($qry);
     if($exe1)
     {
        echo "<script>alert('Notification Deleted Successfully');
        window.location.href='notificationview.php'</script>";
     }
     else
     {
         echo "<script>alert('Notification Not  Deleted')</script>";
     }
 }

function vnotification($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from notification inner join volunteerreg on notification.loginid=volunteerreg.panchayathname where volunteerreg.loginid='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    



function wastereq($a,$b,$c,$d,$e,$key)
 {
    $keyy=uniquekey("wastereq","wkey");
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);
    $qry="insert into wastereq(wkey,aadharno,wastedetails,wardno,houseno,otherdetails,loginid,currentdate)
    values('".$keyy."', '".$a."', '".$b."', '".$c."', '".$d."', '".$e."','".$id."','".$date."')";
    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe)
     {
        echo"<script>alert('Request Submission Successful')</script>";
     }
     else
     {
        echo"<script>alert('Request Submission Unsuccessful')</script>";
     } 
    } 

 function wastereqpview($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from wastereq inner join publicreg on publicreg.loginid=wastereq.loginid where publicreg.panchayatname='".$id."' ";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    




function wastereqapprove($key)
{
    $id=keytoid("wastereq","wkey",$key);
    $qry="update wastereq set approvestatus='1' where id='".$id."'";
    $exe=mysql_query($qry);
    if($exe)
    {
        echo "<script>alert('Approved Successfully');
        window.location.href='wastereqpview.php'</script>";
    }
    else
    {
        echo "<script>alert('Not Approved')</script>";
    }
}
function wastereqreject($key)
{
    $id=keytoid("wastereq","wkey",$key);
    $qry="update wastereq set approvestatus='2' where id='".$id."'";
    $exe=mysql_query($qry);
    if($exe)
    {
        echo "<script>alert('Rejected Successfully');
        window.location.href='wastereqpview.php'</script>";
    }
    else
    {
        echo "<script>alert('Not Rejected')</script>";
    }
}


function wastereqview($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from wastereq inner join publicreg on publicreg.loginid=wastereq.loginid inner join selectdate on wastereq.id=selectdate.wasterequestid where publicreg.loginid='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    

function wastereqedit($key)
{
    $id=keytoid("wastereq","wkey",$key);
    $qry="select * from wastereq where id='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}

function editwastereq($a,$b,$c,$d,$e,$key)
{
     $id=keytoid("wastereq","wkey",$key);
     $date=date('Y-m-d');
     $qry1="update wastereq set aadharno='".$a."',wastedetails='".$b."',wardno='".$c."',houseno='".$d."',otherdetails='".$e."',currentdate='".$date."' where id='".$id."'";
     $exe1=mysql_query($qry1);
     if($exe1)
     {
        echo "<script>alert('Request Updated Successfully');
        window.location.href='wastereqview.php'</script>";
     }
     else
     {
         echo "<script>alert('Request Not  Updated Successfully')</script>";
     }
 }
function wastereqdel($key)
 {
     $id=keytoid("wastereq","wkey",$key);
     $qry="delete from wastereq where id='".$id."'";
    $exe1=mysql_query($qry);
     if($exe1)
     {
        echo "<script>alert('Request Deleted Successfully');
        window.location.href='wastereqview.php'</script>";
     }
     else
     {
         echo "<script>alert('Request Not  Deleted')</script>";
     }
 }
 function sel_panchayath()
 {
    $qry="select * from panchayatreg";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
 }


    
 function wastereqadminview($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from wastereq inner join publicreg on publicreg.loginid=wastereq.loginid where publicreg.panchayatname='".$id."'";
     // echo $qry;exit;
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    

function selectdate($a,$b,$wkey,$key)
 { 
    // echo "string";exit();
    $keyy=uniquekey("selectdate","dkey");
    $cdate=date('Y-m-d');
    $id=keytoid("login","ekey",$key);
    $wid=keytoid("wastereq","wkey",$wkey);
    $qry="insert into selectdate(dkey,wasterequestid,date,otherdetails,loginid,currentdate)
    values('".$keyy."','".$wid."', '".$a."', '".$b."','".$id."','".$cdate."')";
    // echo $qry;exit();
     $exe=mysql_query($qry);
     if ($exe)
     {
        echo"<script>alert('Date Selected Successfully')</script>";
     }
     else
     {
        echo"<script>alert(' Date Selected Unsuccessfully')</script>";
     } 
    } 

function selectdateview($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from selectdate inner join wastereq on selectdate.wasterequestid=wastereq.id inner join publicreg on wastereq.loginid=publicreg.loginid where selectdate.loginid='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    


function selectdateedit($key)
{
    $id=keytoid("selectdate","dkey",$key);
    $qry="select * from selectdate where id='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}

function editselectdate($a,$b,$key)
{
     $id=keytoid("selectdate","dkey",$key);
     $date=date('Y-m-d');
     $qry1="update selectdate set date='".$a."',otherdetails='".$b."',date='".$date."' where id='".$id."'";
     $exe1=mysql_query($qry1);
     if($exe1)
     {
        echo "<script>alert(' Updated Successfully');
        window.location.href='selectdateview.php'</script>";
     }
     else
     {
         echo "<script>alert(' Not  Updated Successfully')</script>";
     }
 }

function selectdatedelete($key)
 {
     $id=keytoid("selectdate","dkey",$key);
     $qry="delete from selectdate where id='".$id."'";
    $exe1=mysql_query($qry);
     if($exe1)
     {
        echo "<script>alert(' Deleted Successfully');
        window.location.href='selectdateview.php'</script>";
     }
     else
     {
         echo "<script>alert('Not  Deleted')</script>";
     }
 }

function selectdatepview($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from selectdate where loginid='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}     
 function volunteersel($key,$wkey)
 {
    $id=keytoid("login","ekey",$key);
    $qry="select * from volunteerreg inner join login on volunteerreg.loginid=login.id where volunteerreg.panchayathname='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $rr['wkey']=$wkey;
        $arr[]=$rr;

    }
    return $arr;
 }

function volunteerconfrim($pkey,$wkey,$vkey)
 {
    $keyy=uniquekey("volunteersel","okey");
    $date=date('Y-m-d');
    $pid=keytoid("login","ekey",$pkey);
    $wid=keytoid("wastereq","wkey",$wkey);
    $vid=keytoid("volunteerreg","vkey",$vkey);
    $q1="select loginid from volunteerreg where id='".$vid."'";
    $e1=mysql_query($q1);
    while($r1=mysql_fetch_array($e1))
    {
        $v_id=$r1['loginid'];
    }
    $qry="insert into volunteersel(okey,requestid,volunteerloginid,panchayathloginid,currentdate)
    values('".$keyy."', '".$wid."', '".$v_id."', '".$pid."','".$date."')";
    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe)
     {
        echo"<script>alert('Request Submission Successful');
        window.location.href='selectdateview.php'</script>";
     }
     else
     {
        echo"<script>alert('Request Submission Unsuccessful')</script>";
     } 
    } 


 function assignedvolunteers($key,$wkey)
 {
    $id=keytoid("login","ekey",$key);
      $wid=keytoid("wastereq","wkey",$wkey);
    $qry="select * from volunteersel inner join volunteerreg on volunteerreg.loginid=volunteersel.volunteerloginid where volunteersel.requestid='".$wid."'";
    // echo $qry;exit();
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        // $rr['wkey']=$wkey;
        $arr[]=$rr;

    }
    return $arr;
 }

 function colnotification($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from volunteersel inner join wastereq on wastereq.id=volunteersel.requestid inner join publicreg on publicreg.loginid = wastereq.loginid where volunteersel.volunteerloginid='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    

 function payment($a,$b,$c,$d,$e,$key,$paykey)
{
      date_default_timezone_set('Asia/kolkata');
    $t=date('h:i:sa');
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);

    $key1=uniquekey("paymenttable","mkey");

    $qry="insert into paymenttable(mkey,nameoncard,cardnumber,expiremonth,expireyear,cvv,amount,currentdate,loginid) values('".$key1."','".$a."','".$b."','".$c."','".$d."','".$e."','".$paykey."','".$date."','".$id."')";
    //echo $qry;exit;
    $exe=mysql_query($qry);

    $qry="update banktable set amount=amount-150 where cardnumber='".$b."' and cvv='".$e."'";
         
     $exe=mysql_query($qry);
    

     if ($exe)
     {
        echo"<script>alert('Payment Successful');
        window.location.href='publichome.php'</script>";
     }
     else
     {
        echo"<script>alert('payment Unsuccessful')</script>";
     }  

   
}    

function volsendmsg($a,$key)
 {
    $keyy=uniquekey("volsendmsg","msgkey");
    date_default_timezone_set('Asia/kolkata');
    $t=date('h:i:sa');
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);

    $q1="select panchayathname from volunteerreg where loginid='".$id."'";
    $e1=mysql_query($q1);
    $v_id=NULL;
    while($r1=mysql_fetch_array($e1))
    {
        $v_id=$r1['panchayathname'];
    }
    $qry="insert into volsendmsg(msgkey,msg,sendid,recid,currentdate,currenttime)
    values('".$keyy."', '".$a."','".$id."','".$v_id."','".$date."','".$t."')";
    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe)
     {
        echo"<script>alert('Message sent Successfully')</script>";
     }
     else
     {
        echo"<script>alert('Sending message Unsuccessful')</script>";
     } 
    } 

 function volmsgview($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from volsendmsg where sendid='".$id."'";
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}  


 function volmsgdelete($key)
 {
     $id=keytoid("volsendmsg","msgkey",$key);
     $qry="delete from volsendmsg where id='".$id."'";
    $exe1=mysql_query($qry);
     if($exe1)
     {
        echo "<script>alert('Message Deleted Successfully');
        window.location.href='volsendmsg.php'</script>";
     }
     else
     {
         echo "<script>alert('Message Not  Deleted')</script>";
     }
 }


 function msgviewpan($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from volsendmsg inner join volunteerreg on volunteerreg.loginid=volsendmsg.sendid where recid='".$id."'";
   // echo $qry;exit;
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    


function panreply($a,$key,$key1)
 {
    $keyy=uniquekey("volsendmsg","msgkey");
    date_default_timezone_set('Asia/kolkata');
    $t=date('h:i:sa');
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);
    $id1=keytoid("volsendmsg","msgkey",$key1);

    $q1="select sendid from volsendmsg where id='".$id1."'";
    $e1=mysql_query($q1);
    $v_id=NULL;
    while($r1=mysql_fetch_array($e1))
    {
        $v_id=$r1['sendid'];
    }
    $qry="insert into volsendmsg(msgkey,msg,sendid,recid,currentdate,currenttime)
    values('".$keyy."', '".$a."','".$id."','".$v_id."','".$date."','".$t."')";

    // echo  $qry;exit;
     $exe=mysql_query($qry);
     if ($exe)
     {
        echo"<script>alert('Reply sent Successfully')</script>";
     }
     else
     {
        echo"<script>alert('Sending Reply Unsuccessful')</script>";
     } 
    } 



 function replyviewpan($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from volsendmsg inner join volunteerreg on volunteerreg.loginid=volsendmsg.recid where sendid='".$id."'";
   // echo $qry;exit;
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}   

function panreplydelete($key)
 {
     $id=keytoid("volsendmsg","msgkey",$key);
     $qry="delete from volsendmsg where id='".$id."'";
    $exe1=mysql_query($qry);
     if($exe1)
     {
        echo "<script>alert('Message Deleted Successfully');
        window.location.href='panreply.php'</script>";
     }
     else
     {
         echo "<script>alert('Message Not  Deleted')</script>";
     }
 }


function volviewreply($key)
{
    $id=keytoid("login","ekey",$key);
    $qry="select * from volsendmsg inner join volunteerreg on volunteerreg.loginid=volsendmsg.recid where recid='".$id."'";
   // echo $qry;exit;
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    
 
function panpayview($key)
{
    date_default_timezone_set('Asia/kolkata');
    $t=date('h:i:sa');
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);
    $qry="select * from paymenttable inner join publicreg on paymenttable.loginid=publicreg.loginid where panchayatname='".$id."'";
   // echo $qry;exit;
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    
 

function salarycheck($key)
{
    date_default_timezone_set('Asia/kolkata');
    $t=date('h:i:sa');
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);
    $qry="select * from salarytable inner join volunteerreg on salarytable.loginid=volunteerreg.loginid where panchayatname='".$id."'";
   // echo $qry;exit;
    $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}

function paymentpan($a,$b,$key,$key1)
{
     // echo $key1;exit;
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);

    $key122=uniquekey("salarytable","skey");
   
    $key12=keytoid("login","ekey",$key1);
    //echo $key12;exit;
    $qry="insert into salarytable(skey,month,salary,volid,loginid) values('".$key122."','".$a."','".$b."','".$key12."','".$id."')";
    //echo $qry;exit;
   
     $exe=mysql_query($qry);
    

     if ($exe)
     {
        echo"<script>alert('Salary payment Successful');
        window.location.href='panchayathome.php'</script>";
     }
     else
     {
        echo"<script>alert('Salary payment Unsuccessful')</script>";
     }  

   
} 



function salaryview($key)
{
    $date=date('Y-m-d');
    $id=keytoid("login","ekey",$key);
    $qry="select * from salarytable inner join volunteerreg on salarytable.volid=volunteerreg.loginid where salarytable.volid='".$id."'";
   // echo $qry;exit;
  $exe=mysql_query($qry);
    $arr=array();
    while($rr=mysql_fetch_array($exe))
    {
        $arr[]=$rr;
    }
    return $arr;
}    



}
?>