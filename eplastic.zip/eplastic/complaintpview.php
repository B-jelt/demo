<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
$key=$_COOKIE['ekey'];
$z=$obj->complaintpview($key);
$smartyObj->assign("complaint",$z);
$smartyObj->display("publicsubheader.tpl");
$smartyObj->display('complaintpview.tpl'); 
$smartyObj->display("footer.tpl");
?>