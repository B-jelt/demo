<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();

$s=$obj->sel_panchayath();
$smartyObj->assign("view",$s);
if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	if(isset($_POST['name'])AND($_POST['name'])!=null)
	{
		if (preg_match('/^[A-Z a-z]*$/', $_POST['name']))
				{

		if(isset($_POST['address'])AND($_POST['address'])!=null)
		{
		if(isset($_POST['pincode'])AND($_POST['pincode'])!=null)
		{
				if (preg_match('/^[0-9]*$/', $_POST['pincode']))
													{
													$no=strlen($_POST['pincode']);
													if($no==6)
													{
			if(isset($_POST['district'])AND($_POST['district'])!=null)

		{


			if(isset($_POST['panchayatname'])AND($_POST['panchayatname'])!=null)
		{

			if(isset($_POST['city'])AND($_POST['city'])!=null)
		{
			if(isset($_POST['contactnumber'])AND($_POST['contactnumber'])!=null)
		{
			if (preg_match('/^[0-9]*$/', $_POST['contactnumber']))	
												{
												$nm1=strlen($_POST['contactnumber']);
												if($nm1>=10 and $nm1<=12)
												{

			if(isset($_POST['email'])AND($_POST['email'])!=null)
			{
				if(isset($_POST['password'])AND($_POST['password'])!=null)
				{
					$a=trim($_POST['name']);
					$b=trim($_POST['address']);
					$c=trim($_POST['pincode']);
				    $d=trim($_POST['district']);
				    $z=trim($_POST['panchayatname']);
                    $e=trim($_POST['city']);
                    $f=trim($_POST['contactnumber']);
					$g=trim($_POST['email']);
					$h=trim($_POST['password']);
					 $obj->eplastic($a,$b,$c,$d,$z,$e,$f,$g,$h);
				}
				
				else
					echo"<script>alert('password is empty')</script>";
				}
				else
					echo"<script>alert('email is empty')</script>";
				}
				else
					echo "<script> alert('Enter at least 10 numbers for Contact')</script>";	
				}
				else
					echo "<script> alert('Enter numbers for Contact ')</script>";
			}
				else
					echo"<script>alert('contactnumber is empty')</script>";
				}
			
				else
					echo"<script>alert('city is empty')</script>";

				}

				else
					echo"<script>alert('panchayatname is empty')</script>";
			     }

				else
					echo"<script>alert('district is empty')</script>";
				}
				else
					echo "<script> alert('pin number must contain 6 characters')</script>";
				
					}
						else
					echo "<script> alert('pin number must contain digits')</script>";
			}							
				else
					echo"<script>alert('pincode is empty')</script>";
				
				}
				else
					echo"<script>alert('address is empty')</script>";
				}
			else
					echo "<script> alert('Please use only alphabets for the name') </script>";	
				}
			else
					
					echo "<script> alert('name is empty!')</script>";
					
			}

			 $smartyObj->display('subheader.tpl');

			$smartyObj->display('publicreg.tpl');

			 $smartyObj->display('footer.tpl');
			 

			?>
