<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$wkey=$_GET['key'];
$key1=$_COOKIE['ekey'];	
	// echo "hii";exit;
if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	if(isset($_POST['date'])AND($_POST['date'])!=null)
	{

	if(isset($_POST['otherdetails'])AND($_POST['otherdetails'])!=null)
	{
	
			        $a=trim($_POST['date']);
					$b=trim($_POST['otherdetails']);
					$obj->selectdate($a,$b,$wkey,$key1);
				}
				
			
				else
					echo"<script>alert('date is empty')</script>";
			     }
			else
					echo"<script>alert('otherdetails is empty')</script>";
			}

			$smartyObj->display('panchayathsubheader.tpl');

			$smartyObj->display('selectdate.tpl');

			 $smartyObj->display('footer.tpl');
			 }
else
{	
	Header("location:index.php");
}
			?>
