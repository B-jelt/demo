<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$key=$_COOKIE['ekey'];

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
		if(isset($_POST['aadharno'])AND($_POST['aadharno'])!=null)
		{
		if(isset($_POST['wastedetails'])AND($_POST['wastedetails'])!=null)
		{
			if(isset($_POST['wardno'])AND($_POST['wardno'])!=null)
		{
			if(isset($_POST['houseno'])AND($_POST['houseno'])!=null)
		{
			if(isset($_POST['otherdetails'])AND($_POST['otherdetails'])!=null)
		{
					$a=trim($_POST['aadharno']);
					$b=trim($_POST['wastedetails']);
					$c=trim($_POST['wardno']);
				    $d=trim($_POST['houseno']);
                    $e=trim($_POST['otherdetails']);
                
					 $obj->wastereq($a,$b,$c,$d,$e,$key);
				}
				
				else
					echo"<script>alert('otherdetails are empty')</script>";
				}
				else
					echo"<script>alert('houseno is empty')</script>";
				}
				else
					echo"<script>alert('wardno is empty')</script>";
				}
				
				else
					echo"<script>alert('wastedetails is empty')</script>";

				}
				else
					echo"<script>alert('aadharno is empty')</script>";
				}
				

			 $smartyObj->display('publicsubheader.tpl');

			$smartyObj->display('wastereq.tpl');

			 $smartyObj->display('footer.tpl');
			 }
else
{	
	Header("location:index.php");
}
			

			?>
