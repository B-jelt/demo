<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$key=$_COOKIE['ekey'];
$z=$obj->selectdateview($key);
$smartyObj->assign("selectdate",$z);
$smartyObj->display("panchayathsubheader.tpl");
$smartyObj->display('selectdateview.tpl'); 
$smartyObj->display("footer.tpl");
}
else
{	
	Header("location:index.php");
}
?>