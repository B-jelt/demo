<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$key=$_COOKIE['ekey'];
if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	

	if(isset($_POST['message'])AND($_POST['message'])!=null)
	{
		
			        
					$b=trim($_POST['message']);
			
					 $obj->notification($b,$key);
				}
				
			
				else
					echo"<script>alert('message is empty')</script>";
			     }
		
			$smartyObj->display('panchayathsubheader.tpl');

			$smartyObj->display('notification.tpl');

			 $smartyObj->display('footer.tpl');
			 }
else
{	
	Header("location:index.php");
}
			?>
