<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();
if(isset($_COOKIE['logined'])&& $_COOKIE['logined']==1)
{
$sd=$obj->seldistrict();
$smartyObj->assign("view",$sd);
if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	
	if(isset($_POST['district'])AND($_POST['district'])!=null)
	{
		   $a=trim($_POST['district']);
		   $pc=$obj->selpanchayat($a);
		   $smartyObj->assign("view1",$pc);
			
			}
				
				else
					echo"<script>alert('district is empty')</script>";
				}
				
				

			

			$smartyObj->display('adminsubheader.tpl');

			$smartyObj->display('wastereqadmin.tpl');

			 $smartyObj->display('footer.tpl');
			 }
else
{	
	Header("location:index.php");
}
			?>
