<?php
	$dbpath="localhost";
	$dbusername="root";
	$dbpassword="";
	$dbname="eplastic";
?>