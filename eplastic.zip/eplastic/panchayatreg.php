<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
session_start();

if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	if(isset($_POST['panchayatid'])AND($_POST['panchayatid'])!=null)
	{
if (preg_match('/^[0-9]*$/', $_POST['panchayatid']))
													{
													$no=strlen($_POST['panchayatid']);
													if($no==2)
													{
	if(isset($_POST['panchayatname'])AND($_POST['panchayatname'])!=null)
	{
		if (preg_match('/^[A-Z a-z]*$/', $_POST['panchayatname']))
				{
		
		if(isset($_POST['address'])AND($_POST['address'])!=null)
		{
		if(isset($_POST['pincode'])AND($_POST['pincode'])!=null)
		{
			if (preg_match('/^[0-9]*$/', $_POST['pincode']))
													{
													$no=strlen($_POST['pincode']);
													if($no==6)
													{
			if(isset($_POST['district'])AND($_POST['district'])!=null)
		{
			if(isset($_POST['taluk'])AND($_POST['taluk'])!=null)
		{
			if(isset($_POST['village'])AND($_POST['village'])!=null)
		{
			if(isset($_POST['city'])AND($_POST['city'])!=null)
		{
			if(isset($_POST['contactnumber'])AND($_POST['contactnumber'])!=null)
		{
			if (preg_match('/^[0-9]*$/', $_POST['contactnumber']))	
												{
												$nm1=strlen($_POST['contactnumber']);
												if($nm1>=10 and $nm1<=12)
												{

			if(isset($_POST['email'])AND($_POST['email'])!=null)
			{
				if(isset($_POST['password'])AND($_POST['password'])!=null)
				{
			        $a=trim($_POST['panchayatid']);
					$b=trim($_POST['panchayatname']);
					$c=trim($_POST['address']);
					$d=trim($_POST['pincode']);
				    $e=trim($_POST['district']);
				    $f=trim($_POST['taluk']);
				    $g=trim($_POST['village']);
                    $h=trim($_POST['city']);
                    $i=trim($_POST['contactnumber']);
					$j=trim($_POST['email']);
					$k=trim($_POST['password']);
					 $obj->panchayat($a,$b,$c,$d,$e,$f,$g,$h,$i,$j,$k);
				}
				
				else
					echo"<script>alert('password is empty')</script>";
				}
				else
					echo"<script>alert('email is empty')</script>";
				}
				else
					echo "<script> alert('Enter at least 10 numbers for the phone number')</script>";	
				}}
				else
					echo"<script>alert('contactnumber is empty')</script>";
				}
				
				else
					echo"<script>alert('city is empty')</script>";

				}
				else
					echo "<script>alert('village is empty')</script>";

				}

				else
					echo"<script>alert('taluk is empty')</script>";

				}

				else
					echo"<script>alert('district is empty')</script>";
				}
				else
					echo "<script> alert('pin number must contain 6 characters')</script>";
				
					}	}	
				else
					echo"<script>alert('pincode is empty')</script>";
				
				}
				else
					echo"<script>alert('address is empty')</script>";
				}
				else
					echo "<script> alert('Please use only alphabets for the panchayatname') </script>";	
				}
				else
					echo"<script>alert('panchayatname is empty')</script>";
			     }
			     else
					echo "<script> alert('panchayatid must contain 2 characters')</script>";
				
					}	}
			else
					echo"<script>alert('panchayatid is empty')</script>";
			}

			$smartyObj->display('subheader.tpl');

			$smartyObj->display('panchayatreg.tpl');

			 $smartyObj->display('footer.tpl');
			 
			?>
