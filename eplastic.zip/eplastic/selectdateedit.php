<?php
include_once"settings/settings.php";
include_once"classes/userclass.php";
$obj=new userclass();
$key=$_GET['key'];
$sel=$obj->selectdateedit($key);
$smartyObj->assign("view",$sel);
if (isset($_POST['hide'])AND($_POST['hide'])=='h')
{
	
		if(isset($_POST['date'])AND($_POST['date'])!=null)
		{
		

		if(isset($_POST['otherdetails'])AND($_POST['otherdetails'])!=null)
		{
		
					$a=trim($_POST['date']);
					$b=trim($_POST['otherdetails']);
					 $obj->editselectdate($a,$b,$key);
				}
				
				
				else
					echo"<script>alert('date is empty')</script>";
			     }
			else
					echo"<script>alert('otherdetails is empty')</script>";
			}

			 $smartyObj->display('panchayathsubheader.tpl');

			$smartyObj->display('selectdateedit.tpl');

			 $smartyObj->display('footer.tpl');
		

?>